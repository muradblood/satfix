<?php
require_once __DIR__ . '/config.php';

// رؤوس أمان وأداء
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), geolocation=(), microphone=()');
header('Cache-Control: no-store, max-age=0, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$accept = $_SERVER['HTTP_ACCEPT'] ?? '';

function clean_any($key) {
    return isset($_POST[$key]) ? trim(filter_var($_POST[$key], FILTER_SANITIZE_FULL_SPECIAL_CHARS)) : '';
}
function pick(...$keys) {
    foreach ($keys as $k) {
        $v = clean_any($k);
        if ($v !== '') return $v;
    }
    return '';
}
function label_of($k) {
    $map = [
        'product'     => 'المنتج',
        'car_make'    => 'الماركة',
        'car_year'    => 'سنة الصنع',
        'driver_age'  => 'عمر السائق',
        'no_claim'    => 'بدون مطالبات',
        'destination' => 'الوجهة',
        'days'        => 'الأيام',
        'notes'       => 'ملاحظات',
    ];
    return $map[$k] ?? $k;
}

// التقط الحقول الأساسية بأسماء متعددة
$subject = pick('subject','موضوع');
$name    = pick('name','fullname','username','isim','الاسم');
$company = pick('company','الشركة');
$phone   = pick('phone','mobile','tel','gsm','الهاتف','رقم');
$email   = pick('email','mail','email_address','البريد');
$type    = pick('type','service','kind','category','product','النوع');
$message = pick('message','msg','notes','textarea','ملاحظات');

// خصائص إضافية شائعة
$car_make    = clean_any('car_make');
$car_year    = clean_any('car_year');
$driver_age  = clean_any('driver_age');
$no_claim    = clean_any('no_claim');
$destination = clean_any('destination');
$days        = clean_any('days');

// التقط أي مفاتيح إضافية لم نذكرها صراحة
$known = ['subject','موضوع','name','fullname','username','isim','الاسم','company','الشركة','phone','mobile','tel','gsm','الهاتف','رقم','email','mail','email_address','البريد','type','service','kind','category','product','النوع','message','msg','notes','textarea','ملاحظات','car_make','car_year','driver_age','no_claim','destination','days'];
$extras = [];
foreach ($_POST as $k => $v) {
    if (!in_array($k, $known, true)) {
        $vv = clean_any($k);
        if ($vv !== '') $extras[$k] = $vv;
    }
}

$ip   = get_real_ip();
$time = date('Y-m-d H:i:s');

// على الأقل شيء معرّف عن المرسل
if ($name==='' && $phone==='' && $email==='' && $message==='') {
    http_response_code(400);
    if (strpos($accept, 'application/json') !== false) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status'=>'error','message'=>'لا يوجد بيانات كافية']);
    } elseif (strpos($accept, 'text/html') !== false) {
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>خطأ</title></head><body><h1>تعذر الإرسال ❌</h1><p>لا يوجد بيانات كافية.</p></body></html>';
    } else {
        header('Content-Type: text/plain; charset=utf-8');
        echo "لا يوجد بيانات كافية";
    }
    exit;
}

// ابنِ نص تيليجرام بأسطر حقيقية "\n" وليس %0A
$lines = [];
if ($subject) $lines[] = "الموضوع: <b>{$subject}</b>";
if ($name)    $lines[] = "الاسم: <b>{$name}</b>";
if ($company) $lines[] = "الشركة: <b>{$company}</b>";
if ($phone)   $lines[] = "الهاتف: <b>{$phone}</b>";
if ($email)   $lines[] = "البريد: <b>{$email}</b>";
if ($type)    $lines[] = "النوع/المنتج: <b>{$type}</b>";

if ($car_make)    $lines[] = "الماركة: <b>{$car_make}</b>";
if ($car_year)    $lines[] = "سنة الصنع: <b>{$car_year}</b>";
if ($driver_age)  $lines[] = "عمر السائق: <b>{$driver_age}</b>";
if ($no_claim!=='') $lines[] = "بدون مطالبات: <b>{$no_claim}</b>";
if ($destination) $lines[] = "الوجهة: <b>{$destination}</b>";
if ($days)        $lines[] = "الأيام: <b>{$days}</b>";

if ($message) $lines[] = "ملاحظة: " . nl2br($message);

// ألحق أي مفاتيح إضافية
foreach ($extras as $k => $v) {
    $label = label_of($k);
    $lines[] = "{$label}: <b>{$v}</b>";
}

$lines[] = "IP: <code>{$ip}</code>";
$lines[] = "الوقت: {$time}";

$text = "📝 <b>نموذج جديد</b>\n" . implode("\n", $lines);
tg_send_message($text);

// استجابة حسب Accept
if (strpos($accept, 'text/html') !== false) {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>تم الإرسال</title></head><body><h1>تم الإرسال ✅</h1><p>شكراً لك، استلمنا الطلب.</p></body></html>';
} elseif (strpos($accept, 'application/json') !== false) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status'=>'ok']);
} else {
    header('Content-Type: text/plain; charset=utf-8');
    echo "ok";
}
