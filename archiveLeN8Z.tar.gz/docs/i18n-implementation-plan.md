# Internationalization (i18n) Implementation Plan

## Overview

This document provides a comprehensive plan and code samples for implementing internationalization in your web application, including text translation, date/time formatting, number formatting, and RTL/LTR layout support.

## Architecture

### Core Components

1. **i18n.js** - Main translation engine
2. **localeUtils.js** - Date, time, and number formatting utilities
3. **layoutManager.js** - RTL/LTR layout management
4. **Translation files** - Language-specific content (ar.js, en.js)
5. **LanguageSwitcher.js** - UI component for language selection

## Implementation Guide

### 1. Text Translation

#### Basic Usage

```javascript
import { i18n } from './modules/i18n.js';

// Simple translation
const greeting = i18n.t('common.greeting');

// Translation with parameters
const welcome = i18n.t('messages.welcome', { name: 'Ahmed' });
// Result: "مرحباً Ahmed"

// Pluralization
const passengers = i18n.pluralize('numbers.passenger', 3);
// Arabic: "3 مسافرين"
// English: "3 passengers"
```

#### HTML Integration

```html
<!-- Using data attributes -->
<button data-i18n="common.search">Search</button>
<input data-i18n="form.searchPlaceholder" placeholder="Search...">
<div data-i18n-aria="accessibility.menu" aria-label="Menu"></div>

<!-- JavaScript will automatically update these -->
<script>
  i18n.onLocaleChange(() => {
    updateTranslations();
  });
</script>
```

#### Nested Keys

```javascript
// Translation file structure
export default {
  validation: {
    required: 'This field is required',
    email: {
      invalid: 'Invalid email address',
      required: 'Email is required'
    }
  }
};

// Access nested translations
i18n.t('validation.required');
i18n.t('validation.email.invalid');
```

### 2. Date and Time Formatting

#### Using Intl.DateTimeFormat

```javascript
import { formatDate, formatTime, formatDateTime } from './modules/localeUtils.js';

const date = new Date('2024-03-15T14:30:00');

// Date formatting
formatDate(date);
// Arabic: "١٥ مارس ٢٠٢٤"
// English: "March 15, 2024"

formatDate(date, { dateStyle: 'short' });
// Arabic: "١٥‏/٣‏/٢٠٢٤"
// English: "3/15/2024"

// Time formatting
formatTime(date);
// Arabic: "٠٢:٣٠ م"
// English: "02:30 PM"

// DateTime formatting
formatDateTime(date);
// Arabic: "١٥ مارس ٢٠٢٤ في ٠٢:٣٠ م"
// English: "March 15, 2024 at 02:30 PM"
```

#### Relative Time Formatting

```javascript
import { formatRelativeTime } from './modules/localeUtils.js';

const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000);
formatRelativeTime(yesterday);
// Arabic: "منذ يوم واحد"
// English: "yesterday"

const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);
formatRelativeTime(tomorrow);
// Arabic: "غداً"
// English: "tomorrow"
```

#### Custom Date Formats

```javascript
import { LocaleUtils } from './modules/localeUtils.js';

LocaleUtils.formatDate(date, {
  weekday: 'long',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
  hour: '2-digit',
  minute: '2-digit'
});
// Arabic: "الجمعة، ١٥ مارس ٢٠٢٤ في ٠٢:٣٠"
// English: "Friday, March 15, 2024 at 02:30"
```

### 3. Number Formatting

#### Basic Number Formatting

```javascript
import { formatNumber, formatCurrency, formatPercent } from './modules/localeUtils.js';

// Number formatting
formatNumber(1234567.89);
// Arabic: "١٬٢٣٤٬٥٦٧٫٨٩"
// English: "1,234,567.89"

// Currency formatting
formatCurrency(99.99, 'SAR');
// Arabic: "٩٩٫٩٩ ر.س.‏"
// English: "SAR 99.99"

formatCurrency(99.99, 'USD');
// Arabic: "٩٩٫٩٩ US$‏"
// English: "$99.99"

// Percentage formatting
formatPercent(0.856);
// Arabic: "٨٦٪"
// English: "86%"
```

#### Compact Number Notation

```javascript
import { LocaleUtils } from './modules/localeUtils.js';

LocaleUtils.formatCompactNumber(1500000);
// Arabic: "١٫٥ مليون"
// English: "1.5M"

LocaleUtils.formatCompactNumber(2500);
// Arabic: "٢٫٥ ألف"
// English: "2.5K"
```

#### Custom Number Options

```javascript
LocaleUtils.formatNumber(123.456, {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});
// Result: "123.46"

LocaleUtils.formatCurrency(1234.5, 'SAR', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 0
});
// Arabic: "١٬٢٣٥ ر.س.‏"
// English: "SAR 1,235"
```

### 4. RTL/LTR Layout Support

#### Automatic Layout Management

```javascript
import { layoutManager } from './modules/layoutManager.js';

// Initialize layout manager
layoutManager.init();

// Get current direction
const direction = layoutManager.getDirection(); // 'rtl' or 'ltr'
const isRTL = layoutManager.isRTL(); // true or false

// Listen to direction changes
layoutManager.onDirectionChange((newDirection) => {
  console.log('Direction changed to:', newDirection);
  updateLayout(newDirection);
});
```

#### CSS with Logical Properties

```css
/* Traditional approach (not recommended) */
.element {
  margin-left: 20px;
  text-align: left;
}

/* Modern approach using logical properties */
.element {
  margin-inline-start: 20px;
  text-align: start;
}

/* RTL-aware positioning */
.sidebar {
  inset-inline-start: 0; /* left in LTR, right in RTL */
}

/* Direction-specific styles */
[dir="rtl"] .icon {
  transform: scaleX(-1); /* Flip horizontally */
}

[dir="ltr"] .icon {
  transform: scaleX(1);
}
```

#### JavaScript Layout Helpers

```javascript
// Get start/end positions
const startPos = layoutManager.getStartPosition(); // 'left' or 'right'
const endPos = layoutManager.getEndPosition(); // 'right' or 'left'

// Mirror transforms
const transform = layoutManager.mirrorTransform('translateX(10px)');
// RTL: "translateX(-10px)"
// LTR: "translateX(10px)"

// Flip values
const flipped = layoutManager.flipHorizontalValue('left');
// RTL: "right"
// LTR: "left"

// Apply logical styles
layoutManager.applyLogicalStyles(element, {
  'margin-left': '20px',
  'padding-right': '10px'
});
// Automatically converts to inline-start/inline-end
```

#### HTML Data Attributes for Layout

```html
<!-- Flex direction management -->
<div data-flex-dir="row" class="flex">
  <!-- Automatically reverses in RTL -->
</div>

<!-- Logical properties -->
<div data-logical-props='{"left": "0", "marginLeft": "10px"}'>
  <!-- Automatically flips in RTL -->
</div>

<!-- Transform origin -->
<div data-transform-origin="left center">
  <!-- Flips to "right center" in RTL -->
</div>

<!-- Text alignment -->
<div data-text-align="left">
  <!-- Becomes "right" in RTL -->
</div>
```

### 5. Language Switcher Component

#### Basic Implementation

```javascript
import { createLanguageSwitcher } from './components/LanguageSwitcher.js';

// Create language switcher
const switcher = createLanguageSwitcher('language-switcher-container');

// Listen to language changes
window.addEventListener('languageChanged', (event) => {
  console.log('New locale:', event.detail.locale);
  updateApplicationState(event.detail.locale);
});
```

#### HTML Integration

```html
<!-- Container for language switcher -->
<div id="language-switcher-container"></div>

<!-- The switcher will render a dropdown with all available languages -->
```

#### Custom Styling

```css
.language-switcher button {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  transition: background-color 0.2s;
}

.language-switcher button:hover {
  background-color: #f5f5f5;
}

#language-menu {
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
  animation: slideDown 0.2s ease-out;
}

@keyframes slideDown {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
```

## Recommended Libraries

### 1. Core i18n Library: Custom Implementation

**Pros:**
- Lightweight and fast
- Full control over functionality
- No external dependencies
- Optimized for your specific needs

**Cons:**
- Requires maintenance
- Missing some advanced features

### 2. Alternative: i18next (Industry Standard)

If you need more features, consider i18next:

```bash
npm install i18next i18next-browser-languagedetector
```

```javascript
import i18next from 'i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

i18next
  .use(LanguageDetector)
  .init({
    resources: {
      ar: { translation: require('./locales/ar.json') },
      en: { translation: require('./locales/en.json') }
    },
    fallbackLng: 'ar',
    interpolation: {
      escapeValue: false
    }
  });
```

### 3. Date/Time: Intl API (Built-in)

**Recommended:** Use the built-in Intl API (already implemented)

**Alternative libraries:**
- date-fns with locales
- Day.js with i18n plugin
- Luxon

### 4. Number Formatting: Intl API (Built-in)

**Recommended:** Use Intl.NumberFormat (already implemented)

**Alternative:**
- numeral.js with locales
- accounting.js

## Best Practices

### 1. Translation Keys Organization

```javascript
// Good: Hierarchical structure
{
  validation: {
    required: 'Required',
    email: {
      invalid: 'Invalid email',
      required: 'Email required'
    }
  }
}

// Bad: Flat structure
{
  'validation.required': 'Required',
  'validation.email.invalid': 'Invalid email'
}
```

### 2. Pluralization

```javascript
// Arabic has 6 plural forms
{
  passenger: {
    zero: 'لا يوجد مسافرون',
    one: 'مسافر واحد',
    two: 'مسافران',
    few: '{count} مسافرين',
    many: '{count} مسافراً',
    other: '{count} مسافر'
  }
}

// English has 2 forms
{
  passenger: {
    one: '1 passenger',
    other: '{count} passengers'
  }
}

// Usage
i18n.pluralize('passenger', 3);
```

### 3. Context-Aware Translations

```javascript
// Good: Provide context in keys
{
  button: {
    save: 'Save',
    cancel: 'Cancel'
  },
  message: {
    save: 'Your changes have been saved',
    cancel: 'Operation cancelled'
  }
}

// Usage makes intent clear
i18n.t('button.save');
i18n.t('message.save');
```

### 4. Dynamic Content

```javascript
// Use interpolation for dynamic values
{
  greeting: 'Hello {name}!',
  itemsFound: 'Found {count} items',
  dateRange: 'From {start} to {end}'
}

// Usage
i18n.t('greeting', { name: 'Ahmed' });
i18n.t('itemsFound', { count: 42 });
i18n.t('dateRange', {
  start: formatDate(startDate),
  end: formatDate(endDate)
});
```

### 5. Fallback Handling

```javascript
// Always provide fallback locale
await i18n.init('ar'); // Primary
await i18n.loadLocale('en'); // Fallback

// Missing keys will use English
i18n.t('missing.key'); // Returns English text or key itself
```

### 6. Performance Optimization

```javascript
// Lazy load translations
async function loadLocale(locale) {
  const module = await import(`./locales/${locale}.js`);
  return module.default;
}

// Cache formatted values
const dateFormatter = new Intl.DateTimeFormat(locale);
// Reuse formatter instead of creating new ones

// Debounce locale changes
let changeTimeout;
function changeLocale(locale) {
  clearTimeout(changeTimeout);
  changeTimeout = setTimeout(() => {
    i18n.changeLocale(locale);
  }, 300);
}
```

## Testing Strategies

### 1. Unit Tests

```javascript
import { i18n } from './modules/i18n.js';

describe('i18n', () => {
  test('should translate keys', async () => {
    await i18n.init('en');
    expect(i18n.t('common.search')).toBe('Search');
  });

  test('should interpolate parameters', async () => {
    await i18n.init('en');
    expect(i18n.t('greeting', { name: 'John' }))
      .toBe('Hello John!');
  });

  test('should handle pluralization', async () => {
    await i18n.init('en');
    expect(i18n.pluralize('passenger', 1)).toBe('1 passenger');
    expect(i18n.pluralize('passenger', 5)).toBe('5 passengers');
  });
});
```

### 2. RTL Layout Tests

```javascript
import { layoutManager } from './modules/layoutManager.js';

describe('layoutManager', () => {
  test('should detect RTL for Arabic', () => {
    i18n.changeLocale('ar');
    expect(layoutManager.isRTL()).toBe(true);
  });

  test('should detect LTR for English', () => {
    i18n.changeLocale('en');
    expect(layoutManager.isRTL()).toBe(false);
  });

  test('should flip positions in RTL', () => {
    i18n.changeLocale('ar');
    expect(layoutManager.getStartPosition()).toBe('right');
    expect(layoutManager.getEndPosition()).toBe('left');
  });
});
```

### 3. Visual Regression Tests

Use tools like:
- Playwright for screenshot comparison
- Chromatic for visual testing
- Percy for automated visual reviews

## Accessibility Considerations

### 1. Language Attributes

```html
<html lang="ar" dir="rtl">
  <!-- Automatically updated by layoutManager -->
</html>
```

### 2. ARIA Labels

```html
<button aria-label="${i18n.t('accessibility.closeDialog')}">
  <iconify-icon icon="close"></iconify-icon>
</button>
```

### 3. Screen Reader Support

```javascript
// Update live regions when locale changes
i18n.onLocaleChange(() => {
  const liveRegion = document.getElementById('announcements');
  liveRegion.textContent = i18n.t('messages.localeChanged');
});
```

## Migration Strategy

### Phase 1: Setup Infrastructure (Day 1-2)
- Install i18n system
- Create translation files
- Set up build configuration

### Phase 2: Core Components (Day 3-5)
- Migrate authentication flows
- Update form validation messages
- Translate navigation elements

### Phase 3: Content (Day 6-8)
- Migrate all static text
- Update date/time displays
- Format numbers and currencies

### Phase 4: RTL Support (Day 9-10)
- Implement layout manager
- Test all components in RTL
- Fix layout issues

### Phase 5: Testing & Polish (Day 11-14)
- Comprehensive testing
- Fix edge cases
- Performance optimization
- Documentation

## Tools & Resources

### Translation Management
- **Lokalise** - Professional translation platform
- **Crowdin** - Collaborative translation
- **POEditor** - Simple translation management
- **i18n-ally** - VS Code extension for inline translations

### Testing Tools
- **Playwright** - E2E testing with i18n support
- **Jest** - Unit testing framework
- **React Testing Library** - Component testing

### Design Tools
- **Figma** - Design with RTL support
- **Adobe XD** - Prototyping with i18n
- **Zeplin** - Design handoff with translations

### Browser Extensions
- **React DevTools** - Debug React i18n
- **Redux DevTools** - Track locale state
- **Locale Switcher** - Test different locales quickly

## Common Pitfalls

### 1. Hardcoded Text
```javascript
// Bad
<button>Search</button>

// Good
<button data-i18n="common.search">{i18n.t('common.search')}</button>
```

### 2. String Concatenation
```javascript
// Bad
const message = 'You have ' + count + ' messages';

// Good
const message = i18n.t('messages.count', { count });
```

### 3. Date Formatting
```javascript
// Bad
const date = `${day}/${month}/${year}`;

// Good
const date = formatDate(new Date(year, month, day));
```

### 4. Fixed Layouts
```css
/* Bad */
.sidebar { left: 0; }

/* Good */
.sidebar { inset-inline-start: 0; }
```

### 5. Assuming Text Length
```css
/* Bad */
.button { width: 100px; }

/* Good */
.button {
  min-width: 100px;
  width: fit-content;
  padding: 0.5rem 1rem;
}
```

## Monitoring & Analytics

### Track Locale Usage
```javascript
// Send analytics when locale changes
i18n.onLocaleChange((locale) => {
  analytics.track('locale_changed', {
    locale,
    previous: i18n.previousLocale,
    timestamp: Date.now()
  });
});
```

### Error Tracking
```javascript
// Log missing translations
if (!i18n.exists(key)) {
  errorReporting.captureMessage('Missing translation', {
    key,
    locale: i18n.getLocale()
  });
}
```

## Database Integration with Supabase

### Store User Locale Preference

```sql
-- Migration: Add locale column to users table
ALTER TABLE users ADD COLUMN locale VARCHAR(10) DEFAULT 'ar';
CREATE INDEX idx_users_locale ON users(locale);
```

```javascript
// Save user locale preference
async function saveUserLocale(userId, locale) {
  const { error } = await supabase
    .from('users')
    .update({ locale })
    .eq('id', userId);

  if (!error) {
    localStorage.setItem('locale', locale);
  }
}

// Load user locale preference
async function loadUserLocale(userId) {
  const { data, error } = await supabase
    .from('users')
    .select('locale')
    .eq('id', userId)
    .maybeSingle();

  if (data?.locale) {
    await i18n.changeLocale(data.locale);
  }
}
```

### Multilingual Content in Database

```sql
-- Store translations in JSONB
CREATE TABLE content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  translations JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Example data
INSERT INTO content (translations) VALUES (
  '{
    "ar": {"title": "عنوان", "description": "وصف"},
    "en": {"title": "Title", "description": "Description"}
  }'::jsonb
);

-- Query with locale
SELECT translations->>'ar' as title FROM content;
```

## Conclusion

This implementation provides a robust, production-ready internationalization system with:
- ✅ Automatic text translation
- ✅ Locale-aware date/time formatting
- ✅ Currency and number formatting
- ✅ Full RTL/LTR layout support
- ✅ Easy-to-use language switcher
- ✅ Performance optimized
- ✅ Accessible
- ✅ Type-safe

The system is extensible and can easily accommodate additional languages and features as your application grows.
