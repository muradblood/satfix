# دليل الترحيل من Supabase إلى MySQL

هذا الدليل يشرح كيفية ترحيل التطبيق من Supabase إلى MySQL + PHP API.

---

## 📊 المقارنة

| الميزة | Supabase | MySQL + PHP API |
|-------|----------|----------------|
| **التكلفة** | مجاني حتى حد معين، ثم مدفوع | مجاني تماماً (خادم خاص) |
| **التحكم** | محدود | تحكم كامل |
| **الأداء** | جيد | يعتمد على الخادم |
| **الصيانة** | تلقائية | يدوية |
| **النسخ الاحتياطي** | تلقائي | يدوي أو آلي |
| **الأمان** | مدمج | يحتاج إعداد |
| **التوسع** | تلقائي | يدوي |

---

## 🔄 خطوات الترحيل

### الخطوة 1: إعداد MySQL

اتبع [دليل التثبيت](MYSQL_SETUP_GUIDE.md) لإعداد MySQL.

```bash
# إنشاء قاعدة البيانات
mysql -u root -p < database/schema.sql
```

---

### الخطوة 2: تصدير البيانات من Supabase

#### الطريقة 1: باستخدام Supabase Dashboard

1. افتح Supabase Dashboard
2. اذهب إلى Database → Backups
3. اضغط "Download Backup"
4. احفظ الملف

#### الطريقة 2: باستخدام pg_dump

```bash
# تصدير قاعدة البيانات
pg_dump -h db.wkkoicbjkbnhfqwbwewa.supabase.co \
  -U postgres \
  -d postgres \
  --data-only \
  --table=users \
  --table=bookings \
  --table=trips \
  > supabase_data.sql
```

---

### الخطوة 3: تحويل البيانات

قم بإنشاء سكربت Python لتحويل البيانات من PostgreSQL إلى MySQL:

```python
#!/usr/bin/env python3
import psycopg2
import mysql.connector
from datetime import datetime

# الاتصال بـ Supabase (PostgreSQL)
pg_conn = psycopg2.connect(
    host="db.wkkoicbjkbnhfqwbwewa.supabase.co",
    database="postgres",
    user="postgres",
    password="YOUR_PASSWORD"
)

# الاتصال بـ MySQL
mysql_conn = mysql.connector.connect(
    host="localhost",
    database="bus_booking_system",
    user="bus_admin",
    password="YOUR_PASSWORD"
)

# نقل المستخدمين
pg_cursor = pg_conn.cursor()
mysql_cursor = mysql_conn.cursor()

pg_cursor.execute("SELECT id, email, encrypted_password FROM auth.users")
users = pg_cursor.fetchall()

for user in users:
    mysql_cursor.execute("""
        INSERT INTO users (id, email, password_hash, created_at)
        VALUES (%s, %s, %s, NOW())
    """, (user[0], user[1], user[2]))

mysql_conn.commit()
print(f"تم نقل {len(users)} مستخدم")

# نقل الحجوزات (مثال)
# ... أضف كود مماثل للجداول الأخرى

pg_conn.close()
mysql_conn.close()
```

---

### الخطوة 4: تحديث ملفات JavaScript

#### قبل (Supabase)

```javascript
// src/lib/supabase.js
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

// البحث عن الرحلات
const { data, error } = await supabase
  .from('trips')
  .select('*')
  .eq('from_station_id', fromStation)
  .eq('to_station_id', toStation);
```

#### بعد (MySQL + PHP API)

```javascript
// src/lib/api-client.js
import { apiClient } from './api-client.js';

// البحث عن الرحلات
const response = await apiClient.searchTrips({
  from: fromStation,
  to: toStation,
  date: '2025-01-15'
});

const trips = response.data;
```

---

### الخطوة 5: تحديث الملفات

قم بتحديث جميع الملفات التي تستخدم Supabase:

#### 1. src/main.js

**قبل:**
```javascript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);
```

**بعد:**
```javascript
import { apiClient } from './lib/api-client.js';

// استخدم apiClient بدلاً من supabase
window.api = apiClient;
```

#### 2. src/modules/auth.js

**قبل:**
```javascript
const { data, error } = await supabase.auth.signUp({
  email: email,
  password: password
});
```

**بعد:**
```javascript
const response = await apiClient.register({
  email: email,
  password: password,
  full_name: fullName
});
```

#### 3. src/bookingFormHandler.js

**قبل:**
```javascript
const { data: trips } = await supabase
  .from('trips')
  .select('*')
  .eq('from_station_id', fromStation);
```

**بعد:**
```javascript
const response = await apiClient.searchTrips({
  from: fromStation,
  to: toStation,
  date: departureDate
});
const trips = response.data;
```

---

### الخطوة 6: تحديث ملف .env

**قبل (.env):**
```env
VITE_SUPABASE_URL=https://wkkoicbjkbnhfqwbwewa.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key
```

**بعد (.env):**
```env
VITE_API_URL=http://localhost/api
# أو في الإنتاج
VITE_API_URL=https://yourdomain.com/api
```

---

### الخطوة 7: حذف تبعيات Supabase

```bash
# حذف من package.json
npm uninstall @supabase/supabase-js

# حذف الملفات غير المستخدمة
rm -rf supabase/
rm src/lib/supabase.js
```

---

### الخطوة 8: الاختبار

قم باختبار جميع الوظائف:

```bash
# 1. اختبار تسجيل مستخدم جديد
curl -X POST http://localhost/api/auth.php?action=register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"123456"}'

# 2. اختبار تسجيل الدخول
curl -X POST http://localhost/api/auth.php?action=login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"123456"}'

# 3. اختبار الحصول على المحطات
curl http://localhost/api/api.php?endpoint=stations

# 4. اختبار البحث عن رحلات
curl "http://localhost/api/api.php?endpoint=trips&from=1&to=2&date=2025-01-15"

# 5. اختبار إنشاء حجز
curl -X POST http://localhost/api/api.php?endpoint=booking \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "trip_id": 1,
    "manager_name": "أحمد محمد",
    "manager_email": "ahmad@example.com",
    "manager_phone": "0501234567",
    "manager_national_id": "1234567890",
    "total_passengers": 2,
    "seats": ["A1", "A2"],
    "passengers": [
      {
        "full_name": "أحمد محمد",
        "national_id": "1234567890",
        "seat_number": "A1"
      },
      {
        "full_name": "فاطمة أحمد",
        "national_id": "0987654321",
        "seat_number": "A2"
      }
    ]
  }'
```

---

### الخطوة 9: نشر التطبيق

#### 1. رفع الملفات للخادم

```bash
# باستخدام rsync
rsync -avz --exclude 'node_modules' \
  ./ user@yourserver.com:/var/www/bus-booking/

# أو باستخدام FTP/SFTP
# قم برفع المجلدات: api, src, public, dist
```

#### 2. إعداد الخادم

```bash
# على الخادم
cd /var/www/bus-booking

# تعيين الصلاحيات
sudo chown -R www-data:www-data .
sudo chmod -R 755 .

# إعادة تشغيل خادم الويب
sudo systemctl restart apache2
# أو
sudo systemctl restart nginx
```

---

## 🔒 نقاط الأمان المهمة

### 1. تأمين ملف config.php

```php
// api/config.php
<?php
// منع الوصول المباشر
if (!defined('API_ACCESS')) {
    http_response_code(403);
    die('Access Denied');
}
```

### 2. التحقق من المدخلات

```php
// استخدم PDO prepared statements دائماً
$stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
```

### 3. تشفير كلمات المرور

```php
// استخدم password_hash و password_verify
$hash = password_hash($password, PASSWORD_BCRYPT);
$valid = password_verify($password, $hash);
```

### 4. HTTPS

```bash
# تثبيت Let's Encrypt
sudo apt install certbot python3-certbot-apache
sudo certbot --apache -d yourdomain.com
```

---

## 📋 قائمة المراجعة

- [ ] إعداد MySQL وإنشاء قاعدة البيانات
- [ ] تصدير البيانات من Supabase
- [ ] تحويل واستيراد البيانات إلى MySQL
- [ ] تحديث جميع ملفات JavaScript
- [ ] تحديث ملف .env
- [ ] حذف تبعيات Supabase
- [ ] اختبار جميع الوظائف
- [ ] إعداد النسخ الاحتياطي التلقائي
- [ ] تأمين API endpoints
- [ ] تفعيل HTTPS
- [ ] مراقبة الأداء

---

## 🆘 استكشاف الأخطاء

### المشكلة: "CORS error"

**الحل:** تحقق من إعدادات CORS في config.php:

```php
define('ALLOWED_ORIGINS', [
    'http://localhost:5173',
    'https://yourdomain.com'
]);
```

### المشكلة: "Unauthorized"

**الحل:** تحقق من التوكن في localStorage:

```javascript
// في console المتصفح
console.log(localStorage.getItem('auth_token'));
```

### المشكلة: "Database connection failed"

**الحل:** تحقق من إعدادات قاعدة البيانات في config.php ومن تشغيل MySQL.

---

## 📚 الموارد

- [دليل تثبيت MySQL](MYSQL_SETUP_GUIDE.md)
- [وثائق PHP PDO](https://www.php.net/manual/en/book.pdo.php)
- [أمان MySQL](https://dev.mysql.com/doc/refman/8.0/en/security.html)

---

**🎉 تم الترحيل بنجاح!**
