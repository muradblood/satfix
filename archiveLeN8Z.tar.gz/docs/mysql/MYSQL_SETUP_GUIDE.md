# دليل تثبيت وإعداد MySQL

هذا الدليل يشرح كيفية إعداد قاعدة بيانات MySQL للنظام.

## المتطلبات

### البرامج المطلوبة
- **MySQL Server** 8.0 أو أحدث
- **PHP** 7.4 أو أحدث
- **خادم ويب** (Apache أو Nginx)
- **Composer** (اختياري للتبعيات)

### الإضافات المطلوبة لـ PHP
```bash
php-mysqli
php-pdo
php-pdo_mysql
php-json
php-mbstring
php-curl
```

---

## الخطوة 1: تثبيت MySQL

### على Ubuntu/Debian
```bash
sudo apt update
sudo apt install mysql-server
sudo mysql_secure_installation
```

### على CentOS/RHEL
```bash
sudo yum install mysql-server
sudo systemctl start mysqld
sudo mysql_secure_installation
```

### على Windows
1. قم بتحميل MySQL من [الموقع الرسمي](https://dev.mysql.com/downloads/mysql/)
2. قم بتشغيل المثبت واتبع التعليمات
3. اختر كلمة مرور قوية لـ root

### على macOS
```bash
brew install mysql
brew services start mysql
mysql_secure_installation
```

---

## الخطوة 2: إنشاء قاعدة البيانات

### الطريقة 1: باستخدام سطر الأوامر

```bash
# تسجيل الدخول لـ MySQL
mysql -u root -p

# إنشاء قاعدة البيانات
CREATE DATABASE bus_booking_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# إنشاء مستخدم جديد
CREATE USER 'bus_admin'@'localhost' IDENTIFIED BY 'your_secure_password';

# منح الصلاحيات
GRANT ALL PRIVILEGES ON bus_booking_system.* TO 'bus_admin'@'localhost';
FLUSH PRIVILEGES;

# الخروج
EXIT;
```

### الطريقة 2: باستخدام ملف schema.sql

```bash
# استيراد الهيكل
mysql -u root -p < database/schema.sql
```

---

## الخطوة 3: إعداد ملف config.php

قم بتحديث الملف `api/config.php` بمعلومات قاعدة البيانات:

```php
// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'bus_booking_system');
define('DB_USER', 'bus_admin');
define('DB_PASS', 'your_secure_password');
define('DB_CHARSET', 'utf8mb4');

// مفتاح سري للتشفير (غيّره في الإنتاج!)
define('JWT_SECRET', 'اختر-مفتاح-عشوائي-قوي-هنا');
```

---

## الخطوة 4: إعداد خادم الويب

### Apache

#### 1. تمكين mod_rewrite
```bash
sudo a2enmod rewrite
sudo systemctl restart apache2
```

#### 2. إنشاء Virtual Host

أنشئ ملف `/etc/apache2/sites-available/bus-booking.conf`:

```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    DocumentRoot /var/www/bus-booking

    <Directory /var/www/bus-booking>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/bus-booking-error.log
    CustomLog ${APACHE_LOG_DIR}/bus-booking-access.log combined
</VirtualHost>
```

#### 3. تفعيل الموقع
```bash
sudo a2ensite bus-booking
sudo systemctl reload apache2
```

#### 4. إنشاء ملف .htaccess

أنشئ ملف `.htaccess` في مجلد `api/`:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteBase /api/

    # إعادة توجيه جميع الطلبات لـ api.php
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^(.*)$ api.php?endpoint=$1 [QSA,L]
</IfModule>

# منع الوصول المباشر للملفات الحساسة
<FilesMatch "^(config|auth)\.php$">
    Order Allow,Deny
    Deny from all
</FilesMatch>
```

### Nginx

أضف هذا إلى ملف إعدادات Nginx:

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/bus-booking;
    index index.html;

    # معالجة طلبات API
    location /api/ {
        try_files $uri $uri/ /api/api.php?$query_string;

        location ~ \.php$ {
            fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
            fastcgi_index index.php;
            fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
            include fastcgi_params;
        }
    }

    # منع الوصول لملفات حساسة
    location ~ /(config|auth)\.php$ {
        deny all;
        return 404;
    }
}
```

---

## الخطوة 5: إعداد الصلاحيات

```bash
# تعيين المالك
sudo chown -R www-data:www-data /var/www/bus-booking

# تعيين الصلاحيات
sudo chmod -R 755 /var/www/bus-booking
sudo chmod -R 775 /var/www/bus-booking/logs
```

---

## الخطوة 6: اختبار التثبيت

### 1. اختبار الاتصال بقاعدة البيانات

أنشئ ملف `test-db.php`:

```php
<?php
define('API_ACCESS', true);
require_once 'api/config.php';

try {
    $db = getDBConnection();
    echo "✅ الاتصال بقاعدة البيانات ناجح!\n";

    $stmt = $db->query("SELECT COUNT(*) as count FROM stations");
    $result = $stmt->fetch();
    echo "عدد المحطات: " . $result['count'] . "\n";

} catch (Exception $e) {
    echo "❌ خطأ في الاتصال: " . $e->getMessage() . "\n";
}
```

قم بتشغيله:
```bash
php test-db.php
```

### 2. اختبار API

```bash
# اختبار الحصول على المحطات
curl http://localhost/api/api.php?endpoint=stations

# اختبار التسجيل
curl -X POST http://localhost/api/auth.php?action=register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"123456","full_name":"Test User"}'

# اختبار تسجيل الدخول
curl -X POST http://localhost/api/auth.php?action=login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"123456"}'
```

---

## الخطوة 7: النسخ الاحتياطي

### نسخة احتياطية يدوية

```bash
# نسخ احتياطي كامل
mysqldump -u root -p bus_booking_system > backup_$(date +%Y%m%d).sql

# نسخ احتياطي مضغوط
mysqldump -u root -p bus_booking_system | gzip > backup_$(date +%Y%m%d).sql.gz
```

### نسخة احتياطية تلقائية

أنشئ ملف `/etc/cron.daily/mysql-backup.sh`:

```bash
#!/bin/bash
BACKUP_DIR="/var/backups/mysql"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR
mysqldump -u root -pYOUR_PASSWORD bus_booking_system | gzip > $BACKUP_DIR/backup_$DATE.sql.gz

# حذف النسخ القديمة (أقدم من 30 يوم)
find $BACKUP_DIR -type f -mtime +30 -delete
```

اجعله قابلاً للتنفيذ:
```bash
chmod +x /etc/cron.daily/mysql-backup.sh
```

---

## استكشاف الأخطاء

### خطأ: "Access denied for user"
```bash
# تحقق من اسم المستخدم وكلمة المرور في config.php
# أو أعد تعيين كلمة المرور
mysql -u root -p
ALTER USER 'bus_admin'@'localhost' IDENTIFIED BY 'new_password';
FLUSH PRIVILEGES;
```

### خطأ: "Can't connect to MySQL server"
```bash
# تحقق من تشغيل MySQL
sudo systemctl status mysql

# إذا لم يكن يعمل، قم بتشغيله
sudo systemctl start mysql
```

### خطأ: "Table doesn't exist"
```bash
# أعد استيراد schema.sql
mysql -u root -p bus_booking_system < database/schema.sql
```

### خطأ: "Access forbidden"
```bash
# تحقق من صلاحيات المستخدم
SHOW GRANTS FOR 'bus_admin'@'localhost';

# إذا لزم الأمر، أعد منح الصلاحيات
GRANT ALL PRIVILEGES ON bus_booking_system.* TO 'bus_admin'@'localhost';
FLUSH PRIVILEGES;
```

---

## نصائح للأمان

### 1. تأمين MySQL
```bash
# تشغيل سكربت الأمان
mysql_secure_installation
```

### 2. استخدام جدار ناري
```bash
# السماح فقط بالاتصالات المحلية
sudo ufw allow from 127.0.0.1 to any port 3306
```

### 3. تشفير الاتصالات
قم بتمكين SSL/TLS في MySQL:

```sql
-- في ملف my.cnf
[mysqld]
require_secure_transport = ON
ssl-ca=/path/to/ca.pem
ssl-cert=/path/to/server-cert.pem
ssl-key=/path/to/server-key.pem
```

### 4. تغيير المفاتيح السرية
قم بتغيير `JWT_SECRET` في config.php إلى قيمة عشوائية قوية:

```bash
# إنشاء مفتاح عشوائي
openssl rand -base64 32
```

---

## الصيانة

### تحسين الجداول
```sql
OPTIMIZE TABLE users, bookings, trips;
```

### تحليل الأداء
```sql
-- تحليل استعلام
EXPLAIN SELECT * FROM trips WHERE departure_time > NOW();

-- إحصائيات الجداول
ANALYZE TABLE trips;
```

### مراقبة الحجم
```sql
SELECT
    table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb
FROM information_schema.TABLES
WHERE table_schema = 'bus_booking_system'
ORDER BY size_mb DESC;
```

---

## الموارد الإضافية

- [وثائق MySQL الرسمية](https://dev.mysql.com/doc/)
- [وثائق PHP PDO](https://www.php.net/manual/en/book.pdo.php)
- [أفضل ممارسات الأمان](https://dev.mysql.com/doc/refman/8.0/en/security.html)

---

**🎉 تهانينا! قاعدة البيانات جاهزة للاستخدام**
