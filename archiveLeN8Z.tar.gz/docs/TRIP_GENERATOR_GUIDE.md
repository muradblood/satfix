# دليل نظام توليد الرحلات التلقائي

نظام متقدم لتوليد رحلات تلقائية من وإلى جميع المحطات في أي تاريخ.

---

## ✨ المميزات

### 🎯 التوليد المرن
- ✅ توليد رحلات لفترة مخصصة
- ✅ توليد رحلات لشهر كامل
- ✅ توليد رحلات للأسبوع القادم
- ✅ توليد رحلات ليوم محدد
- ✅ تحديد عدد الرحلات لكل مسار

### 🤖 التشغيل التلقائي
- ✅ توليد تلقائي يومي
- ✅ تنظيف تلقائي للرحلات القديمة
- ✅ جدولة باستخدام MySQL Events

### 📊 الإحصائيات
- ✅ عرض إحصائيات شاملة
- ✅ تتبع الرحلات المتاحة
- ✅ مراقبة المقاعد

---

## 🗂️ الملفات

```
database/trip-generator.sql     # دوال SQL للتوليد
api/trip-generator.php          # API endpoints
admin/trip-generator.html       # واجهة إدارية
```

---

## 🚀 البدء السريع

### 1. تثبيت دوال SQL

```bash
mysql -u root -p bus_booking_system < database/trip-generator.sql
```

### 2. الوصول للواجهة الإدارية

```
افتح: https://yourdomain.com/admin/trip-generator.html
```

### 3. توليد رحلات

اختر أحد الخيارات:
- **أسبوعي**: رحلات للأيام السبعة القادمة
- **شهري**: رحلات لشهر كامل
- **يومي**: رحلات ليوم محدد
- **مخصص**: رحلات لفترة محددة

---

## 📡 API Endpoints

### توليد رحلات أسبوعية

```bash
POST /api/trip-generator.php?action=generate-weekly
Authorization: Bearer {token}
Content-Type: application/json

{
  "trips_per_route": 3
}
```

### توليد رحلات شهرية

```bash
POST /api/trip-generator.php?action=generate-monthly
Authorization: Bearer {token}
Content-Type: application/json

{
  "month": 1,
  "year": 2025,
  "trips_per_route": 3
}
```

### توليد رحلات يومية

```bash
POST /api/trip-generator.php?action=generate-daily
Authorization: Bearer {token}
Content-Type: application/json

{
  "date": "2025-01-15",
  "trips_per_route": 3
}
```

### توليد رحلات لفترة مخصصة

```bash
POST /api/trip-generator.php?action=generate
Authorization: Bearer {token}
Content-Type: application/json

{
  "start_date": "2025-01-01",
  "end_date": "2025-01-31",
  "trips_per_route": 3
}
```

### تنظيف الرحلات القديمة

```bash
POST /api/trip-generator.php?action=cleanup
Authorization: Bearer {token}
Content-Type: application/json

{
  "days_old": 7
}
```

### حذف جميع الرحلات المجدولة

```bash
POST /api/trip-generator.php?action=delete-all
Authorization: Bearer {token}
```

### تفعيل/تعطيل التوليد التلقائي

```bash
POST /api/trip-generator.php?action=toggle-auto
Authorization: Bearer {token}
Content-Type: application/json

{
  "enabled": true
}
```

### الحصول على الإحصائيات

```bash
GET /api/trip-generator.php?action=statistics
Authorization: Bearer {token}
```

### الحصول على الملخص

```bash
GET /api/trip-generator.php?action=summary
Authorization: Bearer {token}
```

---

## 🛠️ دوال SQL

### generate_trips

توليد رحلات لفترة محددة:

```sql
CALL generate_trips('2025-01-01', '2025-01-31', 3);
```

**المعاملات:**
- `start_date`: تاريخ البداية
- `end_date`: تاريخ النهاية
- `trips_per_route`: عدد الرحلات لكل مسار يومياً

### generate_monthly_trips

توليد رحلات لشهر كامل:

```sql
CALL generate_monthly_trips(1, 2025, 3);
```

**المعاملات:**
- `target_month`: رقم الشهر (1-12)
- `target_year`: السنة
- `trips_per_route`: عدد الرحلات لكل مسار يومياً

### generate_weekly_trips

توليد رحلات للأسبوع القادم:

```sql
CALL generate_weekly_trips(3);
```

**المعاملات:**
- `trips_per_route`: عدد الرحلات لكل مسار يومياً

### generate_daily_trips

توليد رحلات ليوم محدد:

```sql
CALL generate_daily_trips('2025-01-15', 3);
```

**المعاملات:**
- `target_date`: التاريخ المستهدف
- `trips_per_route`: عدد الرحلات لكل مسار

### cleanup_old_trips

حذف الرحلات القديمة:

```sql
CALL cleanup_old_trips(7);
```

**المعاملات:**
- `days_old`: عدد الأيام (يحذف الرحلات الأقدم من هذا العدد)

### get_trip_statistics

الحصول على إحصائيات مفصلة:

```sql
CALL get_trip_statistics();
```

---

## ⚙️ التوليد التلقائي

### تفعيل التوليد التلقائي

```sql
SET GLOBAL event_scheduler = ON;
```

### تعطيل التوليد التلقائي

```sql
SET GLOBAL event_scheduler = OFF;
```

### عرض الأحداث المجدولة

```sql
SHOW EVENTS;
```

### الحدث التلقائي

يتم تشغيل الحدث `daily_trip_generation` يومياً ويقوم بـ:

1. توليد رحلات للأسبوع القادم (3 رحلات لكل مسار)
2. تنظيف الرحلات القديمة (أقدم من 7 أيام)

---

## 📊 كيفية عمل النظام

### 1. توليد المسارات

يقوم النظام بإنشاء رحلات لجميع المسارات الممكنة بين المحطات:

```
الرياض → جدة
جدة → الرياض
الرياض → الدمام
الدمام → الرياض
...
```

### 2. توزيع الأوقات

يتم توزيع الرحلات على مدار اليوم:

- **3 رحلات يومياً**: 06:00، 12:00، 18:00
- **5 رحلات يومياً**: 06:00، 09:36، 13:12، 16:48، 20:24

### 3. تخصيص الباصات

يتم اختيار باص عشوائي لكل رحلة من الباصات المتاحة.

### 4. حساب الأسعار

السعر الأساسي = 100 + (المدة × 20) + قيمة عشوائية

**مثال:**
- مدة 6 ساعات: 100 + (6 × 20) + 50 = 270 ريال

### 5. رحلات الذهاب والعودة

لكل رحلة ذهاب، يتم إنشاء رحلة عودة تلقائياً بعد ساعتين.

---

## 💡 أمثلة عملية

### مثال 1: توليد رحلات لشهر يناير 2025

```sql
CALL generate_monthly_trips(1, 2025, 3);
```

**النتيجة:**
- عدد المسارات: 28 (8 محطات × 7 / 2)
- رحلات يومياً: 28 × 3 × 2 = 168 رحلة
- إجمالي شهر يناير: 168 × 31 = 5,208 رحلة

### مثال 2: توليد رحلات للأسبوع

```sql
CALL generate_weekly_trips(5);
```

**النتيجة:**
- عدد المسارات: 28
- رحلات يومياً: 28 × 5 × 2 = 280 رحلة
- إجمالي أسبوع: 280 × 7 = 1,960 رحلة

### مثال 3: توليد رحلات ليوم محدد

```sql
CALL generate_daily_trips('2025-01-15', 4);
```

**النتيجة:**
- عدد المسارات: 28
- رحلات اليوم: 28 × 4 × 2 = 224 رحلة

---

## 🔧 التخصيص

### تعديل عدد الرحلات الافتراضي

في ملف `trip-generator.sql`:

```sql
-- تغيير من 3 إلى 5 رحلات
CALL generate_weekly_trips(5);
```

### تعديل فترة التنظيف

```sql
-- تغيير من 7 إلى 14 يوم
CALL cleanup_old_trips(14);
```

### تعديل جدولة الحدث التلقائي

```sql
-- تشغيل كل 12 ساعة بدلاً من يومياً
DROP EVENT daily_trip_generation;

CREATE EVENT daily_trip_generation
ON SCHEDULE EVERY 12 HOUR
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    CALL generate_weekly_trips(3);
    CALL cleanup_old_trips(7);
END;
```

---

## 📈 مراقبة الأداء

### عرض إحصائيات الرحلات

```sql
SELECT
    COUNT(*) as total_trips,
    COUNT(CASE WHEN trip_status = 'scheduled' THEN 1 END) as scheduled,
    COUNT(DISTINCT from_station_id) as stations_covered,
    SUM(available_seats) as total_seats,
    MIN(departure_time) as first_trip,
    MAX(departure_time) as last_trip
FROM trips
WHERE departure_time >= CURDATE();
```

### عرض الرحلات حسب المسار

```sql
SELECT
    sf.name_ar as من,
    st.name_ar as إلى,
    COUNT(*) as عدد_الرحلات,
    AVG(base_price) as متوسط_السعر
FROM trips t
JOIN stations sf ON t.from_station_id = sf.id
JOIN stations st ON t.to_station_id = st.id
WHERE t.trip_status = 'scheduled'
GROUP BY sf.name_ar, st.name_ar
ORDER BY عدد_الرحلات DESC;
```

---

## 🆘 استكشاف الأخطاء

### المشكلة: "Event scheduler is OFF"

**الحل:**
```sql
SET GLOBAL event_scheduler = ON;
```

### المشكلة: "Duplicate entry for key 'trip_number'"

**الحل:** حذف الرحلات المكررة أولاً:
```sql
DELETE FROM trips WHERE trip_status = 'scheduled';
CALL generate_weekly_trips(3);
```

### المشكلة: لا يتم توليد رحلات

**التحقق:**
```sql
-- التأكد من وجود محطات نشطة
SELECT COUNT(*) FROM stations WHERE is_active = TRUE;

-- التأكد من وجود باصات نشطة
SELECT COUNT(*) FROM buses WHERE is_active = TRUE;
```

### المشكلة: الرحلات غير متوازنة

**الحل:** إضافة المزيد من الباصات:
```sql
INSERT INTO buses (bus_number, bus_type, capacity, is_active)
VALUES ('BUS-006', 'standard', 50, TRUE);
```

---

## 📋 قائمة المراجعة

قبل استخدام النظام:

- [ ] تثبيت دوال SQL
- [ ] إضافة محطات كافية (8 محطات على الأقل)
- [ ] إضافة باصات كافية (5 باصات على الأقل)
- [ ] تفعيل event scheduler
- [ ] منح صلاحيات المسؤول

---

## 🎯 أفضل الممارسات

1. **التوليد المنتظم**
   - استخدم التوليد التلقائي اليومي
   - راقب الإحصائيات بانتظام

2. **التنظيف الدوري**
   - نظّف الرحلات القديمة أسبوعياً
   - احذف الرحلات الملغاة

3. **التخطيط المسبق**
   - ولّد رحلات للشهر القادم مسبقاً
   - راجع الأسعار دورياً

4. **المراقبة**
   - راقب استخدام المقاعد
   - تتبع الرحلات الأكثر طلباً

---

## 📚 الموارد

- [دليل MySQL Events](https://dev.mysql.com/doc/refman/8.0/en/events.html)
- [دليل Stored Procedures](https://dev.mysql.com/doc/refman/8.0/en/stored-programs.html)
- [دليل النظام الرئيسي](../MYSQL_README.md)

---

**🎉 استمتع بنظام توليد الرحلات!**
