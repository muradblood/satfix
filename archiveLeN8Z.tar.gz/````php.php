````php
<?php
// ...existing code...
?>
<!doctype html>
<html lang="ar">
<head>
    <!-- ...existing head... -->
</head>
<body>
    <div class="container">
        <!-- ...existing markup... -->
        ...existing code...
    </div>

    { /* تمت إضافة استدعاءات ملفات الجافاسكربت المنفصلة */ }
    <script src="js/search.js"></script>
    <script src="js/select.js"></script>
    <script src="script.js"></script>
</body>
</html>
````