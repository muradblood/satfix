# 🚀 خطوات النشر خطوة بخطوة

دليل مختصر ومباشر للنشر على خادمك (46.28.44.184).

---

## ✅ الملفات جاهزة

- ✅ `deploy_ready.tar.gz` (76 KB) - جاهز للرفع
- ✅ `upload_to_server.sh` - سكربت رفع تلقائي
- ✅ `COMMANDS_ON_SERVER.sh` - أوامر الفحص على الخادم

---

## 📤 الخطوة 1: رفع الملفات (من جهازك)

### الطريقة السهلة - السكربت التلقائي:

```bash
./upload_to_server.sh
```

سيُطلب منك كلمة المرور، أدخلها وانتظر.

### الطريقة اليدوية:

```bash
scp deploy_ready.tar.gz fastpanel@46.28.44.184:/tmp/
```

---

## 🔌 الخطوة 2: الاتصال بالخادم

```bash
ssh fastpanel@46.28.44.184
```

أدخل كلمة المرور.

---

## 🔍 الخطوة 3: فحص الخادم

بعد الاتصال، نفذ:

```bash
# فك الضغط
cd /tmp
tar -xzf deploy_ready.tar.gz

# تشغيل سكربت الفحص
bash deploy_ready/COMMANDS_ON_SERVER.sh
```

أو يدوياً:

```bash
# معلومات سريعة
cat /etc/os-release | grep NAME
php -v
mysql --version
ls -la /var/www/
```

---

## 📋 الخطوة 4: حسب نتائج الفحص

### إذا كان لديك `/var/www/`:

```bash
# نقل الملفات
sudo mkdir -p /var/www/bus-booking
sudo cp -r deploy_ready/deploy_ready/* /var/www/bus-booking/
sudo chown -R www-data:www-data /var/www/bus-booking
sudo chmod -R 755 /var/www/bus-booking
```

### إذا كان لديك `~/domains/`:

```bash
# نقل الملفات
mkdir -p ~/domains/bus-booking
cp -r deploy_ready/deploy_ready/* ~/domains/bus-booking/
```

### إذا كان لديك `~/public_html/`:

```bash
# نقل الملفات
cp -r deploy_ready/deploy_ready/* ~/public_html/
```

---

## 🗄️ الخطوة 5: إعداد قاعدة البيانات

```bash
# تسجيل الدخول لـ MySQL
mysql -u root -p
# أو
mysql -u fastpanel -p
```

داخل MySQL:

```sql
-- إنشاء قاعدة البيانات
CREATE DATABASE bus_booking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- إنشاء مستخدم
CREATE USER 'bus_admin'@'localhost' IDENTIFIED BY 'كلمة_مرور_قوية_123';

-- منح الصلاحيات
GRANT ALL PRIVILEGES ON bus_booking.* TO 'bus_admin'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

استيراد الجداول:

```bash
# حدد المسار الصحيح حسب الخطوة 4
mysql -u bus_admin -p bus_booking < /var/www/bus-booking/database/schema.sql
mysql -u bus_admin -p bus_booking < /var/www/bus-booking/database/generate_trips.sql
```

---

## ⚙️ الخطوة 6: تحديث الإعدادات

```bash
# حدد المسار الصحيح
nano /var/www/bus-booking/api/config.php
```

عدّل:

```php
define('DB_NAME', 'bus_booking');
define('DB_USER', 'bus_admin');
define('DB_PASS', 'كلمة_المرور_التي_أنشأتها');

define('JWT_SECRET', 'غير_هذا_لمفتاح_عشوائي_طويل_جداً');
define('DEBUG_MODE', false);
```

احفظ: `Ctrl+O` ثم `Enter` ثم `Ctrl+X`

---

## 🌐 الخطوة 7: اختبار

### اختبار API:

```bash
curl http://46.28.44.184/api/api.php?endpoint=stations
```

### في المتصفح:

```
http://46.28.44.184
http://46.28.44.184/admin/login.html
```

---

## 🆘 مشاكل شائعة

### "Permission denied"

```bash
sudo chown -R www-data:www-data /var/www/bus-booking
sudo chmod -R 755 /var/www/bus-booking
```

### "404 Not Found"

```bash
# تحقق من DocumentRoot في Apache
cat /etc/apache2/sites-enabled/*.conf | grep DocumentRoot
```

### "Access denied for user"

```bash
# تحقق من config.php
cat /var/www/bus-booking/api/config.php | grep DB_
```

---

## 📞 الدعم

إذا واجهت مشكلة:

1. انسخ رسالة الخطأ
2. أرسل نتائج `COMMANDS_ON_SERVER.sh`
3. راجع [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)

---

## ✨ نصائح

### للتحديثات المستقبلية:

```bash
# من جهازك
rsync -avz --exclude 'node_modules' \
  dist/ api/ database/ \
  fastpanel@46.28.44.184:/var/www/bus-booking/
```

### للنسخ الاحتياطي:

```bash
# على الخادم
mysqldump -u bus_admin -p bus_booking | gzip > backup_$(date +%Y%m%d).sql.gz
```

---

## 🎯 الملخص السريع

```bash
# 1. من جهازك - رفع
./upload_to_server.sh

# 2. على الخادم - فحص
ssh fastpanel@46.28.44.184
cd /tmp && tar -xzf deploy_ready.tar.gz
bash deploy_ready/COMMANDS_ON_SERVER.sh

# 3. نقل الملفات
sudo cp -r deploy_ready/deploy_ready/* /var/www/bus-booking/

# 4. قاعدة البيانات
mysql -u root -p < database/schema.sql

# 5. تحديث config.php
nano api/config.php

# 6. اختبار
curl http://46.28.44.184/api/api.php?endpoint=stations
```

---

**✨ بالتوفيق! 🚀**
