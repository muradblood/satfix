# طريقة النشر على الخادم - خطوة بخطوة

دليل مفصل لنشر نظام حجز الباصات على خادم Ubuntu 24.04

---

## 📋 المتطلبات الأساسية

### 1. الخادم
- Ubuntu 24.04 LTS (أو 22.04 / 20.04)
- 2 GB RAM (على الأقل)
- 20 GB مساحة تخزين
- صلاحيات root أو sudo

### 2. الوصول للخادم
- IP الخادم أو اسم النطاق
- اسم مستخدم وكلمة مرور
- SSH Port (عادةً 22)

---

## 🔐 الخطوة 1: الاتصال بالخادم

### من Windows (استخدم PuTTY أو CMD/PowerShell):

```powershell
# باستخدام CMD/PowerShell
ssh username@your-server-ip

# مثال
ssh root@192.168.1.100
```

### من Mac/Linux:

```bash
ssh username@your-server-ip

# مثال
ssh root@192.168.1.100
```

### إذا كان لديك مفتاح SSH:

```bash
ssh -i /path/to/key.pem username@your-server-ip
```

---

## 📦 الخطوة 2: تحديث النظام

```bash
# تحديث قوائم الحزم
sudo apt update

# ترقية الحزم الموجودة
sudo apt upgrade -y

# تنظيف الحزم القديمة
sudo apt autoremove -y
```

**الوقت المتوقع**: 2-5 دقائق

---

## 🌐 الخطوة 3: تثبيت Apache

```bash
# تثبيت Apache
sudo apt install apache2 -y

# التحقق من التثبيت
apache2 -v

# يجب أن ترى: Server version: Apache/2.4.xx

# تفعيل Apache عند بدء التشغيل
sudo systemctl enable apache2

# تشغيل Apache
sudo systemctl start apache2

# التحقق من الحالة
sudo systemctl status apache2
```

**الاختبار**: افتح `http://your-server-ip` في المتصفح - يجب أن ترى صفحة Apache الافتراضية.

---

## 🐘 الخطوة 4: تثبيت PHP

```bash
# تثبيت PHP والإضافات المطلوبة
sudo apt install php8.1 php8.1-fpm php8.1-mysql php8.1-mbstring \
  php8.1-curl php8.1-xml php8.1-json php8.1-zip -y

# التحقق من نسخة PHP
php -v

# يجب أن ترى: PHP 8.1.xx

# تفعيل PHP-FPM
sudo systemctl enable php8.1-fpm
sudo systemctl start php8.1-fpm

# تفعيل mod_rewrite في Apache
sudo a2enmod rewrite

# تفعيل PHP-FPM في Apache
sudo a2enmod proxy_fcgi setenvif
sudo a2enconf php8.1-fpm

# إعادة تشغيل Apache
sudo systemctl restart apache2
```

**الاختبار**:

```bash
# إنشاء ملف اختبار
echo "<?php phpinfo(); ?>" | sudo tee /var/www/html/info.php

# افتح في المتصفح
# http://your-server-ip/info.php

# احذف الملف بعد الاختبار (أمان)
sudo rm /var/www/html/info.php
```

---

## 🗄️ الخطوة 5: تثبيت MySQL

```bash
# تثبيت MySQL
sudo apt install mysql-server -y

# تشغيل MySQL
sudo systemctl start mysql
sudo systemctl enable mysql

# تأمين MySQL
sudo mysql_secure_installation
```

**أثناء mysql_secure_installation ستُسأل:**

```
1. Would you like to setup VALIDATE PASSWORD component?
   → اختر Y (نعم)

2. Please select password strength (0=LOW, 1=MEDIUM, 2=STRONG)
   → اختر 1 أو 2

3. Remove anonymous users?
   → اختر Y (نعم)

4. Disallow root login remotely?
   → اختر Y (نعم)

5. Remove test database?
   → اختر Y (نعم)

6. Reload privilege tables?
   → اختر Y (نعم)
```

---

## 🎲 الخطوة 6: إعداد قاعدة البيانات

```bash
# تسجيل الدخول لـ MySQL
sudo mysql
```

**داخل MySQL**، نفّذ الأوامر التالية:

```sql
-- إنشاء قاعدة البيانات
CREATE DATABASE bus_booking_system
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

-- إنشاء مستخدم (غيّر كلمة المرور!)
CREATE USER 'bus_admin'@'localhost'
IDENTIFIED BY 'كلمة_مرور_قوية_جداً_هنا';

-- منح الصلاحيات
GRANT ALL PRIVILEGES ON bus_booking_system.*
TO 'bus_admin'@'localhost';

-- تطبيق التغييرات
FLUSH PRIVILEGES;

-- الخروج
EXIT;
```

**اختبار الاتصال**:

```bash
mysql -u bus_admin -p bus_booking_system

# أدخل كلمة المرور
# إذا نجحت، اكتب:
EXIT;
```

---

## 📁 الخطوة 7: رفع ملفات المشروع

### الطريقة 1: باستخدام SCP (من جهازك المحلي)

```bash
# من جهازك المحلي (Windows/Mac/Linux)
cd /path/to/your/project

# ضغط الملفات أولاً
tar -czf bus-booking.tar.gz dist/ api/ database/ public/ admin/ .htaccess

# رفع الملف
scp bus-booking.tar.gz username@your-server-ip:/tmp/

# على الخادم
cd /tmp
sudo tar -xzf bus-booking.tar.gz -C /var/www/
sudo mv /var/www/dist /var/www/bus-booking-system
```

### الطريقة 2: باستخدام Git (موصى بها)

```bash
# على الخادم
cd /var/www

# استنساخ المشروع
sudo git clone https://github.com/yourusername/bus-booking-system.git

# أو إذا كان مستودع خاص
sudo git clone https://username:token@github.com/yourusername/bus-booking-system.git
```

### الطريقة 3: باستخدام SFTP (FileZilla)

1. افتح FileZilla
2. Host: `sftp://your-server-ip`
3. Username: `your-username`
4. Password: `your-password`
5. Port: `22`
6. اسحب المجلدات إلى `/var/www/bus-booking-system/`

### الطريقة 4: رفع يدوي مباشر

```bash
# على الخادم
sudo mkdir -p /var/www/bus-booking-system

# ثم استخدم SFTP لرفع المجلدات:
/var/www/bus-booking-system/
├── dist/
├── api/
├── database/
├── public/
├── admin/
└── .htaccess
```

---

## 🔑 الخطوة 8: تعيين الصلاحيات

```bash
# تغيير المالك إلى Apache
sudo chown -R www-data:www-data /var/www/bus-booking-system

# تعيين صلاحيات المجلدات
sudo find /var/www/bus-booking-system -type d -exec chmod 755 {} \;

# تعيين صلاحيات الملفات
sudo find /var/www/bus-booking-system -type f -exec chmod 644 {} \;

# صلاحيات خاصة لـ config.php (أمان إضافي)
sudo chmod 600 /var/www/bus-booking-system/api/config.php

# إنشاء مجلد logs
sudo mkdir -p /var/www/bus-booking-system/logs
sudo chmod 775 /var/www/bus-booking-system/logs
sudo chown www-data:www-data /var/www/bus-booking-system/logs
```

---

## ⚙️ الخطوة 9: تكوين config.php

```bash
# فتح الملف للتعديل
sudo nano /var/www/bus-booking-system/api/config.php
```

**عدّل القيم التالية**:

```php
<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'bus_booking_system');
define('DB_USER', 'bus_admin');
define('DB_PASS', 'كلمة_المرور_التي_أنشأتها_في_الخطوة_6');  // ⚠️ هام!

// Security
define('JWT_SECRET', 'مفتاح_عشوائي_قوي_جداً_هنا');  // ⚠️ هام! غيّره!

// Environment
define('DEBUG_MODE', false);  // ⚠️ هام! اجعلها false

// CORS (عدّل حسب نطاقك)
define('ALLOWED_ORIGINS', [
    'http://yourdomain.com',
    'https://yourdomain.com',
    'http://www.yourdomain.com',
    'https://www.yourdomain.com'
]);
```

**حفظ والخروج**: اضغط `Ctrl+O` ثم `Enter` ثم `Ctrl+X`

### 💡 نصيحة: توليد JWT_SECRET قوي

```bash
# على الخادم
openssl rand -base64 64

# انسخ الناتج واستخدمه كـ JWT_SECRET
```

---

## 📊 الخطوة 10: استيراد قاعدة البيانات

```bash
# الانتقال لمجلد المشروع
cd /var/www/bus-booking-system

# استيراد هيكل قاعدة البيانات
mysql -u bus_admin -p bus_booking_system < database/schema.sql

# أدخل كلمة المرور عند الطلب

# استيراد سكربت توليد الرحلات
mysql -u bus_admin -p bus_booking_system < database/generate_trips.sql
```

**التحقق**:

```bash
mysql -u bus_admin -p bus_booking_system -e "SHOW TABLES;"

# يجب أن ترى 14 جدول:
# users, stations, buses, trips, bookings, tickets, ...
```

---

## 🌍 الخطوة 11: إعداد Apache Virtual Host

```bash
# إنشاء ملف التكوين
sudo nano /etc/apache2/sites-available/bus-booking.conf
```

**أضف المحتوى التالي** (غيّر `yourdomain.com`):

```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com

    DocumentRoot /var/www/bus-booking-system

    <Directory /var/www/bus-booking-system>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted

        # PHP-FPM
        <FilesMatch \.php$>
            SetHandler "proxy:unix:/run/php/php8.1-fpm.sock|fcgi://localhost"
        </FilesMatch>
    </Directory>

    # API Directory
    <Directory /var/www/bus-booking-system/api>
        Options -Indexes
        AllowOverride All
        Require all granted
    </Directory>

    # Logs
    ErrorLog ${APACHE_LOG_DIR}/bus-booking-error.log
    CustomLog ${APACHE_LOG_DIR}/bus-booking-access.log combined

    # Security Headers
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set X-Content-Type-Options "nosniff"
</VirtualHost>
```

**حفظ والخروج**: `Ctrl+O` → `Enter` → `Ctrl+X`

```bash
# تفعيل الموقع
sudo a2ensite bus-booking.conf

# تعطيل الموقع الافتراضي
sudo a2dissite 000-default.conf

# تفعيل mod_headers (للـ Security Headers)
sudo a2enmod headers

# اختبار التكوين
sudo apache2ctl configtest

# يجب أن ترى: Syntax OK

# إعادة تشغيل Apache
sudo systemctl restart apache2
```

---

## 🔥 الخطوة 12: إعداد جدار الحماية

```bash
# التحقق من حالة UFW
sudo ufw status

# تفعيل UFW إذا لم يكن مفعلاً
sudo ufw enable

# السماح بـ SSH (مهم جداً!)
sudo ufw allow 22/tcp

# السماح بـ HTTP
sudo ufw allow 80/tcp

# السماح بـ HTTPS (للمستقبل)
sudo ufw allow 443/tcp

# إعادة تحميل UFW
sudo ufw reload

# التحقق من القواعد
sudo ufw status numbered
```

---

## 🧪 الخطوة 13: الاختبار

### 1. اختبار Apache

```bash
sudo systemctl status apache2
# يجب أن ترى: active (running)
```

### 2. اختبار PHP

```bash
php -v
# يجب أن ترى: PHP 8.1.xx
```

### 3. اختبار MySQL

```bash
sudo systemctl status mysql
mysql -u bus_admin -p -e "SELECT VERSION();"
```

### 4. اختبار API

```bash
# من الخادم
curl http://localhost/api/api.php?endpoint=stations

# من المتصفح
http://yourdomain.com/api/api.php?endpoint=stations
```

### 5. اختبار الموقع

افتح في المتصفح:
- الصفحة الرئيسية: `http://yourdomain.com`
- لوحة التحكم: `http://yourdomain.com/admin/login.html`

---

## 🔒 الخطوة 14: إعداد SSL (HTTPS) - اختياري لكن موصى به

```bash
# تثبيت Certbot
sudo apt install certbot python3-certbot-apache -y

# الحصول على شهادة SSL مجانية من Let's Encrypt
sudo certbot --apache -d yourdomain.com -d www.yourdomain.com
```

**أثناء التثبيت ستُسأل**:

```
1. Enter email address:
   → أدخل بريدك الإلكتروني

2. Agree to terms of service?
   → اختر Y (نعم)

3. Share email with EFF?
   → اختر N (لا) أو Y (نعم)

4. Redirect HTTP to HTTPS?
   → اختر 2 (Redirect)
```

**التجديد التلقائي**:

```bash
# اختبار التجديد
sudo certbot renew --dry-run

# إذا نجح، سيتم التجديد تلقائياً كل 90 يوم
```

---

## 🔄 الخطوة 15: إعداد النسخ الاحتياطي التلقائي

```bash
# إنشاء سكربت النسخ الاحتياطي
sudo nano /usr/local/bin/backup-bus-booking.sh
```

**أضف المحتوى**:

```bash
#!/bin/bash

# الإعدادات
BACKUP_DIR="/var/backups/bus-booking"
DB_NAME="bus_booking_system"
DB_USER="bus_admin"
DB_PASS="كلمة_المرور_هنا"
DATE=$(date +%Y%m%d_%H%M%S)

# إنشاء مجلد النسخ الاحتياطي
mkdir -p $BACKUP_DIR

# نسخ قاعدة البيانات
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# نسخ الملفات
tar -czf $BACKUP_DIR/files_$DATE.tar.gz -C /var/www bus-booking-system

# حذف النسخ القديمة (أكثر من 30 يوم)
find $BACKUP_DIR -type f -mtime +30 -delete

echo "✓ Backup completed: $DATE"
```

```bash
# جعل السكربت قابل للتنفيذ
sudo chmod +x /usr/local/bin/backup-bus-booking.sh

# اختبار السكربت
sudo /usr/local/bin/backup-bus-booking.sh

# إضافة مهمة cron (كل يوم الساعة 2 صباحاً)
sudo crontab -e

# أضف هذا السطر في نهاية الملف:
0 2 * * * /usr/local/bin/backup-bus-booking.sh >> /var/log/bus-booking-backup.log 2>&1
```

---

## 📊 الخطوة 16: المراقبة والصيانة

### مراقبة Logs

```bash
# Apache Error Log
sudo tail -f /var/log/apache2/bus-booking-error.log

# Apache Access Log
sudo tail -f /var/log/apache2/bus-booking-access.log

# PHP Error Log
sudo tail -f /var/log/php8.1-fpm.log

# MySQL Error Log
sudo tail -f /var/log/mysql/error.log
```

### فحص الموارد

```bash
# استخدام CPU والذاكرة
htop

# مساحة القرص
df -h

# استخدام الذاكرة
free -h

# حالة الخدمات
sudo systemctl status apache2 php8.1-fpm mysql
```

---

## ✅ قائمة التحقق النهائية

### قبل الإطلاق:

- [ ] Apache يعمل: `sudo systemctl status apache2`
- [ ] PHP يعمل: `php -v`
- [ ] MySQL يعمل: `sudo systemctl status mysql`
- [ ] قاعدة البيانات مستوردة: `mysql -u bus_admin -p -e "USE bus_booking_system; SHOW TABLES;"`
- [ ] config.php محدّث: JWT_SECRET, DB_PASS, DEBUG_MODE=false
- [ ] الصلاحيات صحيحة: `ls -la /var/www/bus-booking-system`
- [ ] Virtual Host مفعّل: `sudo apache2ctl -S`
- [ ] جدار الحماية مكوّن: `sudo ufw status`
- [ ] الموقع يعمل: افتح `http://yourdomain.com`
- [ ] API يعمل: `curl http://yourdomain.com/api/api.php?endpoint=stations`
- [ ] SSL مثبت (اختياري): `https://yourdomain.com`
- [ ] النسخ الاحتياطي مجدول: `sudo crontab -l`

---

## 🆘 استكشاف الأخطاء

### المشكلة: لا يمكن الوصول للموقع

```bash
# تحقق من Apache
sudo systemctl status apache2

# تحقق من الـ firewall
sudo ufw status

# تحقق من الـ Virtual Host
sudo apache2ctl -S

# تحقق من logs
sudo tail -50 /var/log/apache2/error.log
```

### المشكلة: 500 Internal Server Error

```bash
# تحقق من الـ error log
sudo tail -100 /var/log/apache2/bus-booking-error.log

# تحقق من صلاحيات الملفات
ls -la /var/www/bus-booking-system

# تحقق من PHP
sudo systemctl status php8.1-fpm
```

### المشكلة: Database connection failed

```bash
# تحقق من MySQL
sudo systemctl status mysql

# اختبر الاتصال
mysql -u bus_admin -p bus_booking_system

# تحقق من config.php
sudo cat /var/www/bus-booking-system/api/config.php | grep DB_
```

### المشكلة: .htaccess لا يعمل

```bash
# تحقق من mod_rewrite
sudo apache2ctl -M | grep rewrite

# تفعيله
sudo a2enmod rewrite
sudo systemctl restart apache2

# تحقق من AllowOverride
sudo grep -r "AllowOverride" /etc/apache2/sites-available/
```

---

## 🎉 تهانينا!

نظامك الآن منشور ويعمل على الخادم! 🚀

### الخطوات التالية:

1. ✅ سجّل دخول للوحة التحكم: `/admin/setup.html`
2. ✅ أنشئ مستخدم مسؤول
3. ✅ ولّد رحلات تجريبية: `/admin/generate-trips.html`
4. ✅ اختبر الحجز
5. ✅ شارك الموقع مع المستخدمين

---

## 📞 الدعم

إذا واجهت أي مشاكل:

1. راجع logs: `sudo tail -100 /var/log/apache2/bus-booking-error.log`
2. راجع التوثيق: [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)
3. تحقق من المتطلبات: Ubuntu 24.04 + PHP 8.1 + MySQL 8.0

---

**✨ نشر ناجح! موقعك الآن على الإنترنت**
