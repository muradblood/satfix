<?php
session_start();
require_once __DIR__ . '/config.php';

// حماية بسيطة بكلمة مرور
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
    if (hash_equals($ADMIN_PASSWORD, $_POST['password'])) {
      $_SESSION['is_admin'] = true;
      header("Location: admin.php");
      exit;
    } else {
      $err = "كلمة المرور غير صحيحة";
    }
  }
  ?><!doctype html>
  <html lang="ar" dir="rtl">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>تسجيل الدخول | لوحة التحكم</title>
    <link rel="stylesheet" href="https://unpkg.com/@picocss/pico@2.0.6/css/pico.min.css">
  </head>
  <body>
    <main class="container">
      <article>
        <h1>لوحة التحكم</h1>
        <p class="muted">أدخل كلمة المرور للدخول. غيّر كلمة المرور الافتراضية من <code>config.php</code> أو عبر المتغير البيئي <code>ADMIN_PASSWORD</code>.</p>
        <?php if (!empty($err)) echo '<mark>' . htmlspecialchars($err, ENT_QUOTES, "UTF-8") . '</mark>'; ?>
        <form method="post">
          <label>كلمة المرور
            <input type="password" name="password" required>
          </label>
          <button type="submit" class="contrast">دخول</button>
        </form>
      </article>
    </main>
  </body>
  </html><?php
  exit;
}

// أدوات
function read_cards() {
  $f = __DIR__ . '/data/cards.json';
  if (!is_file($f)) return [];
  $json = file_get_contents($f);
  return json_decode($json, true) ?: [];
}
function write_cards($arr) {
  $f = __DIR__ . '/data/cards.json';
  file_put_contents($f, json_encode($arr, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));
}

// تنفيذ الأفعال
$notice = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'save_config') {
    $token = trim($_POST['bot_token'] ?? '');
    $chat  = trim($_POST['chat_id'] ?? '');
    $local = "<?php\n$"."TELEGRAM_BOT_TOKEN_LOCAL = '".addslashes($token)."';\n$"."TELEGRAM_CHAT_ID_LOCAL   = '".addslashes($chat)."';\n";
    file_put_contents(__DIR__ . '/config.local.php', $local);
    $notice = "تم حفظ إعدادات تيليجرام";
  }
  if ($action === 'add_card') {
    $cards = read_cards();
    $cards[] = [
      'id' => uniqid('c_', true),
      'title' => trim($_POST['title'] ?? ''),
      'description' => trim($_POST['description'] ?? ''),
      'image_url' => trim($_POST['image_url'] ?? ''),
      'button_text' => trim($_POST['button_text'] ?? ''),
      'button_url' => trim($_POST['button_url'] ?? ''),
      'visible' => isset($_POST['visible']) ? true : false,
      'order' => intval($_POST['order'] ?? count($cards))
    ];
    write_cards($cards);
    $notice = "تمت إضافة البطاقة";
  }
  if ($action === 'update_card') {
    $cards = read_cards();
    $id = $_POST['id'] ?? '';
    foreach ($cards as &$c) {
      if ($c['id'] === $id) {
        $c['title'] = trim($_POST['title'] ?? '');
        $c['description'] = trim($_POST['description'] ?? '');
        $c['image_url'] = trim($_POST['image_url'] ?? '');
        $c['button_text'] = trim($_POST['button_text'] ?? '');
        $c['button_url'] = trim($_POST['button_url'] ?? '');
        $c['visible'] = isset($_POST['visible']) ? true : false;
        $c['order'] = intval($_POST['order'] ?? 0);
        break;
      }
    }
    write_cards($cards);
    $notice = "تم تحديث البطاقة";
  }
  if ($action === 'delete_card') {
    $cards = read_cards();
    $id = $_POST['id'] ?? '';
    $cards = array_values(array_filter($cards, function($c) use ($id){ return $c['id'] !== $id; }));
    write_cards($cards);
    $notice = "تم حذف البطاقة";
  }
  if ($action === 'reorder') {
    $cards = read_cards();
    $id = $_POST['id'] ?? '';
    $dir = $_POST['dir'] ?? 'up';
    for ($i=0; $i<count($cards); $i++) {
      if ($cards[$i]['id'] === $id) {
        $j = $dir === 'up' ? $i-1 : $i+1;
        if ($j >= 0 && $j < count($cards)) {
          $tmp = $cards[$i]['order'] ?? $i;
          $cards[$i]['order'] = $cards[$j]['order'] ?? $j;
          $cards[$j]['order'] = $tmp;
          // swap positions too
          $t = $cards[$i]; $cards[$i] = $cards[$j]; $cards[$j] = $t;
        }
        break;
      }
    }
    write_cards($cards);
    $notice = "تم تغيير الترتيب";
  }
}

// قراءة القيم الحالية
$cards = read_cards();
$bot_token = $TELEGRAM_BOT_TOKEN ?? '';
$chat_id   = $TELEGRAM_CHAT_ID ?? '';

?><!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>لوحة التحكم</title>
  <link rel="stylesheet" href="https://unpkg.com/@picocss/pico@2.0.6/css/pico.min.css">
  <style>
    nav { border-bottom: 1px solid #e2e8f0; }
    .tabs { display:flex; gap:.5rem; margin:1rem 0 }
    .tabs a { padding:.5rem 1rem; border-radius:999px; border:1px solid #e2e8f0; text-decoration:none }
    .tabs a.active { background:#111; color:#fff; border-color:#111 }
    .grid-3 { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:1rem }
    .muted { color:#64748b }
    .row { display:flex; gap:.5rem; align-items:center }
    textarea{min-height:120px}
    code{direction:ltr}
  </style>
</head>
<body>
  <nav class="container-fluid">
    <ul><li><strong>لوحة التحكم</strong></li></ul>
    <ul><li><a href="index.html">رجوع للموقع</a></li><li><a href="admin.php?logout=1">خروج</a></li></ul>
  </nav>
  <main class="container">
    <?php if (!empty($notice)): ?>
      <mark><?php echo htmlspecialchars($notice, ENT_QUOTES, "UTF-8"); ?></mark>
    <?php endif; ?>

    <div class="tabs">
      <a href="#tab-config" class="active" onclick="openTab(event,'tab-config')">إعدادات تيليجرام</a>
      <a href="#tab-cards" onclick="openTab(event,'tab-cards')">المحتوى (بطاقات)</a>
    </div>

    <section id="tab-config">
      <h2>إعدادات تيليجرام</h2>
      <p class="muted">حرر التوكن و الـ chat_id. تحفظ في <code>config.local.php</code> دون المساس بـ <code>config.php</code>.</p>
      <form method="post">
        <input type="hidden" name="action" value="save_config">
        <label>TELEGRAM_BOT_TOKEN
          <input type="text" name="bot_token" value="<?php echo htmlspecialchars($bot_token ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        </label>
        <label>TELEGRAM_CHAT_ID
          <input type="text" name="chat_id" value="<?php echo htmlspecialchars($chat_id ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
        </label>
        <button type="submit" class="contrast">حفظ</button>
      </form>
      <details>
        <summary>معلومة أمنية</summary>
        <p class="muted">احفظ كلمة مرور لوحة التحكم من <code>ADMIN_PASSWORD</code> في متغير بيئي أو ضمن <code>config.php</code>. القيمة الافتراضية هي <code>change-me-please</code> ويجب تغييرها.</p>
      </details>
    </section>

    <section id="tab-cards" style="display:none">
      <h2>إدارة البطاقات</h2>
      <p class="muted">أضف بطاقات بوسائط وصِف عنوانها ونصها وزر اختياري. تُعرض للجمهور على أي صفحة تضع فيها الحاوية <code>&lt;div id="cards-grid"&gt;&lt;/div&gt;</code> مع <code>cards.js</code> و<code>cards.css</code>.</p>

      <article>
        <h3>إضافة بطاقة جديدة</h3>
        <form method="post">
          <input type="hidden" name="action" value="add_card">
          <div class="grid">
            <label>العنوان
              <input type="text" name="title" placeholder="مثال: تأمين مركبات">
            </label>
            <label>الرابط النصي للزر
              <input type="text" name="button_text" placeholder="تعرّف أكثر">
            </label>
          </div>
          <div class="grid">
            <label>رابط الزر
              <input type="url" name="button_url" placeholder="https://example.com">
            </label>
            <label>رابط الصورة
              <input type="url" name="image_url" placeholder="https://.../image.jpg">
            </label>
          </div>
          <label>الوصف
            <textarea name="description" placeholder="نص قصير يشرح البطاقة"></textarea>
          </label>
          <div class="row">
            <label><input type="checkbox" name="visible" checked> ظاهرة</label>
            <label>الترتيب <input type="number" name="order" value="0" style="max-width:120px"></label>
          </div>
          <button type="submit" class="contrast">إضافة</button>
        </form>
      </article>

      <article>
        <h3>القائمة</h3>
        <div class="grid-3">
          <?php foreach ($cards as $c): ?>
          <form method="post" class="card" style="border:1px solid #e2e8f0; padding:1rem; border-radius:12px">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($c['id'], ENT_QUOTES, 'UTF-8'); ?>">
            <label>العنوان
              <input type="text" name="title" value="<?php echo htmlspecialchars($c['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            </label>
            <label>الوصف
              <textarea name="description"><?php echo htmlspecialchars($c['description'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
            </label>
            <label>رابط الصورة
              <input type="url" name="image_url" value="<?php echo htmlspecialchars($c['image_url'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
            </label>
            <div class="grid">
              <label>نص الزر
                <input type="text" name="button_text" value="<?php echo htmlspecialchars($c['button_text'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
              </label>
              <label>رابط الزر
                <input type="url" name="button_url" value="<?php echo htmlspecialchars($c['button_url'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
              </label>
            </div>
            <div class="row">
              <label><input type="checkbox" name="visible" <?php echo (!isset($c['visible']) || $c['visible']) ? 'checked' : ''; ?>> ظاهرة</label>
              <label>الترتيب <input type="number" name="order" value="<?php echo intval($c['order'] ?? 0); ?>" style="max-width:120px"></label>
            </div>
            <div class="row">
              <button type="submit" name="action" value="update_card">حفظ التعديلات</button>
              <button type="submit" name="action" value="delete_card" class="secondary" onclick="return confirm('حذف نهائي؟')">حذف</button>
            </div>
            <div class="row">
              <button type="submit" name="action" value="reorder" onclick="this.form.dir.value='up'">▲</button>
              <button type="submit" name="action" value="reorder" onclick="this.form.dir.value='down'">▼</button>
              <input type="hidden" name="dir" value="up">
            </div>
          </form>
          <?php endforeach; ?>
        </div>
      </article>

      <article>
        <h3>طريقة العرض في الصفحات العامة</h3>
        <details>
          <summary>باستخدام جافاسكربت (لا تحتاج PHP)</summary>
          <pre><code>&lt;link rel="stylesheet" href="cards.css"&gt;
&lt;div id="cards-grid"&gt;&lt;/div&gt;
&lt;script src="cards.js"&gt;&lt;/script&gt;</code></pre>
        </details>
        <details>
          <summary>باستخدام PHP (تضمين خادمي)</summary>
          <pre><code>&lt;?php include __DIR__ . '/cards.php'; ?&gt;</code></pre>
        </details>
      </article>
    </section>
  </main>
  <script>
    function openTab(ev, id) {
      document.querySelectorAll('main section').forEach(s => s.style.display = 'none');
      document.getElementById(id).style.display = '';
      document.querySelectorAll('.tabs a').forEach(a=>a.classList.remove('active'));
      ev.target.classList.add('active');
      ev.preventDefault();
    }
    if (location.hash === '#tab-cards') {
      document.querySelector('.tabs a[href="#tab-cards"]').click();
    }
    // logout
    if (new URLSearchParams(location.search).get('logout') === '1') {
      fetch('admin.php?do=logout').then(()=>{ location.href='admin.php'; });
    }
  </script>
</body>
</html>
