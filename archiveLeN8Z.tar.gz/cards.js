(function(){
  function h(tag, attrs, children){
    var el = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function(k){ el.setAttribute(k, attrs[k]); });
    (children||[]).forEach(function(c){ if (typeof c === 'string') el.appendChild(document.createTextNode(c)); else if (c) el.appendChild(c); });
    return el;
  }
  function renderCards(container, cards) {
    container.innerHTML = "";
    var grid = h('div', {class: 'cards-grid'});
    cards.sort(function(a,b){ return (a.order||0)-(b.order||0); });
    cards.forEach(function(card){
      if (card.visible === false) return;
      var fig = h('figure', {class:'card'});
      if (card.image_url) {
        var img = h('img', {src: card.image_url, alt: card.title||''});
        fig.appendChild(img);
      }
      var cap = h('figcaption', null, []);
      if (card.title) cap.appendChild(h('h3', null, [card.title]));
      if (card.description) cap.appendChild(h('p', null, [card.description]));
      if (card.button_url && card.button_text) {
        var a = h('a', {href: card.button_url, class: 'contrast', role: 'button', target: '_blank', rel:'noopener'}, [card.button_text]);
        cap.appendChild(a);
      }
      fig.appendChild(cap);
      grid.appendChild(fig);
    });
    container.appendChild(grid);
  }
  function init(){
    var container = document.getElementById('cards-grid');
    if (!container) return;
    var url = (window.CARDS_JSON_URL || 'data/cards.json') + '?v=' + Date.now();
    fetch(url).then(function(r){ return r.json(); }).then(function(cards){
      renderCards(container, cards || []);
    }).catch(function(){ /* ignore */ });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();