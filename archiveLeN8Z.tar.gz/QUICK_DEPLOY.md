# النشر السريع

دليل سريع لنشر النظام على Ubuntu 24.04 في دقائق.

---

## ⚡ البدء السريع

### 1. تثبيت المتطلبات (دقيقتان)

```bash
sudo apt update
sudo apt install -y apache2 php8.1 php8.1-fpm php8.1-mysql \
  php8.1-mbstring php8.1-curl php8.1-xml mysql-server
```

### 2. إعداد Apache (دقيقة واحدة)

```bash
sudo a2enmod rewrite proxy_fcgi setenvif
sudo a2enconf php8.1-fpm
sudo systemctl restart apache2
```

### 3. إعداد MySQL (دقيقتان)

```bash
# تسجيل الدخول
sudo mysql

# إنشاء قاعدة البيانات
CREATE DATABASE bus_booking_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'bus_admin'@'localhost' IDENTIFIED BY 'كلمة_مرور_قوية';
GRANT ALL PRIVILEGES ON bus_booking_system.* TO 'bus_admin'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 4. رفع الملفات (دقيقة واحدة)

```bash
# إنشاء المجلد
sudo mkdir -p /var/www/bus-booking-system

# رفع الملفات (من جهازك)
scp -r dist/ api/ database/ public/ admin/ .htaccess \
  user@your-server:/tmp/

# نقلها (على الخادم)
sudo mv /tmp/dist /tmp/api /tmp/database /tmp/public /tmp/admin /tmp/.htaccess \
  /var/www/bus-booking-system/

# أو استخدم git
cd /var/www
sudo git clone your-repo-url bus-booking-system
```

### 5. الصلاحيات (30 ثانية)

```bash
sudo chown -R www-data:www-data /var/www/bus-booking-system
sudo chmod -R 755 /var/www/bus-booking-system
sudo mkdir -p /var/www/bus-booking-system/logs
sudo chmod -R 775 /var/www/bus-booking-system/logs
```

### 6. إعداد config.php (30 ثانية)

```bash
sudo nano /var/www/bus-booking-system/api/config.php
```

عدّل:
```php
define('DB_PASS', 'كلمة_المرور_التي_أنشأتها');
define('JWT_SECRET', 'مفتاح_عشوائي_قوي_جداً');
define('DEBUG_MODE', false);
```

### 7. استيراد قاعدة البيانات (دقيقة واحدة)

```bash
cd /var/www/bus-booking-system

mysql -u bus_admin -p bus_booking_system < database/schema.sql
mysql -u bus_admin -p bus_booking_system < database/generate_trips.sql
```

### 8. إعداد Virtual Host (دقيقتان)

```bash
sudo nano /etc/apache2/sites-available/bus-booking.conf
```

أضف:
```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    DocumentRoot /var/www/bus-booking-system

    <Directory /var/www/bus-booking-system>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted

        <FilesMatch \.php$>
            SetHandler "proxy:unix:/run/php/php8.1-fpm.sock|fcgi://localhost"
        </FilesMatch>
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/bus-booking-error.log
    CustomLog ${APACHE_LOG_DIR}/bus-booking-access.log combined
</VirtualHost>
```

```bash
sudo a2ensite bus-booking.conf
sudo a2dissite 000-default.conf
sudo apache2ctl configtest
sudo systemctl restart apache2
```

### 9. جدار الحماية (30 ثانية)

```bash
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

### 10. اختبار (30 ثانية)

```bash
# اختبار API
curl http://yourdomain.com/api/api.php?endpoint=stations

# في المتصفح
http://yourdomain.com
http://yourdomain.com/admin/login.html
```

---

## 🎉 انتهيت!

المجموع: **~10 دقائق**

---

## 🔒 (اختياري) إعداد SSL

```bash
sudo apt install -y certbot python3-certbot-apache
sudo certbot --apache -d yourdomain.com
```

---

## 📝 الخطوات التالية

1. ✅ سجل دخول لوحة التحكم
2. ✅ ولّد رحلات تجريبية
3. ✅ اختبر الحجز
4. ✅ راقب logs

---

## 🆘 حل المشاكل السريع

### "500 Error"
```bash
sudo tail -50 /var/log/apache2/bus-booking-error.log
```

### "Access Denied"
```bash
# تحقق من config.php
cat /var/www/bus-booking-system/api/config.php

# اختبار الاتصال
mysql -u bus_admin -p bus_booking_system -e "SELECT 1;"
```

### ".htaccess not working"
```bash
# تحقق من mod_rewrite
sudo apache2ctl -M | grep rewrite

# تفعيله
sudo a2enmod rewrite
sudo systemctl restart apache2
```

---

## 📚 للمزيد

- [دليل النشر الكامل](DEPLOYMENT_GUIDE.md)
- [هيكل المشروع](PROJECT_STRUCTURE.md)
- [ملخص التنظيف](CLEANUP_SUMMARY.md)

---

**⚡ نشر سريع في 10 دقائق!**
