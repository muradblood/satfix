# دليل الاتصال بالخادم

معلومات الاتصال بخادمك والخطوات التالية.

---

## 🔐 معلومات الاتصال

```
المستخدم: fastpanel
عنوان IP: 46.28.44.184
المنفذ: 22 (افتراضي)
```

---

## 🚀 الاتصال بالخادم

### من Linux/Mac

```bash
ssh fastpanel@46.28.44.184
```

### من Windows (PowerShell)

```powershell
ssh fastpanel@46.28.44.184
```

### من Windows (PuTTY)

1. افتح PuTTY
2. Host Name: `46.28.44.184`
3. Port: `22`
4. Connection Type: SSH
5. اضغط "Open"
6. اكتب اسم المستخدم: `fastpanel`
7. اكتب كلمة المرور

---

## ✅ بعد الاتصال - الخطوات السريعة

### 1️⃣ التحقق من المتطلبات

```bash
# التحقق من Apache
apache2 -v
# أو
httpd -v

# التحقق من PHP
php -v

# التحقق من MySQL
mysql --version

# التحقق من المجلدات
ls /var/www/
ls /home/fastpanel/
```

### 2️⃣ إنشاء مجلد المشروع

```bash
# إذا كان لديك صلاحيات sudo
sudo mkdir -p /var/www/bus-booking-system

# إذا لم تكن لديك صلاحيات sudo
mkdir -p ~/bus-booking-system
```

### 3️⃣ استقبال الملفات من جهازك

**على جهازك المحلي** (نافذة جديدة):

```bash
# الطريقة 1: رفع ملف مضغوط
# أولاً: حضّر الملفات
cd /tmp/cc-agent/59475119/project
npm run build

# إنشاء مجلد النشر
mkdir deploy
cp -r dist api database public admin .htaccess deploy/

# ضغط
tar -czf bus-booking.tar.gz deploy/

# رفع
scp bus-booking.tar.gz fastpanel@46.28.44.184:/tmp/
```

**على الخادم**:

```bash
# فك الضغط
cd /tmp
tar -xzf bus-booking.tar.gz

# نقل الملفات
# إذا كان لديك sudo
sudo mv deploy/* /var/www/bus-booking-system/

# أو إذا في مجلد المستخدم
mv deploy/* ~/bus-booking-system/
```

### 4️⃣ التحقق من لوحة FastPanel

FastPanel عادة يوفر واجهة ويب لإدارة الخادم:

```bash
# تحقق من المنفذ
sudo netstat -tulpn | grep :8000
# أو
sudo netstat -tulpn | grep :8080
```

جرب في المتصفح:
- `http://46.28.44.184:8000`
- `http://46.28.44.184:8080`
- `https://46.28.44.184:8443`

---

## 🔍 فحص FastPanel

### التحقق من الإعدادات

```bash
# التحقق من مجلدات الويب
ls -la /var/www/
ls -la /home/fastpanel/

# التحقق من تكوين Apache/Nginx
sudo apache2ctl -S
# أو
sudo nginx -T

# التحقق من PHP-FPM
sudo systemctl status php*-fpm
```

### التحقق من MySQL

```bash
# محاولة الاتصال
mysql -u root -p

# أو إذا كان FastPanel له مستخدم خاص
mysql -u fastpanel -p
```

---

## 📋 معلومات FastPanel الشائعة

FastPanel عادة يُنشئ:

### المجلدات الافتراضية:
```
/var/www/           # مجلد الويب الرئيسي
/home/fastpanel/    # مجلد المستخدم
~/domains/          # المواقع
```

### قواعد البيانات:
```
مستخدم: fastpanel أو root
كلمة المرور: (حسب الإعداد)
```

### لوحة التحكم:
```
عادة على المنافذ: 8000, 8080, 8443
```

---

## 🎯 الخطوات الموصى بها

### 1. استكشف الخادم أولاً

```bash
# بعد الاتصال
ssh fastpanel@46.28.44.184

# نفذ هذه الأوامر
echo "=== معلومات النظام ==="
uname -a
cat /etc/os-release

echo "=== مجلدات الويب ==="
ls -la /var/www/

echo "=== Apache/Nginx ==="
which apache2 || which nginx

echo "=== PHP ==="
php -v

echo "=== MySQL ==="
mysql --version

echo "=== FastPanel ==="
ls -la ~
systemctl list-units | grep -i panel
```

### 2. أرسل النتائج

بعد تنفيذ الأوامر أعلاه، أرسل النتائج لنقرر:
- أين نضع الملفات؟
- كيف نُعد قاعدة البيانات؟
- ما هي الصلاحيات المتاحة؟

---

## 📦 خيارات الرفع المختلفة

### الخيار 1: SCP (الأسرع)

```bash
# من جهازك
scp -r dist/ api/ database/ public/ admin/ .htaccess \
  fastpanel@46.28.44.184:/tmp/bus-booking/
```

### الخيار 2: RSYNC (الأفضل)

```bash
# من جهازك
rsync -avz --progress \
  dist/ api/ database/ public/ admin/ .htaccess \
  fastpanel@46.28.44.184:/tmp/bus-booking/
```

### الخيار 3: SFTP

```bash
# من جهازك
sftp fastpanel@46.28.44.184

# داخل SFTP
put -r deploy/
quit
```

### الخيار 4: استخدام لوحة FastPanel

إذا كانت لوحة FastPanel متاحة:
1. افتح لوحة التحكم
2. اذهب لـ "File Manager"
3. ارفع الملفات مباشرة

---

## 🛠️ استكشاف الأخطاء

### "Permission denied (publickey)"

```bash
# استخدم كلمة المرور
ssh -o PreferredAuthentications=password fastpanel@46.28.44.184
```

### "Connection refused"

```bash
# تحقق من المنفذ
ssh -p 22 fastpanel@46.28.44.184
# جرب منافذ أخرى إذا لزم
ssh -p 2222 fastpanel@46.28.44.184
```

### "Connection timeout"

- تحقق من جدار الحماية
- تأكد من عنوان IP صحيح
- تحقق من الإنترنت

---

## 📞 التالي؟

بعد الاتصال الناجح:

1. ✅ استكشف الخادم (الأوامر أعلاه)
2. ✅ حدد مجلد الويب المناسب
3. ✅ ارفع الملفات
4. ✅ أعد قاعدة البيانات
5. ✅ اختبر الموقع

---

## 🔗 روابط مفيدة

- [دليل الرفع الكامل](UPLOAD_GUIDE.md)
- [دليل النشر السريع](QUICK_DEPLOY.md)
- [إعداد الخادم](SERVER_SETUP.md)

---

**✨ حظاً موفقاً في الاتصال!**

أخبرني بالنتائج بعد الاتصال لنكمل معاً 🚀
