<?php
/**
 * إعدادات قاعدة البيانات والتطبيق
 */

/**
 * إعدادات CORS
 */
define('ALLOWED_ORIGINS', [
    'http://localhost:5173',
    'http://localhost:3000',
    'https://hmdev.store',
    'https://hmdev.store/'
]);

// دالة معالجة CORS (الهيدرز + preflight)
function handleCORS()
{
    // نوع الاستجابة
    header('Content-Type: application/json; charset=utf-8');

    // CORS headers
    if (isset($_SERVER['HTTP_ORIGIN']) && in_array($_SERVER['HTTP_ORIGIN'], ALLOWED_ORIGINS, true)) {
        header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        header('Access-Control-Allow-Credentials: true');
    }

    // Handle preflight (OPTIONS) requests
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204); // No Content
        exit;
    }
}

// استدعاء CORS في بداية كل طلب
handleCORS();

/**
 * إعدادات قاعدة البيانات
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'blood');
define('DB_USER', 'hmdev_store');
define('DB_PASS', 'Xrpxyoz@2222');
define('DB_CHARSET', 'utf8mb4');

/**
 * إعدادات التطبيق
 */
define('APP_NAME', 'نظام حجز الباصات');
define('APP_VERSION', '1.0.0');
define('API_VERSION', 'v1');

/**
 * إعدادات الأمان
 */
define('JWT_SECRET', getenv('JWT_SECRET')); // تأكد إن المتغير موجود في البيئة
define('JWT_EXPIRY', 86400); // 24 ساعة
define('PASSWORD_HASH_ALGO', PASSWORD_BCRYPT);
define('PASSWORD_COST', 12);

/**
 * إعدادات OTP
 */
define('OTP_LENGTH', 6);
define('OTP_EXPIRY', 300); // 5 دقائق
define('OTP_MAX_ATTEMPTS', 3);

/**
 * إعدادات التيليجرام
 */
define('TELEGRAM_API_URL', 'https://api.telegram.org/bot');

/**
 * إعدادات معالجة الأخطاء
 */
define('DEBUG_MODE', true); // غيّر إلى false في الإنتاج
define('LOG_ERRORS', true);
define('LOG_FILE', __DIR__ . '/../logs/api.log');

/**
 * المنطقة الزمنية
 */
date_default_timezone_set('Asia/Riyadh');


/**
 * دالة الاتصال بقاعدة البيانات
 */
function getDBConnection()
{
    static $conn = null;

    if ($conn === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET,
            ];

            $conn = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log('Database Connection Error: ' . $e->getMessage());

            if (DEBUG_MODE) {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'error'   => 'Database connection failed: ' . $e->getMessage(),
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            } else {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'error'   => 'Database connection failed',
                ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            }
            exit;
        }
    }

    return $conn;
}

/**
 * دالة إرجاع استجابة JSON
 */
function sendResponse($success, $data = null, $error = null, $status = 200)
{
    http_response_code($status);

    $response = ['success' => $success];

    if ($data !== null) {
        $response['data'] = $data;
    }

    if ($error !== null) {
        $response['error'] = $error;
    }

    echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * دالة معالجة الأخطاء
 */
function handleError($message, $status = 400)
{
    if (LOG_ERRORS) {
        error_log($message);
    }

    sendResponse(false, null, $message, $status);
}

/**
 * دالة التحقق من نوع الطلب
 */
function validateRequest($method)
{
    if ($_SERVER['REQUEST_METHOD'] !== $method) {
        handleError('Invalid request method', 405);
    }
}

/**
 * دالة الحصول على البيانات من الطلب (JSON body)
 */
function getRequestData()
{
    $data = json_decode(file_get_contents('php://input'), true);
    return $data ?? [];
}

/**
 * دالة التحقق من الحقول المطلوبة
 */
function validateRequired($data, $fields)
{
    $missing = [];

    foreach ($fields as $field) {
        if (!isset($data[$field]) || $data[$field] === '') {
            $missing[] = $field;
        }
    }

    if (!empty($missing)) {
        handleError('Missing required fields: ' . implode(', ', $missing), 400);
    }
}

/**
 * دالة تنظيف البيانات
 */
function sanitizeInput($data)
{
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }

    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * دالة إنشاء معرف فريد
 */
function generateUniqueId($prefix = '')
{
    return $prefix . strtoupper(bin2hex(random_bytes(8)));
}

/**
 * دالة إنشاء رمز OTP
 */
function generateOTP()
{
    return str_pad(
        (string) random_int(0, pow(10, OTP_LENGTH) - 1),
        OTP_LENGTH,
        '0',
        STR_PAD_LEFT
    );
}
