<?php
/**
 * API توليد الرحلات التلقائي
 */

define('API_ACCESS', true);
require_once 'config.php';
require_once 'auth.php';

class TripGenerator {
    private $db;
    private $auth;

    public function __construct() {
        $this->db = getDBConnection();
        $this->auth = new Auth();
    }

    /**
     * توليد رحلات لفترة محددة
     */
    public function generateTrips($start_date, $end_date, $trips_per_route = 3) {
        // التحقق من صلاحيات المسؤول
        $this->auth->requireAdmin();

        try {
            $stmt = $this->db->prepare("CALL generate_trips(?, ?, ?)");
            $stmt->execute([$start_date, $end_date, $trips_per_route]);

            $stats = $stmt->fetch();

            return [
                'message' => 'تم توليد الرحلات بنجاح',
                'statistics' => $stats
            ];
        } catch (PDOException $e) {
            throw new Exception('فشل توليد الرحلات: ' . $e->getMessage());
        }
    }

    /**
     * توليد رحلات لشهر كامل
     */
    public function generateMonthlyTrips($month, $year, $trips_per_route = 3) {
        // التحقق من صلاحيات المسؤول
        $this->auth->requireAdmin();

        if ($month < 1 || $month > 12) {
            handleError('رقم الشهر غير صحيح (1-12)', 400);
        }

        if ($year < 2024 || $year > 2030) {
            handleError('السنة غير صحيحة', 400);
        }

        try {
            $stmt = $this->db->prepare("CALL generate_monthly_trips(?, ?, ?)");
            $stmt->execute([$month, $year, $trips_per_route]);

            $stats = $stmt->fetch();

            return [
                'message' => "تم توليد رحلات شهر {$month}/{$year} بنجاح",
                'statistics' => $stats
            ];
        } catch (PDOException $e) {
            throw new Exception('فشل توليد الرحلات: ' . $e->getMessage());
        }
    }

    /**
     * توليد رحلات للأسبوع القادم
     */
    public function generateWeeklyTrips($trips_per_route = 3) {
        // التحقق من صلاحيات المسؤول
        $this->auth->requireAdmin();

        try {
            $stmt = $this->db->prepare("CALL generate_weekly_trips(?)");
            $stmt->execute([$trips_per_route]);

            $stats = $stmt->fetch();

            return [
                'message' => 'تم توليد رحلات الأسبوع القادم بنجاح',
                'statistics' => $stats
            ];
        } catch (PDOException $e) {
            throw new Exception('فشل توليد الرحلات: ' . $e->getMessage());
        }
    }

    /**
     * توليد رحلات ليوم محدد
     */
    public function generateDailyTrips($date, $trips_per_route = 3) {
        // التحقق من صلاحيات المسؤول
        $this->auth->requireAdmin();

        if (!strtotime($date)) {
            handleError('تاريخ غير صحيح', 400);
        }

        try {
            $stmt = $this->db->prepare("CALL generate_daily_trips(?, ?)");
            $stmt->execute([$date, $trips_per_route]);

            $stats = $stmt->fetch();

            return [
                'message' => "تم توليد رحلات يوم {$date} بنجاح",
                'statistics' => $stats
            ];
        } catch (PDOException $e) {
            throw new Exception('فشل توليد الرحلات: ' . $e->getMessage());
        }
    }

    /**
     * تنظيف الرحلات القديمة
     */
    public function cleanupOldTrips($days_old = 7) {
        // التحقق من صلاحيات المسؤول
        $this->auth->requireAdmin();

        try {
            $stmt = $this->db->prepare("CALL cleanup_old_trips(?)");
            $stmt->execute([$days_old]);

            $result = $stmt->fetch();

            return [
                'message' => 'تم تنظيف الرحلات القديمة',
                'deleted_trips' => $result['deleted_trips']
            ];
        } catch (PDOException $e) {
            throw new Exception('فشل تنظيف الرحلات: ' . $e->getMessage());
        }
    }

    /**
     * الحصول على إحصائيات الرحلات
     */
    public function getTripStatistics() {
        try {
            $stmt = $this->db->query("CALL get_trip_statistics()");
            $stats = $stmt->fetchAll();

            return $stats;
        } catch (PDOException $e) {
            throw new Exception('فشل الحصول على الإحصائيات: ' . $e->getMessage());
        }
    }

    /**
     * الحصول على ملخص الرحلات
     */
    public function getTripsSummary() {
        try {
            $stmt = $this->db->query("
                SELECT
                    COUNT(*) as total_trips,
                    COUNT(CASE WHEN trip_status = 'scheduled' THEN 1 END) as scheduled,
                    COUNT(CASE WHEN trip_status = 'completed' THEN 1 END) as completed,
                    COUNT(CASE WHEN trip_status = 'cancelled' THEN 1 END) as cancelled,
                    COUNT(DISTINCT from_station_id) as total_stations,
                    MIN(departure_time) as first_trip,
                    MAX(departure_time) as last_trip,
                    SUM(available_seats) as total_available_seats
                FROM trips
                WHERE departure_time >= CURDATE()
            ");

            return $stmt->fetch();
        } catch (PDOException $e) {
            throw new Exception('فشل الحصول على الملخص: ' . $e->getMessage());
        }
    }

    /**
     * حذف جميع الرحلات المجدولة
     */
    public function deleteAllScheduledTrips() {
        // التحقق من صلاحيات المسؤول
        $this->auth->requireAdmin();

        try {
            $stmt = $this->db->query("
                DELETE FROM trips
                WHERE trip_status = 'scheduled'
                AND available_seats = (SELECT capacity FROM buses WHERE id = bus_id)
            ");

            $deleted_count = $stmt->rowCount();

            return [
                'message' => 'تم حذف جميع الرحلات المجدولة',
                'deleted_count' => $deleted_count
            ];
        } catch (PDOException $e) {
            throw new Exception('فشل حذف الرحلات: ' . $e->getMessage());
        }
    }

    /**
     * تفعيل/تعطيل توليد الرحلات التلقائي
     */
    public function toggleAutoGeneration($enabled) {
        // التحقق من صلاحيات المسؤول
        $this->auth->requireAdmin();

        try {
            if ($enabled) {
                $this->db->exec("SET GLOBAL event_scheduler = ON");
                $message = 'تم تفعيل التوليد التلقائي للرحلات';
            } else {
                $this->db->exec("SET GLOBAL event_scheduler = OFF");
                $message = 'تم تعطيل التوليد التلقائي للرحلات';
            }

            return ['message' => $message];
        } catch (PDOException $e) {
            throw new Exception('فشل تحديث الإعداد: ' . $e->getMessage());
        }
    }

    /**
     * الحصول على حالة التوليد التلقائي
     */
    public function getAutoGenerationStatus() {
        try {
            $stmt = $this->db->query("SHOW VARIABLES LIKE 'event_scheduler'");
            $result = $stmt->fetch();

            $enabled = ($result['Value'] === 'ON');

            return [
                'enabled' => $enabled,
                'status' => $enabled ? 'مفعّل' : 'معطّل'
            ];
        } catch (PDOException $e) {
            throw new Exception('فشل الحصول على الحالة: ' . $e->getMessage());
        }
    }
}

// معالجة الطلبات
$generator = new TripGenerator();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'generate':
            validateRequest('POST');
            $data = getRequestData();
            validateRequired($data, ['start_date', 'end_date']);

            $trips_per_route = (int)($data['trips_per_route'] ?? 3);
            $result = $generator->generateTrips(
                $data['start_date'],
                $data['end_date'],
                $trips_per_route
            );
            sendResponse(true, $result);
            break;

        case 'generate-monthly':
            validateRequest('POST');
            $data = getRequestData();
            validateRequired($data, ['month', 'year']);

            $trips_per_route = (int)($data['trips_per_route'] ?? 3);
            $result = $generator->generateMonthlyTrips(
                (int)$data['month'],
                (int)$data['year'],
                $trips_per_route
            );
            sendResponse(true, $result);
            break;

        case 'generate-weekly':
            validateRequest('POST');
            $data = getRequestData();

            $trips_per_route = (int)($data['trips_per_route'] ?? 3);
            $result = $generator->generateWeeklyTrips($trips_per_route);
            sendResponse(true, $result);
            break;

        case 'generate-daily':
            validateRequest('POST');
            $data = getRequestData();
            validateRequired($data, ['date']);

            $trips_per_route = (int)($data['trips_per_route'] ?? 3);
            $result = $generator->generateDailyTrips(
                $data['date'],
                $trips_per_route
            );
            sendResponse(true, $result);
            break;

        case 'cleanup':
            validateRequest('POST');
            $data = getRequestData();

            $days_old = (int)($data['days_old'] ?? 7);
            $result = $generator->cleanupOldTrips($days_old);
            sendResponse(true, $result);
            break;

        case 'statistics':
            validateRequest('GET');
            $result = $generator->getTripStatistics();
            sendResponse(true, $result);
            break;

        case 'summary':
            validateRequest('GET');
            $result = $generator->getTripsSummary();
            sendResponse(true, $result);
            break;

        case 'delete-all':
            validateRequest('POST');
            $result = $generator->deleteAllScheduledTrips();
            sendResponse(true, $result);
            break;

        case 'toggle-auto':
            validateRequest('POST');
            $data = getRequestData();
            validateRequired($data, ['enabled']);

            $result = $generator->toggleAutoGeneration((bool)$data['enabled']);
            sendResponse(true, $result);
            break;

        case 'auto-status':
            validateRequest('GET');
            $result = $generator->getAutoGenerationStatus();
            sendResponse(true, $result);
            break;

        default:
            handleError('Invalid action', 400);
    }

} catch (Exception $e) {
    error_log('Trip Generator Error: ' . $e->getMessage());
    handleError($e->getMessage(), 500);
}
