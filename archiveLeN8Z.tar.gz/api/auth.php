<?php
/**
 * وحدة المصادقة والتفويض
 */

define('API_ACCESS', true);
require_once 'config.php';

class Auth {
    private $db;

    public function __construct() {
        $this->db = getDBConnection();
    }

    /**
     * تسجيل مستخدم جديد
     */
    public function register($data) {
        validateRequired($data, ['email', 'password']);

        $email = sanitizeInput($data['email']);
        $password = $data['password'];
        $full_name = sanitizeInput($data['full_name'] ?? '');
        $phone = sanitizeInput($data['phone'] ?? '');

        // التحقق من صحة البريد الإلكتروني
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            handleError('Invalid email format', 400);
        }

        // التحقق من طول كلمة المرور
        if (strlen($password) < 6) {
            handleError('Password must be at least 6 characters', 400);
        }

        // التحقق من وجود المستخدم
        $stmt = $this->db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            handleError('Email already exists', 409);
        }

        // تشفير كلمة المرور
        $password_hash = password_hash($password, PASSWORD_HASH_ALGO, ['cost' => PASSWORD_COST]);

        // إضافة المستخدم
        $stmt = $this->db->prepare("
            INSERT INTO users (email, password_hash, full_name, phone)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->execute([$email, $password_hash, $full_name, $phone]);
        $user_id = $this->db->lastInsertId();

        // إنشاء ملف شخصي
        $stmt = $this->db->prepare("
            INSERT INTO user_profiles (user_id) VALUES (?)
        ");
        $stmt->execute([$user_id]);

        // إنشاء جلسة
        $token = $this->createSession($user_id);

        return [
            'user' => [
                'id' => $user_id,
                'email' => $email,
                'full_name' => $full_name,
                'phone' => $phone,
                'role' => 'user'
            ],
            'token' => $token
        ];
    }

    /**
     * تسجيل الدخول
     */
    public function login($data) {
        validateRequired($data, ['email', 'password']);

        $email = sanitizeInput($data['email']);
        $password = $data['password'];

        // البحث عن المستخدم
        $stmt = $this->db->prepare("
            SELECT id, email, password_hash, full_name, phone, role, is_active
            FROM users
            WHERE email = ?
        ");

        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            handleError('Invalid credentials', 401);
        }

        // التحقق من كلمة المرور
        if (!password_verify($password, $user['password_hash'])) {
            handleError('Invalid credentials', 401);
        }

        // التحقق من تفعيل الحساب
        if (!$user['is_active']) {
            handleError('Account is inactive', 403);
        }

        // تحديث آخر تسجيل دخول
        $stmt = $this->db->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->execute([$user['id']]);

        // إنشاء جلسة
        $token = $this->createSession($user['id']);

        unset($user['password_hash']);

        return [
            'user' => $user,
            'token' => $token
        ];
    }

    /**
     * تسجيل الخروج
     */
    public function logout($token) {
        $stmt = $this->db->prepare("DELETE FROM user_sessions WHERE token = ?");
        $stmt->execute([$token]);

        return ['message' => 'Logged out successfully'];
    }

    /**
     * إنشاء جلسة جديدة
     */
    private function createSession($user_id) {
        $token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', time() + JWT_EXPIRY);
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? '';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

        $stmt = $this->db->prepare("
            INSERT INTO user_sessions (user_id, token, expires_at, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?)
        ");

        $stmt->execute([$user_id, $token, $expires_at, $ip_address, $user_agent]);

        return $token;
    }

    /**
     * التحقق من الجلسة
     */
    public function verifyToken($token) {
        if (empty($token)) {
            return null;
        }

        $stmt = $this->db->prepare("
            SELECT s.user_id, u.email, u.role, u.is_active
            FROM user_sessions s
            JOIN users u ON s.user_id = u.id
            WHERE s.token = ? AND s.expires_at > NOW()
        ");

        $stmt->execute([$token]);
        $session = $stmt->fetch();

        if (!$session || !$session['is_active']) {
            return null;
        }

        return $session;
    }

    /**
     * الحصول على التوكن من الهيدر
     */
    public static function getToken() {
        $headers = getallheaders();
        $auth_header = $headers['Authorization'] ?? $headers['authorization'] ?? '';

        if (preg_match('/Bearer\s+(.*)$/i', $auth_header, $matches)) {
            return $matches[1];
        }

        return null;
    }

    /**
     * التحقق من صلاحية المسؤول
     */
    public function requireAdmin() {
        $token = self::getToken();
        $session = $this->verifyToken($token);

        if (!$session) {
            handleError('Unauthorized', 401);
        }

        if ($session['role'] !== 'admin') {
            handleError('Forbidden: Admin access required', 403);
        }

        return $session;
    }

    /**
     * التحقق من تسجيل الدخول
     */
    public function requireAuth() {
        $token = self::getToken();
        $session = $this->verifyToken($token);

        if (!$session) {
            handleError('Unauthorized', 401);
        }

        return $session;
    }
}

// معالجة الطلبات
if (basename($_SERVER['PHP_SELF']) === 'auth.php') {
    $auth = new Auth();
    $action = $_GET['action'] ?? '';

    try {
        switch ($action) {
            case 'register':
                validateRequest('POST');
                $data = getRequestData();
                $result = $auth->register($data);
                sendResponse(true, $result);
                break;

            case 'login':
                validateRequest('POST');
                $data = getRequestData();
                $result = $auth->login($data);
                sendResponse(true, $result);
                break;

            case 'logout':
                validateRequest('POST');
                $token = Auth::getToken();
                $result = $auth->logout($token);
                sendResponse(true, $result);
                break;

            case 'verify':
                validateRequest('GET');
                $token = Auth::getToken();
                $session = $auth->verifyToken($token);

                if ($session) {
                    sendResponse(true, ['valid' => true, 'user' => $session]);
                } else {
                    sendResponse(false, ['valid' => false], 'Invalid or expired token', 401);
                }
                break;

            default:
                handleError('Invalid action', 400);
        }
    } catch (Exception $e) {
        handleError($e->getMessage(), 500);
    }
}
