<?php
/**
 * API الرئيسي لنظام حجز الباصات
 *
 * نقاط النهاية المتاحة:
 * - GET  /api.php?endpoint=stations - الحصول على جميع المحطات
 * - GET  /api.php?endpoint=trips - البحث عن الرحلات
 * - GET  /api.php?endpoint=trip&id=1 - الحصول على رحلة محددة
 * - POST /api.php?endpoint=booking - إنشاء حجز جديد
 * - GET  /api.php?endpoint=booking&ref=BK-123 - الحصول على حجز
 * - POST /api.php?endpoint=otp - إنشاء رمز OTP
 * - POST /api.php?endpoint=verify-otp - التحقق من OTP
 * - POST /api.php?endpoint=telegram - إرسال إشعار تيليجرام
 */

define('API_ACCESS', true);
require_once 'config.php';
require_once 'auth.php';

class BusBookingAPI {
    private $db;
    private $auth;

    public function __construct() {
        $this->db = getDBConnection();
        $this->auth = new Auth();
    }

    /**
     * الحصول على جميع المحطات
     */
    public function getStations() {
        $stmt = $this->db->query("
            SELECT id, name_ar, name_en, city, address, latitude, longitude, facilities
            FROM stations
            WHERE is_active = TRUE
            ORDER BY city, name_ar
        ");

        return $stmt->fetchAll();
    }

    /**
     * البحث عن الرحلات
     */
    public function searchTrips($params) {
        $from_station = $params['from'] ?? null;
        $to_station = $params['to'] ?? null;
        $date = $params['date'] ?? date('Y-m-d');
        $passengers = (int)($params['passengers'] ?? 1);
        $direct_only = isset($params['direct']) && $params['direct'] == 'true';

        $sql = "
            SELECT
                t.id, t.trip_number, t.departure_time, t.arrival_time,
                t.base_price, t.available_seats, t.is_direct, t.amenities, t.trip_status,
                sf.name_ar as from_station_name, sf.city as from_city,
                st.name_ar as to_station_name, st.city as to_city,
                b.bus_type, b.capacity, b.features,
                TIMESTAMPDIFF(HOUR, t.departure_time, t.arrival_time) as duration_hours
            FROM trips t
            JOIN stations sf ON t.from_station_id = sf.id
            JOIN stations st ON t.to_station_id = st.id
            JOIN buses b ON t.bus_id = b.id
            WHERE t.trip_status = 'scheduled'
            AND t.available_seats >= ?
            AND DATE(t.departure_time) = ?
        ";

        $params_array = [$passengers, $date];

        if ($from_station) {
            $sql .= " AND t.from_station_id = ?";
            $params_array[] = $from_station;
        }

        if ($to_station) {
            $sql .= " AND t.to_station_id = ?";
            $params_array[] = $to_station;
        }

        if ($direct_only) {
            $sql .= " AND t.is_direct = TRUE";
        }

        $sql .= " ORDER BY t.departure_time ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params_array);

        return $stmt->fetchAll();
    }

    /**
     * الحصول على رحلة محددة
     */
    public function getTrip($id) {
        $stmt = $this->db->prepare("
            SELECT
                t.*,
                sf.name_ar as from_station_name, sf.city as from_city,
                st.name_ar as to_station_name, st.city as to_city,
                b.bus_type, b.bus_number, b.capacity, b.features
            FROM trips t
            JOIN stations sf ON t.from_station_id = sf.id
            JOIN stations st ON t.to_station_id = st.id
            JOIN buses b ON t.bus_id = b.id
            WHERE t.id = ?
        ");

        $stmt->execute([$id]);
        $trip = $stmt->fetch();

        if (!$trip) {
            handleError('Trip not found', 404);
        }

        return $trip;
    }

    /**
     * إنشاء حجز جديد
     */
    public function createBooking($data) {
        validateRequired($data, [
            'trip_id', 'manager_name', 'manager_email',
            'manager_phone', 'manager_national_id',
            'total_passengers', 'passengers', 'seats'
        ]);

        $trip_id = (int)$data['trip_id'];
        $total_passengers = (int)$data['total_passengers'];

        // التحقق من الرحلة
        $trip = $this->getTrip($trip_id);

        if ($trip['available_seats'] < $total_passengers) {
            handleError('Not enough available seats', 400);
        }

        // حساب السعر الإجمالي
        $total_price = $trip['base_price'] * $total_passengers;

        // إنشاء رقم مرجعي فريد
        $booking_reference = 'BK-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));

        // الحصول على معرف المستخدم إن وجد
        $token = Auth::getToken();
        $session = $this->auth->verifyToken($token);
        $user_id = $session['user_id'] ?? null;

        $this->db->beginTransaction();

        try {
            // إضافة الحجز
            $stmt = $this->db->prepare("
                INSERT INTO bookings (
                    booking_reference, user_id, trip_id,
                    manager_name, manager_email, manager_phone, manager_national_id,
                    total_passengers, total_price, seats, booking_status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
            ");

            $stmt->execute([
                $booking_reference, $user_id, $trip_id,
                $data['manager_name'], $data['manager_email'],
                $data['manager_phone'], $data['manager_national_id'],
                $total_passengers, $total_price, json_encode($data['seats'])
            ]);

            $booking_id = $this->db->lastInsertId();

            // إضافة تفاصيل الركاب
            $stmt = $this->db->prepare("
                INSERT INTO passenger_details (
                    booking_id, full_name, national_id, date_of_birth,
                    gender, phone, seat_number, passenger_type
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            foreach ($data['passengers'] as $passenger) {
                $stmt->execute([
                    $booking_id,
                    $passenger['full_name'],
                    $passenger['national_id'],
                    $passenger['date_of_birth'] ?? null,
                    $passenger['gender'] ?? null,
                    $passenger['phone'] ?? null,
                    $passenger['seat_number'] ?? null,
                    $passenger['passenger_type'] ?? 'adult'
                ]);
            }

            // تحديث المقاعد المتاحة
            $stmt = $this->db->prepare("
                UPDATE trips
                SET available_seats = available_seats - ?
                WHERE id = ?
            ");
            $stmt->execute([$total_passengers, $trip_id]);

            $this->db->commit();

            return [
                'booking_id' => $booking_id,
                'booking_reference' => $booking_reference,
                'total_price' => $total_price,
                'status' => 'pending'
            ];

        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * الحصول على حجز
     */
    public function getBooking($reference) {
        $stmt = $this->db->prepare("
            SELECT
                b.*,
                t.trip_number, t.departure_time, t.arrival_time,
                sf.name_ar as from_station, st.name_ar as to_station
            FROM bookings b
            JOIN trips t ON b.trip_id = t.id
            JOIN stations sf ON t.from_station_id = sf.id
            JOIN stations st ON t.to_station_id = st.id
            WHERE b.booking_reference = ?
        ");

        $stmt->execute([$reference]);
        $booking = $stmt->fetch();

        if (!$booking) {
            handleError('Booking not found', 404);
        }

        // الحصول على تفاصيل الركاب
        $stmt = $this->db->prepare("
            SELECT * FROM passenger_details WHERE booking_id = ?
        ");
        $stmt->execute([$booking['id']]);
        $booking['passengers'] = $stmt->fetchAll();

        return $booking;
    }

    /**
     * تحديث حالة الدفع
     */
    public function updatePayment($data) {
        validateRequired($data, ['booking_reference', 'payment_status', 'payment_method']);

        $stmt = $this->db->prepare("
            UPDATE bookings
            SET payment_status = ?,
                payment_method = ?,
                payment_reference = ?,
                payment_date = NOW(),
                booking_status = CASE WHEN ? = 'completed' THEN 'confirmed' ELSE booking_status END
            WHERE booking_reference = ?
        ");

        $stmt->execute([
            $data['payment_status'],
            $data['payment_method'],
            $data['payment_reference'] ?? null,
            $data['payment_status'],
            $data['booking_reference']
        ]);

        return ['message' => 'Payment updated successfully'];
    }

    /**
     * إنشاء رمز OTP
     */
    public function createOTP($phone, $purpose = 'verification') {
        $code = generateOTP();
        $expires_at = date('Y-m-d H:i:s', time() + OTP_EXPIRY);

        $stmt = $this->db->prepare("
            INSERT INTO otp_codes (phone, code, purpose, expires_at)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->execute([$phone, $code, $purpose, $expires_at]);

        // في بيئة الإنتاج، يجب إرسال الكود عبر SMS
        // هنا نرجع الكود للاختبار فقط
        if (DEBUG_MODE) {
            return ['code' => $code, 'expires_at' => $expires_at];
        }

        return ['message' => 'OTP sent successfully'];
    }

    /**
     * التحقق من رمز OTP
     */
    public function verifyOTP($phone, $code) {
        $stmt = $this->db->prepare("
            SELECT * FROM otp_codes
            WHERE phone = ?
            AND code = ?
            AND is_used = FALSE
            AND expires_at > NOW()
            AND attempts < ?
            ORDER BY created_at DESC
            LIMIT 1
        ");

        $stmt->execute([$phone, $code, OTP_MAX_ATTEMPTS]);
        $otp = $stmt->fetch();

        if (!$otp) {
            // زيادة عدد المحاولات
            $stmt = $this->db->prepare("
                UPDATE otp_codes
                SET attempts = attempts + 1
                WHERE phone = ? AND code = ?
            ");
            $stmt->execute([$phone, $code]);

            handleError('Invalid or expired OTP', 400);
        }

        // تحديد الرمز كمستخدم
        $stmt = $this->db->prepare("
            UPDATE otp_codes
            SET is_used = TRUE
            WHERE id = ?
        ");
        $stmt->execute([$otp['id']]);

        return ['valid' => true, 'message' => 'OTP verified successfully'];
    }

    /**
     * إرسال إشعار تيليجرام
     */
    public function sendTelegramNotification($message) {
        // الحصول على إعدادات تيليجرام
        $stmt = $this->db->query("
            SELECT bot_token, chat_id, notifications_enabled
            FROM telegram_settings
            ORDER BY id DESC
            LIMIT 1
        ");

        $settings = $stmt->fetch();

        if (!$settings || !$settings['notifications_enabled']) {
            return ['message' => 'Telegram notifications are disabled'];
        }

        $url = TELEGRAM_API_URL . $settings['bot_token'] . '/sendMessage';
        $data = [
            'chat_id' => $settings['chat_id'],
            'text' => $message,
            'parse_mode' => 'HTML'
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);

        return json_decode($result, true);
    }
}

// معالجة الطلبات
$api = new BusBookingAPI();
$endpoint = $_GET['endpoint'] ?? '';

try {
    switch ($endpoint) {
        case 'stations':
            validateRequest('GET');
            $result = $api->getStations();
            sendResponse(true, $result);
            break;

        case 'trips':
            validateRequest('GET');
            $result = $api->searchTrips($_GET);
            sendResponse(true, $result);
            break;

        case 'trip':
            validateRequest('GET');
            $id = $_GET['id'] ?? null;
            if (!$id) handleError('Trip ID is required', 400);
            $result = $api->getTrip($id);
            sendResponse(true, $result);
            break;

        case 'booking':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $data = getRequestData();
                $result = $api->createBooking($data);
                sendResponse(true, $result, null, 201);
            } else {
                $ref = $_GET['ref'] ?? null;
                if (!$ref) handleError('Booking reference is required', 400);
                $result = $api->getBooking($ref);
                sendResponse(true, $result);
            }
            break;

        case 'payment':
            validateRequest('POST');
            $data = getRequestData();
            $result = $api->updatePayment($data);
            sendResponse(true, $result);
            break;

        case 'otp':
            validateRequest('POST');
            $data = getRequestData();
            validateRequired($data, ['phone']);
            $result = $api->createOTP($data['phone'], $data['purpose'] ?? 'verification');
            sendResponse(true, $result);
            break;

        case 'verify-otp':
            validateRequest('POST');
            $data = getRequestData();
            validateRequired($data, ['phone', 'code']);
            $result = $api->verifyOTP($data['phone'], $data['code']);
            sendResponse(true, $result);
            break;

        case 'telegram':
            validateRequest('POST');
            $data = getRequestData();
            validateRequired($data, ['message']);
            $result = $api->sendTelegramNotification($data['message']);
            sendResponse(true, $result);
            break;

        default:
            handleError('Invalid endpoint', 404);
    }

} catch (Exception $e) {
    error_log('API Error: ' . $e->getMessage());
    handleError($e->getMessage(), 500);
}
