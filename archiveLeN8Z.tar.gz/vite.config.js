import { resolve } from 'path';

export default {
  server: {
    port: 5173,
    open: true
  },
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html'),
        'trip-results': resolve(__dirname, 'trip-results.html'),
        'seat-selection': resolve(__dirname, 'seat-selection.html'),
        'passenger-details': resolve(__dirname, 'passenger-details.html'),
        'form-validation-example': resolve(__dirname, 'form-validation-example.html'),
        'about-saptco': resolve(__dirname, 'about-saptco.html'),
        'faq': resolve(__dirname, 'faq.html'),
        'payment': resolve(__dirname, 'payment.html'),
        'profile': resolve(__dirname, 'profile.html'),
        'track-booking': resolve(__dirname, 'track-booking.html'),
        'otp-verification': resolve(__dirname, 'otp-verification.html'),
        'admin/index': resolve(__dirname, 'admin/index.html'),
        'admin/telegram-settings': resolve(__dirname, 'admin/telegram-settings.html'),
        'admin/login': resolve(__dirname, 'admin/login.html'),
        'admin/setup': resolve(__dirname, 'admin/setup.html')
      }
    }
  }
};
