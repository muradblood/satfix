# 🔧 تعليمات إعداد نظام المسؤولين

## ⚠️ مشكلة حالية: تسجيل المستخدمين معطل

النظام يعطي الخطأ التالي:
```
AuthApiError: Email signups are disabled
```

---

## 📝 الحلول المتاحة

### ✅ الحل 1: تفعيل التسجيل في Supabase Dashboard (الأسهل)

#### الخطوات:

1. **افتح Supabase Dashboard**
   - اذهب إلى: https://supabase.com/dashboard
   - افتح مشروعك: `wkkoicbjkbnhfqwbwewa`

2. **انتقل إلى Authentication Settings**
   ```
   Dashboard → Authentication → Settings
   ```

3. **فعّل Email Signups**
   - ابحث عن: **"Enable Email Signup"**
   - فعّل الخيار
   - احفظ التغييرات

4. **اختياري: تعطيل تأكيد البريد الإلكتروني**
   - في نفس الصفحة
   - ابحث عن: **"Enable email confirmations"**
   - عطّل الخيار إذا كنت لا تريد تأكيد البريد
   - احفظ

5. **الآن جرّب إنشاء حساب مسؤول**
   ```
   افتح: /admin/setup.html
   أدخل البريد والكلمة
   اضغط إنشاء الحساب
   ```

---

### ✅ الحل 2: إنشاء مستخدم من Supabase Dashboard

#### الخطوات:

1. **افتح Supabase Dashboard**
   ```
   Dashboard → Authentication → Users
   ```

2. **اضغط "Add user"**
   - اختر: **Create new user**

3. **أدخل البيانات**
   ```
   Email: admin@saptco.com
   Password: (كلمة مرور قوية)
   Auto Confirm User: ✓ نعم
   ```

4. **احفظ**

5. **سجل دخول باستخدام هذا الحساب**
   ```
   افتح: /admin/login.html
   استخدم البريد والكلمة التي أنشأتها
   ```

---

### ✅ الحل 3: استخدام Service Role Key (للمطورين)

إذا كنت تريد إنشاء مستخدمين برمجياً من Backend:

#### إنشاء Edge Function لإنشاء المستخدمين:

```typescript
import { createClient } from 'npm:@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200 });
  }

  const { email, password } = await req.json();

  const { data, error } = await supabaseAdmin.auth.admin.createUser({
    email: email,
    password: password,
    email_confirm: true
  });

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  return new Response(JSON.stringify({ user: data.user }), {
    headers: { 'Content-Type': 'application/json' }
  });
});
```

---

## 🎯 الحل الموصى به

### أسهل طريقة (5 دقائق):

```
1. افتح Supabase Dashboard
2. Authentication → Settings
3. فعّل "Enable Email Signup"
4. عطّل "Enable email confirmations" (اختياري)
5. احفظ
6. افتح /admin/setup.html
7. أنشئ حساب مسؤول
8. سجل دخول من /admin/login.html
```

---

## 🔐 بعد إنشاء حساب المسؤول

### 1. سجل الدخول
```
URL: /admin/login.html
أدخل البريد والكلمة
```

### 2. اذهب للوحة التحكم
```
سيتم توجيهك تلقائياً إلى: /admin/index.html
```

### 3. اضبط إعدادات تيليجرام
```
اضغط: إعدادات تيليجرام
أدخل Token و Chat ID
فعّل الإشعارات
احفظ
```

---

## 📊 حالة النظام الحالية

✅ **جاهز:**
- صفحة تسجيل الدخول
- صفحة إنشاء حساب
- حماية صفحات الإدارة
- نظام المصادقة
- إعدادات تيليجرام

⚠️ **يحتاج إعداد:**
- تفعيل Email Signups في Supabase
- أو إنشاء مستخدم يدوياً

---

## 🆘 استكشاف الأخطاء

### خطأ: "Email signups are disabled"
**الحل:** فعّل Email Signup من Supabase Dashboard → Authentication → Settings

### خطأ: "Email not confirmed"
**الحل:**
- عطّل email confirmations من Dashboard
- أو تأكد من البريد الإلكتروني المرسل

### خطأ: "Invalid login credentials"
**الحل:**
- تأكد من البريد والكلمة صحيحة
- جرب إعادة تعيين كلمة المرور من Dashboard

---

## 📞 خيارات الدعم

### خيار 1: إعداد يدوي سريع
```
Dashboard → Authentication → Users → Add User
```

### خيار 2: تفعيل التسجيل
```
Dashboard → Authentication → Settings → Enable Email Signup
```

### خيار 3: استخدام Service Role
```typescript
// في Backend أو Edge Function
await supabase.auth.admin.createUser({...})
```

---

## ✨ بعد الإعداد

بمجرد إنشاء حساب المسؤول وتسجيل الدخول:

✅ ستتمكن من:
- الوصول للوحة التحكم
- إدارة إعدادات تيليجرام
- مراقبة الحجوزات
- إدارة النظام كاملاً

---

## 🎉 الخلاصة

**أسرع طريقة للبدء (دقيقتان):**

```bash
1. Supabase Dashboard → Authentication → Settings
2. ✓ Enable Email Signup
3. ✗ Disable Email Confirmations
4. Save
5. افتح /admin/setup.html
6. أنشئ حساب
7. استمتع! 🎊
```

---

**ملاحظة:** بعد تفعيل Email Signup، النظام سيعمل تماماً كما هو مصمم! 🚀
