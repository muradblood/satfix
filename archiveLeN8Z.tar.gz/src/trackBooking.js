import { apiClient } from './lib/api-client.js';

let currentBooking = null;

document.addEventListener('DOMContentLoaded', () => {
  const trackForm = document.getElementById('trackForm');
  const cancelBtn = document.getElementById('cancelBookingBtn');
  const downloadBtn = document.getElementById('downloadTicketBtn');

  trackForm?.addEventListener('submit', handleTrackBooking);
  cancelBtn?.addEventListener('click', handleCancelBooking);
  downloadBtn?.addEventListener('click', handleDownloadTicket);

  const urlParams = new URLSearchParams(window.location.search);
  const bookingId = urlParams.get('id');
  if (bookingId) {
    document.getElementById('bookingId').value = bookingId;
    handleTrackBooking({ preventDefault: () => {} });
  }
});

async function handleTrackBooking(e) {
  e.preventDefault();

  const bookingId = document.getElementById('bookingId').value.trim();
  if (!bookingId) return;

  showLoading();
  hideError();
  hideDetails();

  try {
    const { data: booking, error } = await supabase
      .from('bookings')
      .select(`
        *,
        trip:trips (
          *,
          route:bus_routes (
            *,
            departure_station:stations!bus_routes_departure_station_id_fkey (name, city),
            arrival_station:stations!bus_routes_arrival_station_id_fkey (name, city)
          ),
          bus:buses (name, plate_number, bus_type)
        )
      `)
      .eq('id', bookingId)
      .maybeSingle();

    if (error) throw error;

    if (!booking) {
      showError('لم يتم العثور على حجز بهذا الرقم');
      return;
    }

    const { data: passengers } = await supabase
      .from('passengers')
      .select('*')
      .eq('booking_id', bookingId);

    currentBooking = { ...booking, passengers: passengers || [] };
    displayBookingDetails(currentBooking);

  } catch (error) {
    console.error('Error fetching booking:', error);
    showError('حدث خطأ أثناء البحث عن الحجز');
  } finally {
    hideLoading();
  }
}

function displayBookingDetails(booking) {
  document.getElementById('bookingNumber').textContent = booking.id.slice(0, 8).toUpperCase();
  document.getElementById('bookingDate').textContent = formatDate(booking.booking_date);

  const statusBadge = document.getElementById('statusBadge');
  const statusText = {
    'pending': 'قيد الانتظار',
    'confirmed': 'مؤكد',
    'cancelled': 'ملغي'
  };
  const statusColors = {
    'pending': 'bg-yellow-500 text-white',
    'confirmed': 'bg-accent text-accent-foreground',
    'cancelled': 'bg-destructive text-white'
  };
  statusBadge.textContent = statusText[booking.status] || booking.status;
  statusBadge.className = `px-4 py-1.5 rounded-full text-sm font-medium ${statusColors[booking.status]}`;

  document.getElementById('departureStation').textContent =
    `${booking.trip.route.departure_station.name} - ${booking.trip.route.departure_station.city}`;
  document.getElementById('departureTime').textContent = formatDateTime(booking.trip.departure_time);

  document.getElementById('arrivalStation').textContent =
    `${booking.trip.route.arrival_station.name} - ${booking.trip.route.arrival_station.city}`;

  const arrivalTime = new Date(booking.trip.departure_time);
  arrivalTime.setMinutes(arrivalTime.getMinutes() + booking.trip.route.duration_minutes);
  document.getElementById('arrivalTime').textContent = formatDateTime(arrivalTime);

  document.getElementById('seatsCount').textContent = `${booking.seats.length} مقعد`;
  document.getElementById('totalPrice').textContent = `${booking.total_price} ريال`;

  document.getElementById('passengerName').textContent = booking.passenger_name;
  document.getElementById('passengerPhone').textContent = booking.passenger_phone;
  document.getElementById('passengerEmail').textContent = booking.passenger_email;

  if (booking.passengers && booking.passengers.length > 0) {
    displayPassengers(booking.passengers);
  }

  const cancelBtn = document.getElementById('cancelBookingBtn');
  if (booking.status === 'cancelled') {
    cancelBtn.disabled = true;
    cancelBtn.classList.add('opacity-50', 'cursor-not-allowed');
  } else {
    cancelBtn.disabled = false;
    cancelBtn.classList.remove('opacity-50', 'cursor-not-allowed');
  }

  showDetails();
}

function displayPassengers(passengers) {
  const container = document.getElementById('passengersContainer');
  const passengersList = document.getElementById('passengersList');

  container.innerHTML = passengers.map((p, index) => `
    <div class="flex items-center gap-3 p-3 bg-secondary/20 rounded-lg">
      <div class="flex items-center justify-center size-10 bg-primary text-primary-foreground rounded-full font-semibold">
        ${index + 1}
      </div>
      <div class="flex-1">
        <p class="font-semibold text-foreground">${p.name}</p>
        <p class="text-sm text-muted-foreground">مقعد ${p.seat_number} • ${p.gender === 'male' ? 'ذكر' : 'أنثى'} • ${p.age} سنة</p>
      </div>
    </div>
  `).join('');

  passengersList.classList.remove('hidden');
}

async function handleCancelBooking() {
  if (!currentBooking) return;

  if (currentBooking.status === 'cancelled') {
    showError('هذا الحجز ملغي بالفعل');
    return;
  }

  const confirmed = confirm('هل أنت متأكد من إلغاء هذا الحجز؟');
  if (!confirmed) return;

  try {
    const { error } = await supabase
      .from('bookings')
      .update({ status: 'cancelled' })
      .eq('id', currentBooking.id);

    if (error) throw error;

    const { error: tripError } = await supabase
      .from('trips')
      .update({
        available_seats: currentBooking.trip.available_seats + currentBooking.seats.length
      })
      .eq('id', currentBooking.trip.id);

    if (tripError) throw tripError;

    alert('تم إلغاء الحجز بنجاح');
    location.reload();

  } catch (error) {
    console.error('Error cancelling booking:', error);
    showError('حدث خطأ أثناء إلغاء الحجز');
  }
}

function handleDownloadTicket() {
  if (!currentBooking) return;

  alert('سيتم تحميل التذكرة قريباً');
}

function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('ar-SA', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

function formatDateTime(dateString) {
  const date = new Date(dateString);
  return date.toLocaleString('ar-SA', {
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function showLoading() {
  document.getElementById('loadingState').classList.remove('hidden');
}

function hideLoading() {
  document.getElementById('loadingState').classList.add('hidden');
}

function showError(message) {
  document.getElementById('errorMessage').textContent = message;
  document.getElementById('errorState').classList.remove('hidden');
}

function hideError() {
  document.getElementById('errorState').classList.add('hidden');
}

function showDetails() {
  document.getElementById('bookingDetails').classList.remove('hidden');
}

function hideDetails() {
  document.getElementById('bookingDetails').classList.add('hidden');
}