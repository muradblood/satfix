import { i18n } from './i18n.js';

export class LocaleUtils {
  static formatDate(date, options = {}) {
    if (!date) return '';
    const dateObj = date instanceof Date ? date : new Date(date);

    const defaultOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      ...options
    };

    try {
      return new Intl.DateTimeFormat(i18n.getLocale(), defaultOptions).format(dateObj);
    } catch (error) {
      console.error('Date formatting error:', error);
      return dateObj.toLocaleDateString();
    }
  }

  static formatTime(date, options = {}) {
    if (!date) return '';
    const dateObj = date instanceof Date ? date : new Date(date);

    const defaultOptions = {
      hour: '2-digit',
      minute: '2-digit',
      ...options
    };

    try {
      return new Intl.DateTimeFormat(i18n.getLocale(), defaultOptions).format(dateObj);
    } catch (error) {
      console.error('Time formatting error:', error);
      return dateObj.toLocaleTimeString();
    }
  }

  static formatDateTime(date, options = {}) {
    if (!date) return '';
    const dateObj = date instanceof Date ? date : new Date(date);

    const defaultOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      ...options
    };

    try {
      return new Intl.DateTimeFormat(i18n.getLocale(), defaultOptions).format(dateObj);
    } catch (error) {
      console.error('DateTime formatting error:', error);
      return dateObj.toLocaleString();
    }
  }

  static formatRelativeTime(date) {
    if (!date) return '';
    const dateObj = date instanceof Date ? date : new Date(date);
    const now = new Date();
    const diffMs = dateObj - now;
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    const diffWeeks = Math.floor(diffDays / 7);
    const diffMonths = Math.floor(diffDays / 30);
    const diffYears = Math.floor(diffDays / 365);

    try {
      const rtf = new Intl.RelativeTimeFormat(i18n.getLocale(), { numeric: 'auto' });

      if (Math.abs(diffYears) > 0) {
        return rtf.format(diffYears, 'year');
      } else if (Math.abs(diffMonths) > 0) {
        return rtf.format(diffMonths, 'month');
      } else if (Math.abs(diffWeeks) > 0) {
        return rtf.format(diffWeeks, 'week');
      } else if (Math.abs(diffDays) > 0) {
        return rtf.format(diffDays, 'day');
      } else if (Math.abs(diffHours) > 0) {
        return rtf.format(diffHours, 'hour');
      } else if (Math.abs(diffMins) > 0) {
        return rtf.format(diffMins, 'minute');
      } else {
        return rtf.format(diffSecs, 'second');
      }
    } catch (error) {
      console.error('Relative time formatting error:', error);
      return LocaleUtils.formatDate(date);
    }
  }

  static formatNumber(number, options = {}) {
    if (number === null || number === undefined || isNaN(number)) return '';

    try {
      return new Intl.NumberFormat(i18n.getLocale(), options).format(number);
    } catch (error) {
      console.error('Number formatting error:', error);
      return String(number);
    }
  }

  static formatCurrency(amount, currency = null, options = {}) {
    if (amount === null || amount === undefined || isNaN(amount)) return '';

    const currencyCode = currency || i18n.getCurrency();
    const defaultOptions = {
      style: 'currency',
      currency: currencyCode,
      ...options
    };

    try {
      return new Intl.NumberFormat(i18n.getLocale(), defaultOptions).format(amount);
    } catch (error) {
      console.error('Currency formatting error:', error);
      return `${currencyCode} ${amount}`;
    }
  }

  static formatPercent(value, options = {}) {
    if (value === null || value === undefined || isNaN(value)) return '';

    const defaultOptions = {
      style: 'percent',
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
      ...options
    };

    try {
      return new Intl.NumberFormat(i18n.getLocale(), defaultOptions).format(value);
    } catch (error) {
      console.error('Percent formatting error:', error);
      return `${value * 100}%`;
    }
  }

  static formatCompactNumber(number, options = {}) {
    if (number === null || number === undefined || isNaN(number)) return '';

    const defaultOptions = {
      notation: 'compact',
      compactDisplay: 'short',
      ...options
    };

    try {
      return new Intl.NumberFormat(i18n.getLocale(), defaultOptions).format(number);
    } catch (error) {
      console.error('Compact number formatting error:', error);
      return LocaleUtils.formatNumber(number);
    }
  }

  static formatList(items, options = {}) {
    if (!Array.isArray(items) || items.length === 0) return '';

    const defaultOptions = {
      style: 'long',
      type: 'conjunction',
      ...options
    };

    try {
      return new Intl.ListFormat(i18n.getLocale(), defaultOptions).format(items);
    } catch (error) {
      console.error('List formatting error:', error);
      return items.join(', ');
    }
  }

  static formatDuration(milliseconds) {
    if (!milliseconds || isNaN(milliseconds)) return '';

    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    const parts = [];

    if (days > 0) {
      parts.push(`${days} ${i18n.t('time.days')}`);
    }
    if (hours % 24 > 0) {
      parts.push(`${hours % 24} ${i18n.t('time.hours')}`);
    }
    if (minutes % 60 > 0) {
      parts.push(`${minutes % 60} ${i18n.t('time.minutes')}`);
    }
    if (seconds % 60 > 0 && parts.length === 0) {
      parts.push(`${seconds % 60} ${i18n.t('time.seconds')}`);
    }

    return parts.join(' ');
  }

  static formatFileSize(bytes, decimals = 2) {
    if (!bytes || isNaN(bytes)) return '0 Bytes';
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
  }

  static parseDate(dateString, locale = null) {
    if (!dateString) return null;

    try {
      const date = new Date(dateString);
      return isNaN(date.getTime()) ? null : date;
    } catch (error) {
      console.error('Date parsing error:', error);
      return null;
    }
  }

  static parseNumber(numberString, locale = null) {
    if (!numberString) return null;

    try {
      const cleanString = String(numberString).replace(/[^\d.-]/g, '');
      const number = parseFloat(cleanString);
      return isNaN(number) ? null : number;
    } catch (error) {
      console.error('Number parsing error:', error);
      return null;
    }
  }

  static getWeekDays(format = 'long') {
    const locale = i18n.getLocale();
    const formatter = new Intl.DateTimeFormat(locale, { weekday: format });
    const days = [];

    for (let i = 0; i < 7; i++) {
      const date = new Date(2024, 0, i + 1);
      days.push(formatter.format(date));
    }

    return days;
  }

  static getMonths(format = 'long') {
    const locale = i18n.getLocale();
    const formatter = new Intl.DateTimeFormat(locale, { month: format });
    const months = [];

    for (let i = 0; i < 12; i++) {
      const date = new Date(2024, i, 1);
      months.push(formatter.format(date));
    }

    return months;
  }

  static getFirstDayOfWeek() {
    const locale = i18n.getLocale();
    const rtlLocales = ['ar', 'he', 'fa'];
    return rtlLocales.some(l => locale.startsWith(l)) ? 6 : 0;
  }

  static getCalendarSystem() {
    const locale = i18n.getLocale();
    if (locale.startsWith('ar-SA')) {
      return 'islamic-umalqura';
    }
    return 'gregory';
  }

  static compareStrings(str1, str2, options = {}) {
    const defaultOptions = {
      sensitivity: 'base',
      ...options
    };

    try {
      return new Intl.Collator(i18n.getLocale(), defaultOptions).compare(str1, str2);
    } catch (error) {
      console.error('String comparison error:', error);
      return str1.localeCompare(str2);
    }
  }

  static sortStrings(strings, options = {}) {
    const defaultOptions = {
      sensitivity: 'base',
      ...options
    };

    try {
      const collator = new Intl.Collator(i18n.getLocale(), defaultOptions);
      return [...strings].sort((a, b) => collator.compare(a, b));
    } catch (error) {
      console.error('String sorting error:', error);
      return [...strings].sort();
    }
  }

  static getTextDirection() {
    return i18n.getDirection();
  }

  static isRTL() {
    return i18n.isRTL();
  }

  static getNumericSeparators() {
    const locale = i18n.getLocale();
    const formatted = new Intl.NumberFormat(locale).format(1234.56);

    const decimal = formatted.charAt(formatted.length - 3);
    const thousand = formatted.charAt(formatted.length - 7);

    return {
      decimal,
      thousand
    };
  }

  static getCurrencySymbol(currency = null) {
    const currencyCode = currency || i18n.getCurrency();
    const locale = i18n.getLocale();

    try {
      const formatter = new Intl.NumberFormat(locale, {
        style: 'currency',
        currency: currencyCode,
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      });

      const parts = formatter.formatToParts(0);
      const symbolPart = parts.find(part => part.type === 'currency');
      return symbolPart ? symbolPart.value : currencyCode;
    } catch (error) {
      console.error('Currency symbol error:', error);
      return currencyCode;
    }
  }
}

export const formatDate = LocaleUtils.formatDate.bind(LocaleUtils);
export const formatTime = LocaleUtils.formatTime.bind(LocaleUtils);
export const formatDateTime = LocaleUtils.formatDateTime.bind(LocaleUtils);
export const formatRelativeTime = LocaleUtils.formatRelativeTime.bind(LocaleUtils);
export const formatNumber = LocaleUtils.formatNumber.bind(LocaleUtils);
export const formatCurrency = LocaleUtils.formatCurrency.bind(LocaleUtils);
export const formatPercent = LocaleUtils.formatPercent.bind(LocaleUtils);
export const formatCompactNumber = LocaleUtils.formatCompactNumber.bind(LocaleUtils);
export const formatList = LocaleUtils.formatList.bind(LocaleUtils);
export const formatDuration = LocaleUtils.formatDuration.bind(LocaleUtils);
export const formatFileSize = LocaleUtils.formatFileSize.bind(LocaleUtils);
