const DARK_MODE_KEY = 'darkMode';

const darkModeStyles = {
  light: {
    '--background': '#f5f5f5',
    '--foreground': '#1a1a1a',
    '--primary': '#a77939',
    '--primary-foreground': '#ffffff',
    '--secondary': '#e8f5e9',
    '--secondary-foreground': '#1b5e20',
    '--muted': '#e0e0e0',
    '--muted-foreground': '#616161',
    '--accent': '#4caf50',
    '--accent-foreground': '#ffffff',
    '--destructive': '#d32f2f',
    '--card': '#ffffff',
    '--card-foreground': '#1a1a1a',
    '--border': '#e0e0e0',
    '--input': '#ffffff',
    '--ring': '#a77939',
  },
  dark: {
    '--background': '#0a0a0a',
    '--foreground': '#ededed',
    '--primary': '#d4a051',
    '--primary-foreground': '#1a1a1a',
    '--secondary': '#1e3a1e',
    '--secondary-foreground': '#a5d6a7',
    '--muted': '#2a2a2a',
    '--muted-foreground': '#a0a0a0',
    '--accent': '#66bb6a',
    '--accent-foreground': '#000000',
    '--destructive': '#ef5350',
    '--card': '#1a1a1a',
    '--card-foreground': '#ededed',
    '--border': '#2a2a2a',
    '--input': '#1a1a1a',
    '--ring': '#d4a051',
  }
};

class DarkMode {
  constructor() {
    this.isDark = this.loadPreference();
    this.init();
  }

  init() {
    this.applyTheme(this.isDark);
    this.setupEventListeners();
  }

  loadPreference() {
    const saved = localStorage.getItem(DARK_MODE_KEY);
    if (saved !== null) {
      return saved === 'true';
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  }

  savePreference(isDark) {
    localStorage.setItem(DARK_MODE_KEY, isDark.toString());
  }

  applyTheme(isDark) {
    const root = document.documentElement;
    const theme = isDark ? darkModeStyles.dark : darkModeStyles.light;

    Object.entries(theme).forEach(([key, value]) => {
      root.style.setProperty(key, value);
    });

    this.updateToggleButtons(isDark);
  }

  toggle() {
    this.isDark = !this.isDark;
    this.savePreference(this.isDark);
    this.applyTheme(this.isDark);

    window.dispatchEvent(new CustomEvent('darkModeChanged', {
      detail: { isDark: this.isDark }
    }));
  }

  updateToggleButtons(isDark) {
    const toggleButtons = document.querySelectorAll('[data-dark-mode-toggle]');

    toggleButtons.forEach(button => {
      const indicator = button.querySelector('[data-dark-mode-indicator]');
      if (indicator) {
        if (isDark) {
          indicator.style.right = '4px';
          indicator.style.left = 'auto';
        } else {
          indicator.style.left = '4px';
          indicator.style.right = 'auto';
        }
      }

      const icon = button.querySelector('iconify-icon');
      if (icon) {
        icon.setAttribute('icon', isDark ? 'solar:sun-bold' : 'solar:moon-bold');
      }
    });
  }

  setupEventListeners() {
    const toggleButtons = document.querySelectorAll('[data-dark-mode-toggle]');

    toggleButtons.forEach(button => {
      button.addEventListener('click', () => this.toggle());
    });

    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
      if (localStorage.getItem(DARK_MODE_KEY) === null) {
        this.isDark = e.matches;
        this.applyTheme(this.isDark);
      }
    });
  }

  getIsDark() {
    return this.isDark;
  }
}

export const darkMode = new DarkMode();