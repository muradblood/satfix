export class FormValidator {
  constructor(form) {
    this.form = form;
    this.errors = new Map();
    this.touchedFields = new Set();
    this.validationRules = new Map();
    this.realTimeValidation = true;
  }

  addRule(fieldId, rules) {
    this.validationRules.set(fieldId, rules);
    const field = document.getElementById(fieldId);
    if (field) {
      this.attachFieldListeners(field);
    }
  }

  attachFieldListeners(field) {
    field.addEventListener('blur', () => {
      this.touchedFields.add(field.id);
      this.validateField(field.id);
    });

    field.addEventListener('input', () => {
      if (this.touchedFields.has(field.id) && this.realTimeValidation) {
        this.validateField(field.id);
      }
      if (this.errors.has(field.id)) {
        this.validateField(field.id);
      }
    });

    field.addEventListener('focus', () => {
      this.clearFieldSuccess(field.id);
    });
  }

  validateField(fieldId) {
    const field = document.getElementById(fieldId);
    const rules = this.validationRules.get(fieldId);

    if (!field || !rules) return true;

    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';

    for (const rule of rules) {
      const result = rule.validate(value, field);
      if (!result.valid) {
        isValid = false;
        errorMessage = result.message;
        break;
      }
    }

    if (isValid) {
      this.clearFieldError(fieldId);
      if (this.touchedFields.has(fieldId) && value) {
        this.showFieldSuccess(fieldId);
      }
    } else {
      this.showFieldError(fieldId, errorMessage);
    }

    return isValid;
  }

  showFieldError(fieldId, message) {
    this.errors.set(fieldId, message);
    const field = document.getElementById(fieldId);
    if (!field) return;

    field.classList.remove('border-[#E0E0E0]', 'border-[#4caf50]', 'focus:border-[#a77939]');
    field.classList.add('border-[#d32f2f]', 'focus:border-[#d32f2f]', 'focus:ring-[#d32f2f]/20');
    field.setAttribute('aria-invalid', 'true');

    let errorEl = document.getElementById(`${fieldId}-error`);
    if (!errorEl) {
      errorEl = document.createElement('div');
      errorEl.id = `${fieldId}-error`;
      errorEl.className = 'flex items-start gap-2 mt-2 text-sm text-[#d32f2f] animate-slide-down';
      errorEl.setAttribute('role', 'alert');
      errorEl.setAttribute('aria-live', 'polite');
      field.parentElement.appendChild(errorEl);
    }

    errorEl.innerHTML = `
      <iconify-icon icon="solar:danger-circle-bold" class="size-4 mt-0.5 shrink-0"></iconify-icon>
      <span>${message}</span>
    `;

    field.parentElement.classList.add('shake-animation');
    setTimeout(() => field.parentElement.classList.remove('shake-animation'), 500);
  }

  clearFieldError(fieldId) {
    this.errors.delete(fieldId);
    const field = document.getElementById(fieldId);
    if (!field) return;

    field.classList.remove('border-[#d32f2f]', 'focus:border-[#d32f2f]', 'focus:ring-[#d32f2f]/20');
    field.classList.add('border-[#E0E0E0]', 'focus:border-[#a77939]');
    field.removeAttribute('aria-invalid');

    const errorEl = document.getElementById(`${fieldId}-error`);
    if (errorEl) {
      errorEl.remove();
    }
  }

  showFieldSuccess(fieldId) {
    const field = document.getElementById(fieldId);
    if (!field || this.errors.has(fieldId)) return;

    field.classList.remove('border-[#E0E0E0]', 'border-[#d32f2f]');
    field.classList.add('border-[#4caf50]');

    let successIcon = field.parentElement.querySelector('.validation-success-icon');
    if (!successIcon) {
      successIcon = document.createElement('div');
      successIcon.className = 'validation-success-icon absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none';
      successIcon.innerHTML = '<iconify-icon icon="solar:check-circle-bold" class="size-5 text-[#4caf50]"></iconify-icon>';
      field.parentElement.appendChild(successIcon);
    }
  }

  clearFieldSuccess(fieldId) {
    const field = document.getElementById(fieldId);
    if (!field) return;

    field.classList.remove('border-[#4caf50]');
    field.classList.add('border-[#E0E0E0]');

    const successIcon = field.parentElement.querySelector('.validation-success-icon');
    if (successIcon) {
      successIcon.remove();
    }
  }

  validateAll() {
    let isValid = true;
    const fieldIds = Array.from(this.validationRules.keys());

    for (const fieldId of fieldIds) {
      this.touchedFields.add(fieldId);
      if (!this.validateField(fieldId)) {
        isValid = false;
      }
    }

    if (!isValid) {
      const firstErrorField = fieldIds.find(id => this.errors.has(id));
      if (firstErrorField) {
        const field = document.getElementById(firstErrorField);
        if (field) {
          field.scrollIntoView({ behavior: 'smooth', block: 'center' });
          setTimeout(() => field.focus(), 300);
        }
      }
    }

    return isValid;
  }

  reset() {
    this.errors.clear();
    this.touchedFields.clear();

    for (const fieldId of this.validationRules.keys()) {
      this.clearFieldError(fieldId);
      this.clearFieldSuccess(fieldId);
      const field = document.getElementById(fieldId);
      if (field) {
        field.removeAttribute('aria-invalid');
      }
    }
  }

  getErrors() {
    return Array.from(this.errors.entries()).map(([field, message]) => ({
      field,
      message
    }));
  }

  hasErrors() {
    return this.errors.size > 0;
  }
}

export const ValidationRules = {
  required: (message = 'هذا الحقل مطلوب') => ({
    validate: (value) => ({
      valid: value.length > 0,
      message
    })
  }),

  minLength: (min, message = `يجب أن يحتوي على ${min} أحرف على الأقل`) => ({
    validate: (value) => ({
      valid: !value || value.length >= min,
      message
    })
  }),

  maxLength: (max, message = `يجب ألا يتجاوز ${max} حرف`) => ({
    validate: (value) => ({
      valid: !value || value.length <= max,
      message
    })
  }),

  email: (message = 'البريد الإلكتروني غير صالح') => ({
    validate: (value) => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return {
        valid: !value || emailRegex.test(value),
        message
      };
    }
  }),

  pattern: (regex, message = 'التنسيق غير صالح') => ({
    validate: (value) => ({
      valid: !value || regex.test(value),
      message
    })
  }),

  min: (min, message = `القيمة يجب أن تكون ${min} على الأقل`) => ({
    validate: (value) => ({
      valid: !value || Number(value) >= min,
      message
    })
  }),

  max: (max, message = `القيمة يجب ألا تتجاوز ${max}`) => ({
    validate: (value) => ({
      valid: !value || Number(value) <= max,
      message
    })
  }),

  dateNotPast: (message = 'لا يمكن اختيار تاريخ في الماضي') => ({
    validate: (value) => {
      if (!value) return { valid: true, message };
      const selectedDate = new Date(value);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      return {
        valid: selectedDate >= today,
        message
      };
    }
  }),

  dateAfter: (otherFieldId, message = 'التاريخ يجب أن يكون بعد تاريخ المغادرة') => ({
    validate: (value) => {
      if (!value) return { valid: true, message };
      const otherField = document.getElementById(otherFieldId);
      if (!otherField || !otherField.value) return { valid: true, message };

      const selectedDate = new Date(value);
      const otherDate = new Date(otherField.value);

      return {
        valid: selectedDate >= otherDate,
        message
      };
    }
  }),

  notSameAs: (otherFieldId, message = 'المحطتان لا يمكن أن تكونا متطابقتين') => ({
    validate: (value, field) => {
      if (!value) return { valid: true, message };
      const otherField = document.getElementById(otherFieldId);
      if (!otherField || !otherField.value) return { valid: true, message };

      return {
        valid: value.toLowerCase() !== otherField.value.toLowerCase(),
        message
      };
    }
  }),

  custom: (validatorFn, message) => ({
    validate: (value, field) => {
      const result = validatorFn(value, field);
      return {
        valid: result,
        message
      };
    }
  })
};
