import { BusDataTables } from '../components/BusDataTables.js';

/**
 * Table Management Module
 * Handles initialization and management of accessible data tables
 */

let busDataTables = null;

export function initTables() {
  busDataTables = new BusDataTables();
  
  // Add table navigation to existing tabs
  setupTableTabs();
  
  // Initialize default table view
  showTripsTable();
}

function setupTableTabs() {
  const ticketsTab = document.getElementById('tab-tickets');
  if (ticketsTab) {
    ticketsTab.addEventListener('click', () => {
      window.appState.currentTab = 'tickets';
      updateTabUI();
      showBookingsTable();
    });
  }
  
  // Update existing tab handlers to show appropriate tables
  const domesticTab = document.getElementById('tab-domestic');
  if (domesticTab) {
    domesticTab.addEventListener('click', () => {
      window.appState.currentTab = 'domestic';
      updateTabUI();
      showTripsTable();
    });
  }
}

function updateTabUI() {
  const tabs = ['tab-domestic', 'tab-international', 'tab-tickets'];
  tabs.forEach(tab => {
    const elem = document.getElementById(tab);
    if (!elem) return;

    const icon = elem.querySelector('iconify-icon');
    const text = elem.querySelector('span');
    
    if (tab === `tab-${window.appState.currentTab}`) {
      elem.classList.add('active');
      if (icon) icon.classList.add('text-[#a77939]');
      if (text) text.classList.add('text-[#a77939]');
      if (icon) icon.classList.remove('text-muted-foreground');
      if (text) text.classList.remove('text-muted-foreground');
    } else {
      elem.classList.remove('active');
      if (icon) icon.classList.remove('text-[#a77939]');
      if (text) text.classList.remove('text-[#a77939]');
      if (icon) icon.classList.add('text-muted-foreground');
      if (text) text.classList.add('text-muted-foreground');
    }
  });
}

export async function showTripsTable() {
  const resultsContainer = document.getElementById('search-results');
  if (!resultsContainer) return;
  
  // Clear existing content
  resultsContainer.innerHTML = `
    <div class="table-loading">
      <div class="loading-spinner"></div>
      <p>Loading available trips...</p>
    </div>
  `;
  
  try {
    await busDataTables.createTripsTable(resultsContainer);
  } catch (error) {
    console.error('Error showing trips table:', error);
    resultsContainer.innerHTML = `
      <div class="error-message" role="alert">
        <iconify-icon icon="solar:danger-circle-bold" class="error-icon"></iconify-icon>
        <p>Failed to load trips. Please try again.</p>
      </div>
    `;
  }
}

export async function showBookingsTable() {
  const resultsContainer = document.getElementById('search-results');
  if (!resultsContainer) return;
  
  if (!window.appState.user) {
    resultsContainer.innerHTML = `
      <div class="auth-required" role="alert">
        <iconify-icon icon="solar:user-bold" class="auth-icon"></iconify-icon>
        <h3>Login Required</h3>
        <p>Please log in to view your booking history.</p>
        <button id="login-prompt" class="auth-btn">
          <iconify-icon icon="solar:login-bold"></iconify-icon>
          Login Now
        </button>
      </div>
    `;
    
    const loginBtn = resultsContainer.querySelector('#login-prompt');
    if (loginBtn) {
      loginBtn.addEventListener('click', () => {
        const signinBtn = document.getElementById('signin-btn');
        if (signinBtn) signinBtn.click();
      });
    }
    return;
  }
  
  // Clear existing content
  resultsContainer.innerHTML = `
    <div class="table-loading">
      <div class="loading-spinner"></div>
      <p>Loading your bookings...</p>
    </div>
  `;
  
  try {
    await busDataTables.createBookingsTable(resultsContainer, window.appState.user.id);
  } catch (error) {
    console.error('Error showing bookings table:', error);
    resultsContainer.innerHTML = `
      <div class="error-message" role="alert">
        <iconify-icon icon="solar:danger-circle-bold" class="error-icon"></iconify-icon>
        <p>Failed to load your bookings. Please try again.</p>
      </div>
    `;
  }
}

export async function showStationsTable() {
  const resultsContainer = document.getElementById('search-results');
  if (!resultsContainer) return;
  
  // Clear existing content
  resultsContainer.innerHTML = `
    <div class="table-loading">
      <div class="loading-spinner"></div>
      <p>Loading stations...</p>
    </div>
  `;
  
  try {
    await busDataTables.createStationsTable(resultsContainer);
  } catch (error) {
    console.error('Error showing stations table:', error);
    resultsContainer.innerHTML = `
      <div class="error-message" role="alert">
        <iconify-icon icon="solar:danger-circle-bold" class="error-icon"></iconify-icon>
        <p>Failed to load stations. Please try again.</p>
      </div>
    `;
  }
}

// Export the tables instance for external use
export function getTablesInstance() {
  return busDataTables;
}

// Global functions for table actions
window.viewBooking = async function(bookingId) {
  // Create a modal or navigate to booking details
  console.log('Viewing booking:', bookingId);
  
  // For now, show an alert - in a real app, this would open a detailed view
  alert(`Viewing booking details for: ${bookingId}`);
};

window.cancelBooking = async function(bookingId) {
  if (!confirm('Are you sure you want to cancel this booking?')) {
    return;
  }
  
  try {
    // In a real app, this would make an API call to cancel the booking
    console.log('Canceling booking:', bookingId);
    alert('Booking cancellation functionality will be implemented soon.');
    
    // Refresh the bookings table
    if (window.appState.currentTab === 'tickets') {
      showBookingsTable();
    }
  } catch (error) {
    console.error('Error canceling booking:', error);
    alert('Failed to cancel booking. Please try again.');
  }
};