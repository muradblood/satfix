export class I18n {
  constructor() {
    this.currentLocale = 'ar';
    this.defaultLocale = 'ar';
    this.translations = {};
    this.fallbackTranslations = {};
    this.formatters = {};
    this.loadedLocales = new Set();
    this.changeListeners = [];
  }

  async init(locale = 'ar') {
    this.currentLocale = locale;
    await this.loadLocale(locale);

    if (locale !== this.defaultLocale) {
      await this.loadLocale(this.defaultLocale);
      this.fallbackTranslations = this.translations[this.defaultLocale] || {};
    }

    this.setupFormatters();
    this.updateDocumentAttributes();
  }

  async loadLocale(locale) {
    if (this.loadedLocales.has(locale)) {
      return;
    }

    try {
      const module = await import(`../locales/${locale}.js`);
      this.translations[locale] = module.default;
      this.loadedLocales.add(locale);
    } catch (error) {
      console.error(`Failed to load locale: ${locale}`, error);
      throw error;
    }
  }

  async changeLocale(locale) {
    if (locale === this.currentLocale) {
      return;
    }

    await this.loadLocale(locale);
    this.currentLocale = locale;
    this.setupFormatters();
    this.updateDocumentAttributes();
    this.notifyListeners();
  }

  t(key, params = {}) {
    const translation = this.getTranslation(key);
    return this.interpolate(translation, params);
  }

  getTranslation(key) {
    const keys = key.split('.');
    let value = this.translations[this.currentLocale];

    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return this.getFallbackTranslation(key);
      }
    }

    return typeof value === 'string' ? value : key;
  }

  getFallbackTranslation(key) {
    const keys = key.split('.');
    let value = this.fallbackTranslations;

    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        console.warn(`Missing translation for key: ${key}`);
        return key;
      }
    }

    return typeof value === 'string' ? value : key;
  }

  interpolate(text, params) {
    if (!params || typeof text !== 'string') {
      return text;
    }

    return text.replace(/\{(\w+)\}/g, (match, key) => {
      return params[key] !== undefined ? params[key] : match;
    });
  }

  setupFormatters() {
    try {
      this.formatters = {
        date: new Intl.DateTimeFormat(this.currentLocale),
        time: new Intl.DateTimeFormat(this.currentLocale, {
          hour: '2-digit',
          minute: '2-digit'
        }),
        datetime: new Intl.DateTimeFormat(this.currentLocale, {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        shortDate: new Intl.DateTimeFormat(this.currentLocale, {
          year: 'numeric',
          month: 'short',
          day: 'numeric'
        }),
        longDate: new Intl.DateTimeFormat(this.currentLocale, {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          weekday: 'long'
        }),
        number: new Intl.NumberFormat(this.currentLocale),
        currency: new Intl.NumberFormat(this.currentLocale, {
          style: 'currency',
          currency: this.getCurrency()
        }),
        percent: new Intl.NumberFormat(this.currentLocale, {
          style: 'percent',
          minimumFractionDigits: 0,
          maximumFractionDigits: 2
        })
      };
    } catch (error) {
      console.error('Failed to setup formatters:', error);
    }
  }

  formatDate(date, format = 'date') {
    if (!date) return '';
    const dateObj = date instanceof Date ? date : new Date(date);

    try {
      return this.formatters[format]?.format(dateObj) || dateObj.toLocaleDateString(this.currentLocale);
    } catch (error) {
      console.error('Date formatting error:', error);
      return String(date);
    }
  }

  formatNumber(number, format = 'number') {
    if (number === null || number === undefined) return '';

    try {
      return this.formatters[format]?.format(number) || String(number);
    } catch (error) {
      console.error('Number formatting error:', error);
      return String(number);
    }
  }

  formatCurrency(amount, currency) {
    if (amount === null || amount === undefined) return '';

    try {
      const formatter = new Intl.NumberFormat(this.currentLocale, {
        style: 'currency',
        currency: currency || this.getCurrency()
      });
      return formatter.format(amount);
    } catch (error) {
      console.error('Currency formatting error:', error);
      return String(amount);
    }
  }

  formatRelativeTime(date) {
    if (!date) return '';
    const dateObj = date instanceof Date ? date : new Date(date);
    const now = new Date();
    const diffMs = dateObj - now;
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    try {
      const rtf = new Intl.RelativeTimeFormat(this.currentLocale, { numeric: 'auto' });

      if (Math.abs(diffDays) > 0) {
        return rtf.format(diffDays, 'day');
      } else if (Math.abs(diffHours) > 0) {
        return rtf.format(diffHours, 'hour');
      } else if (Math.abs(diffMins) > 0) {
        return rtf.format(diffMins, 'minute');
      } else {
        return rtf.format(diffSecs, 'second');
      }
    } catch (error) {
      console.error('Relative time formatting error:', error);
      return this.formatDate(date);
    }
  }

  getCurrency() {
    const currencyMap = {
      'ar': 'SAR',
      'ar-SA': 'SAR',
      'en': 'USD',
      'en-US': 'USD',
      'en-GB': 'GBP'
    };
    return currencyMap[this.currentLocale] || 'SAR';
  }

  getDirection() {
    return this.isRTL() ? 'rtl' : 'ltr';
  }

  isRTL() {
    const rtlLocales = ['ar', 'he', 'fa', 'ur'];
    return rtlLocales.some(locale => this.currentLocale.startsWith(locale));
  }

  getLocale() {
    return this.currentLocale;
  }

  getAvailableLocales() {
    return ['ar', 'en'];
  }

  updateDocumentAttributes() {
    const html = document.documentElement;
    html.setAttribute('lang', this.currentLocale);
    html.setAttribute('dir', this.getDirection());
  }

  onLocaleChange(callback) {
    this.changeListeners.push(callback);
  }

  offLocaleChange(callback) {
    this.changeListeners = this.changeListeners.filter(cb => cb !== callback);
  }

  notifyListeners() {
    this.changeListeners.forEach(callback => {
      try {
        callback(this.currentLocale);
      } catch (error) {
        console.error('Error in locale change listener:', error);
      }
    });
  }

  pluralize(key, count, params = {}) {
    const pluralKey = this.getPluralKey(count);
    const fullKey = `${key}.${pluralKey}`;
    return this.t(fullKey, { ...params, count });
  }

  getPluralKey(count) {
    if (this.currentLocale.startsWith('ar')) {
      if (count === 0) return 'zero';
      if (count === 1) return 'one';
      if (count === 2) return 'two';
      if (count >= 3 && count <= 10) return 'few';
      if (count >= 11 && count <= 99) return 'many';
      return 'other';
    } else {
      return count === 1 ? 'one' : 'other';
    }
  }

  exists(key) {
    const keys = key.split('.');
    let value = this.translations[this.currentLocale];

    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        return false;
      }
    }

    return typeof value === 'string';
  }
}

export const i18n = new I18n();

export function t(key, params) {
  return i18n.t(key, params);
}

export function formatDate(date, format) {
  return i18n.formatDate(date, format);
}

export function formatNumber(number, format) {
  return i18n.formatNumber(number, format);
}

export function formatCurrency(amount, currency) {
  return i18n.formatCurrency(amount, currency);
}

export function formatRelativeTime(date) {
  return i18n.formatRelativeTime(date);
}
