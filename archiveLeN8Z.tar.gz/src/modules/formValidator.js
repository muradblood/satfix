export class FormValidator {
  constructor(form, options = {}) {
    this.form = form;
    this.fields = new Map();
    this.isValid = false;
    this.options = {
      validateOnInput: true,
      validateOnBlur: true,
      showSuccessIndicators: true,
      debounceDelay: 300,
      ...options
    };

    this.debounceTimers = new Map();
  }

  addField(fieldName, rules) {
    const element = this.form.querySelector(`[name="${fieldName}"]`);
    if (!element) {
      console.warn(`Field ${fieldName} not found in form`);
      return this;
    }

    this.fields.set(fieldName, {
      element,
      rules,
      errors: [],
      touched: false,
      valid: false
    });

    this.attachListeners(fieldName);
    return this;
  }

  attachListeners(fieldName) {
    const field = this.fields.get(fieldName);
    if (!field) return;

    const { element } = field;

    if (this.options.validateOnInput) {
      element.addEventListener('input', () => {
        field.touched = true;
        this.debounceValidate(fieldName);
      });
    }

    if (this.options.validateOnBlur) {
      element.addEventListener('blur', () => {
        field.touched = true;
        this.validateField(fieldName);
      });
    }

    element.addEventListener('focus', () => {
      this.clearFieldError(fieldName);
    });
  }

  debounceValidate(fieldName) {
    if (this.debounceTimers.has(fieldName)) {
      clearTimeout(this.debounceTimers.get(fieldName));
    }

    const timer = setTimeout(() => {
      this.validateField(fieldName);
    }, this.options.debounceDelay);

    this.debounceTimers.set(fieldName, timer);
  }

  validateField(fieldName) {
    const field = this.fields.get(fieldName);
    if (!field) return false;

    const { element, rules } = field;
    const value = element.value.trim();
    field.errors = [];

    for (const rule of rules) {
      const result = rule.validator(value, element);
      if (!result) {
        field.errors.push(rule.message);
        break;
      }
    }

    field.valid = field.errors.length === 0;
    this.updateFieldUI(fieldName);

    return field.valid;
  }

  validateAll() {
    let allValid = true;

    for (const [fieldName] of this.fields) {
      const isValid = this.validateField(fieldName);
      if (!isValid) {
        allValid = false;
      }
    }

    this.isValid = allValid;
    return allValid;
  }

  updateFieldUI(fieldName) {
    const field = this.fields.get(fieldName);
    if (!field || !field.touched) return;

    const { element, errors, valid } = field;
    const wrapper = element.closest('.form-field');

    if (!wrapper) return;

    wrapper.classList.remove('field-valid', 'field-error');

    const existingError = wrapper.querySelector('.field-error-message');
    if (existingError) {
      existingError.remove();
    }

    const existingSuccess = wrapper.querySelector('.field-success-indicator');
    if (existingSuccess) {
      existingSuccess.remove();
    }

    if (errors.length > 0) {
      wrapper.classList.add('field-error');
      this.showError(wrapper, errors[0]);
    } else if (valid && this.options.showSuccessIndicators) {
      wrapper.classList.add('field-valid');
      this.showSuccess(wrapper);
    }
  }

  showError(wrapper, message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'field-error-message';
    errorDiv.innerHTML = `
      <div class="flex items-start gap-2 mt-2 text-sm text-destructive">
        <iconify-icon icon="solar:danger-circle-bold" class="size-4 mt-0.5 flex-shrink-0"></iconify-icon>
        <span>${message}</span>
      </div>
    `;
    wrapper.appendChild(errorDiv);
  }

  showSuccess(wrapper) {
    const successDiv = document.createElement('div');
    successDiv.className = 'field-success-indicator';
    successDiv.innerHTML = `
      <div class="absolute left-3 top-1/2 -translate-y-1/2 text-accent pointer-events-none">
        <iconify-icon icon="solar:check-circle-bold" class="size-5"></iconify-icon>
      </div>
    `;

    const inputWrapper = wrapper.querySelector('.relative');
    if (inputWrapper) {
      inputWrapper.appendChild(successDiv);
    }
  }

  clearFieldError(fieldName) {
    const field = this.fields.get(fieldName);
    if (!field) return;

    const wrapper = field.element.closest('.form-field');
    if (!wrapper) return;

    wrapper.classList.remove('field-error');

    const errorMessage = wrapper.querySelector('.field-error-message');
    if (errorMessage) {
      errorMessage.style.opacity = '0';
      setTimeout(() => errorMessage.remove(), 200);
    }
  }

  reset() {
    for (const [fieldName, field] of this.fields) {
      field.errors = [];
      field.touched = false;
      field.valid = false;

      const wrapper = field.element.closest('.form-field');
      if (wrapper) {
        wrapper.classList.remove('field-valid', 'field-error');
        const errorMsg = wrapper.querySelector('.field-error-message');
        const successInd = wrapper.querySelector('.field-success-indicator');
        if (errorMsg) errorMsg.remove();
        if (successInd) successInd.remove();
      }
    }

    this.isValid = false;
  }

  getValues() {
    const values = {};
    for (const [fieldName, field] of this.fields) {
      values[fieldName] = field.element.value.trim();
    }
    return values;
  }
}

export const validators = {
  required: (message = 'هذا الحقل مطلوب') => ({
    validator: (value) => value.length > 0,
    message
  }),

  minLength: (min, message) => ({
    validator: (value) => value.length >= min,
    message: message || `يجب أن يحتوي هذا الحقل على ${min} أحرف على الأقل`
  }),

  maxLength: (max, message) => ({
    validator: (value) => value.length <= max,
    message: message || `يجب أن لا يتجاوز هذا الحقل ${max} حرف`
  }),

  email: (message = 'يرجى إدخال بريد إلكتروني صحيح') => ({
    validator: (value) => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(value);
    },
    message
  }),

  phone: (message = 'يرجى إدخال رقم هاتف صحيح') => ({
    validator: (value) => {
      const phoneRegex = /^(05|5)\d{8}$/;
      return phoneRegex.test(value.replace(/[\s-]/g, ''));
    },
    message
  }),

  nationalId: (message = 'يرجى إدخال رقم هوية وطنية صحيح (10 أرقام)') => ({
    validator: (value) => {
      const idRegex = /^[12]\d{9}$/;
      return idRegex.test(value);
    },
    message
  }),

  notEqual: (compareFieldName, message) => ({
    validator: (value, element) => {
      const form = element.closest('form');
      const compareField = form?.querySelector(`[name="${compareFieldName}"]`);
      return compareField ? value !== compareField.value : true;
    },
    message: message || 'محطة الوصول يجب أن تختلف عن محطة المغادرة'
  }),

  dateAfter: (compareFieldName, message) => ({
    validator: (value, element) => {
      if (!value) return true;
      const form = element.closest('form');
      const compareField = form?.querySelector(`[name="${compareFieldName}"]`);
      if (!compareField?.value) return true;
      return new Date(value) >= new Date(compareField.value);
    },
    message: message || 'تاريخ العودة يجب أن يكون بعد تاريخ المغادرة'
  }),

  futureDate: (message = 'يرجى اختيار تاريخ في المستقبل') => ({
    validator: (value) => {
      if (!value) return true;
      const selectedDate = new Date(value);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      return selectedDate >= today;
    },
    message
  }),

  minValue: (min, message) => ({
    validator: (value) => {
      const num = parseInt(value);
      return !isNaN(num) && num >= min;
    },
    message: message || `القيمة يجب أن تكون ${min} على الأقل`
  }),

  maxValue: (max, message) => ({
    validator: (value) => {
      const num = parseInt(value);
      return !isNaN(num) && num <= max;
    },
    message: message || `القيمة يجب أن لا تتجاوز ${max}`
  }),

  custom: (validatorFn, message) => ({
    validator: validatorFn,
    message
  })
};

export function showSuccessMessage(message, duration = 3000) {
  const existingMessage = document.querySelector('.success-toast');
  if (existingMessage) {
    existingMessage.remove();
  }

  const toast = document.createElement('div');
  toast.className = 'success-toast';
  toast.innerHTML = `
    <div class="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-slide-down">
      <div class="bg-accent text-accent-foreground px-6 py-4 rounded-xl shadow-lg flex items-center gap-3 min-w-[300px]">
        <iconify-icon icon="solar:check-circle-bold" class="size-6 flex-shrink-0"></iconify-icon>
        <p class="font-medium">${message}</p>
      </div>
    </div>
  `;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-20px)';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

export function showErrorMessage(message, duration = 4000) {
  const existingMessage = document.querySelector('.error-toast');
  if (existingMessage) {
    existingMessage.remove();
  }

  const toast = document.createElement('div');
  toast.className = 'error-toast';
  toast.innerHTML = `
    <div class="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-slide-down">
      <div class="bg-destructive text-white px-6 py-4 rounded-xl shadow-lg flex items-center gap-3 min-w-[300px]">
        <iconify-icon icon="solar:danger-circle-bold" class="size-6 flex-shrink-0"></iconify-icon>
        <p class="font-medium">${message}</p>
      </div>
    </div>
  `;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(-20px)';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

export function showLoadingOverlay(message = 'جارٍ المعالجة...') {
  const existingOverlay = document.querySelector('.loading-overlay');
  if (existingOverlay) return;

  const overlay = document.createElement('div');
  overlay.className = 'loading-overlay';
  overlay.innerHTML = `
    <div class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
      <div class="bg-card rounded-2xl p-8 flex flex-col items-center gap-4 shadow-2xl">
        <div class="size-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p class="text-foreground font-medium">${message}</p>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
}

export function hideLoadingOverlay() {
  const overlay = document.querySelector('.loading-overlay');
  if (overlay) {
    overlay.style.opacity = '0';
    setTimeout(() => overlay.remove(), 200);
  }
}
