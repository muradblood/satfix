import { apiClient } from '../main.js';

export async function initAuth() {
  const { data: { session } } = await supabase.auth.getSession();

  if (session) {
    window.appState.user = session.user;
  }

  supabase.auth.onAuthStateChange((event, session) => {
    window.appState.user = session?.user || null;
    updateAuthUI();
  });

  setupAuthModal();
}

function setupAuthModal() {
  const authCloseBtn = document.getElementById('auth-close');
  const authCloseXBtn = document.getElementById('auth-close-x');
  const authLoginBtn = document.getElementById('auth-login');
  const authSignupBtn = document.getElementById('auth-signup');
  const signinBtn = document.getElementById('signin-btn');
  const authEmail = document.getElementById('auth-email');
  const authPassword = document.getElementById('auth-password');

  if (signinBtn) {
    signinBtn.addEventListener('click', showAuthModal);
  }

  if (authCloseBtn) {
    authCloseBtn.addEventListener('click', hideAuthModal);
  }

  if (authCloseXBtn) {
    authCloseXBtn.addEventListener('click', hideAuthModal);
  }

  if (authLoginBtn) {
    authLoginBtn.addEventListener('click', handleLogin);
  }

  if (authSignupBtn) {
    authSignupBtn.addEventListener('click', handleSignup);
  }

  if (authEmail && authPassword) {
    const handleEnterKey = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleLogin();
      }
    };

    authEmail.addEventListener('keypress', handleEnterKey);
    authPassword.addEventListener('keypress', handleEnterKey);
  }
}

async function handleLogin() {
  const email = document.getElementById('auth-email')?.value;
  const password = document.getElementById('auth-password')?.value;
  const loginBtn = document.getElementById('auth-login');

  if (!email || !password) {
    showToast('يرجى ملء جميع الحقول', 'error');
    return;
  }

  if (!isValidEmail(email)) {
    showToast('يرجى إدخال بريد إلكتروني صحيح', 'error');
    return;
  }

  if (password.length < 6) {
    showToast('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'error');
    return;
  }

  try {
    loginBtn.disabled = true;
    loginBtn.textContent = 'جاري الدخول...';

    await signIn(email, password);
    hideAuthModal();
    showToast('مرحباً بك! تم تسجيل الدخول بنجاح', 'success');
  } catch (error) {
    console.error('Login error:', error);
    const message = error.message.includes('Invalid login')
      ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
      : 'حدث خطأ في تسجيل الدخول، يرجى المحاولة مرة أخرى';
    showToast(message, 'error');
  } finally {
    loginBtn.disabled = false;
    loginBtn.textContent = 'دخول';
  }
}

async function handleSignup() {
  const email = document.getElementById('auth-email')?.value;
  const password = document.getElementById('auth-password')?.value;
  const signupBtn = document.getElementById('auth-signup');

  if (!email || !password) {
    showToast('يرجى ملء جميع الحقول', 'error');
    return;
  }

  if (!isValidEmail(email)) {
    showToast('يرجى إدخال بريد إلكتروني صحيح', 'error');
    return;
  }

  if (password.length < 6) {
    showToast('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'error');
    return;
  }

  try {
    signupBtn.disabled = true;
    signupBtn.textContent = 'جاري الإنشاء...';

    await signUp(email, password);
    hideAuthModal();
    showToast('تم إنشاء الحساب بنجاح! مرحباً بك', 'success');
  } catch (error) {
    console.error('Signup error:', error);
    const message = error.message.includes('already registered')
      ? 'هذا البريد الإلكتروني مسجل مسبقاً'
      : 'حدث خطأ في إنشاء الحساب، يرجى المحاولة مرة أخرى';
    showToast(message, 'error');
  } finally {
    signupBtn.disabled = false;
    signupBtn.textContent = 'إنشاء حساب';
  }
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `fixed top-20 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-xl shadow-lg text-white font-medium text-sm sm:text-base ${
    type === 'error' ? 'bg-red-500' : type === 'success' ? 'bg-green-500' : 'bg-[#a77939]'
  } animate-slide-down`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

export async function signUp(email, password) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: window.location.origin
    }
  });

  if (error) throw error;
  return data;
}

export async function signIn(email, password) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) throw error;
  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

function updateAuthUI() {
  const authSection = document.getElementById('auth-section');
  if (!authSection) return;

  if (window.appState.user) {
    const emailParts = window.appState.user.email.split('@');
    const displayEmail = emailParts[0].length > 8 ? emailParts[0].substring(0, 8) + '...' : emailParts[0];

    authSection.innerHTML = `
      <div class="flex items-center gap-2 sm:gap-3">
        <span class="hidden sm:inline text-xs sm:text-sm text-foreground truncate max-w-[120px]">${window.appState.user.email}</span>
        <span class="inline sm:hidden text-xs text-foreground">${displayEmail}</span>
        <button id="signout-btn" class="px-3 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm bg-red-500 text-white rounded-lg hover:bg-red-600 active:scale-95 transition whitespace-nowrap">خروج</button>
      </div>
    `;
    document.getElementById('signout-btn')?.addEventListener('click', async () => {
      try {
        await signOut();
        showToast('تم تسجيل الخروج بنجاح', 'success');
      } catch (error) {
        console.error('Signout error:', error);
        showToast('حدث خطأ في تسجيل الخروج', 'error');
      }
    });
  } else {
    authSection.innerHTML = `
      <button id="signin-btn" class="px-3 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm bg-[#a77939] text-white rounded-lg hover:bg-[#935c2e] transition active:scale-95 whitespace-nowrap">دخول</button>
    `;
    document.getElementById('signin-btn')?.addEventListener('click', showAuthModal);
  }
}

export function showAuthModal() {
  const modal = document.getElementById('auth-modal');
  if (!modal) return;

  document.getElementById('auth-email').value = '';
  document.getElementById('auth-password').value = '';

  modal.classList.remove('hidden');
  modal.classList.add('flex');
}

export function hideAuthModal() {
  const modal = document.getElementById('auth-modal');
  if (!modal) return;

  modal.classList.add('hidden');
  modal.classList.remove('flex');
}
