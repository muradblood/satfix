import { i18n } from './i18n.js';

export class LayoutManager {
  constructor() {
    this.currentDirection = 'rtl';
    this.transitionDuration = 300;
    this.directionChangeCallbacks = [];
  }

  init() {
    this.currentDirection = i18n.getDirection();
    this.applyDirection(this.currentDirection);

    i18n.onLocaleChange(() => {
      const newDirection = i18n.getDirection();
      if (newDirection !== this.currentDirection) {
        this.changeDirection(newDirection);
      }
    });
  }

  changeDirection(direction) {
    if (direction === this.currentDirection) {
      return;
    }

    this.currentDirection = direction;
    this.applyDirection(direction);
    this.notifyDirectionChange(direction);
  }

  applyDirection(direction) {
    const html = document.documentElement;
    const body = document.body;

    html.setAttribute('dir', direction);
    html.setAttribute('lang', i18n.getLocale());

    body.classList.remove('rtl', 'ltr');
    body.classList.add(direction);

    this.updateFlexboxDirections(direction);
    this.updatePositioningStyles(direction);
    this.updateTransformOrigins(direction);
    this.updateTextAlign(direction);
  }

  updateFlexboxDirections(direction) {
    const flexContainers = document.querySelectorAll('[data-flex-dir]');
    flexContainers.forEach(container => {
      const originalDir = container.getAttribute('data-flex-dir');
      if (direction === 'rtl') {
        if (originalDir === 'row') {
          container.style.flexDirection = 'row-reverse';
        } else if (originalDir === 'row-reverse') {
          container.style.flexDirection = 'row';
        }
      } else {
        container.style.flexDirection = originalDir;
      }
    });
  }

  updatePositioningStyles(direction) {
    const elements = document.querySelectorAll('[data-logical-props]');
    elements.forEach(element => {
      const props = JSON.parse(element.getAttribute('data-logical-props'));

      if (direction === 'rtl') {
        if (props.left !== undefined) {
          element.style.right = props.left;
          element.style.left = 'auto';
        }
        if (props.right !== undefined) {
          element.style.left = props.right;
          element.style.right = 'auto';
        }
        if (props.marginLeft !== undefined) {
          element.style.marginRight = props.marginLeft;
          element.style.marginLeft = 'auto';
        }
        if (props.marginRight !== undefined) {
          element.style.marginLeft = props.marginRight;
          element.style.marginRight = 'auto';
        }
        if (props.paddingLeft !== undefined) {
          element.style.paddingRight = props.paddingLeft;
          element.style.paddingLeft = 'auto';
        }
        if (props.paddingRight !== undefined) {
          element.style.paddingLeft = props.paddingRight;
          element.style.paddingRight = 'auto';
        }
      } else {
        Object.keys(props).forEach(prop => {
          element.style[prop] = props[prop];
        });
      }
    });
  }

  updateTransformOrigins(direction) {
    const elements = document.querySelectorAll('[data-transform-origin]');
    elements.forEach(element => {
      const origin = element.getAttribute('data-transform-origin');
      if (direction === 'rtl') {
        const flipped = origin.replace(/left/g, 'temp')
          .replace(/right/g, 'left')
          .replace(/temp/g, 'right');
        element.style.transformOrigin = flipped;
      } else {
        element.style.transformOrigin = origin;
      }
    });
  }

  updateTextAlign(direction) {
    const elements = document.querySelectorAll('[data-text-align]');
    elements.forEach(element => {
      const align = element.getAttribute('data-text-align');
      if (direction === 'rtl') {
        if (align === 'left') {
          element.style.textAlign = 'right';
        } else if (align === 'right') {
          element.style.textAlign = 'left';
        }
      } else {
        element.style.textAlign = align;
      }
    });
  }

  getLogicalProperty(property, value) {
    const direction = this.currentDirection;
    const logicalMap = {
      'margin-left': direction === 'rtl' ? 'margin-inline-end' : 'margin-inline-start',
      'margin-right': direction === 'rtl' ? 'margin-inline-start' : 'margin-inline-end',
      'padding-left': direction === 'rtl' ? 'padding-inline-end' : 'padding-inline-start',
      'padding-right': direction === 'rtl' ? 'padding-inline-start' : 'padding-inline-end',
      'border-left': direction === 'rtl' ? 'border-inline-end' : 'border-inline-start',
      'border-right': direction === 'rtl' ? 'border-inline-start' : 'border-inline-end',
      'left': direction === 'rtl' ? 'inset-inline-end' : 'inset-inline-start',
      'right': direction === 'rtl' ? 'inset-inline-start' : 'inset-inline-end'
    };

    return logicalMap[property] || property;
  }

  getDirection() {
    return this.currentDirection;
  }

  isRTL() {
    return this.currentDirection === 'rtl';
  }

  onDirectionChange(callback) {
    this.directionChangeCallbacks.push(callback);
  }

  offDirectionChange(callback) {
    this.directionChangeCallbacks = this.directionChangeCallbacks.filter(cb => cb !== callback);
  }

  notifyDirectionChange(direction) {
    this.directionChangeCallbacks.forEach(callback => {
      try {
        callback(direction);
      } catch (error) {
        console.error('Error in direction change callback:', error);
      }
    });
  }

  applyLogicalStyles(element, styles) {
    Object.keys(styles).forEach(property => {
      const logicalProperty = this.getLogicalProperty(property, styles[property]);
      element.style[logicalProperty] = styles[property];
    });
  }

  createMirroredIcon(iconName) {
    const direction = this.currentDirection;
    const mirrorIcons = [
      'arrow-left',
      'arrow-right',
      'chevron-left',
      'chevron-right',
      'angle-left',
      'angle-right'
    ];

    if (direction === 'rtl' && mirrorIcons.some(icon => iconName.includes(icon))) {
      return iconName.replace('left', 'temp')
        .replace('right', 'left')
        .replace('temp', 'right');
    }

    return iconName;
  }

  getStartPosition() {
    return this.isRTL() ? 'right' : 'left';
  }

  getEndPosition() {
    return this.isRTL() ? 'left' : 'right';
  }

  flipHorizontalValue(value) {
    if (typeof value === 'string') {
      return value.replace(/left/g, 'temp')
        .replace(/right/g, 'left')
        .replace(/temp/g, 'right');
    }
    return value;
  }

  convertToLogicalProperties(styles) {
    const converted = { ...styles };
    const propertyMap = {
      'marginLeft': 'marginInlineStart',
      'marginRight': 'marginInlineEnd',
      'paddingLeft': 'paddingInlineStart',
      'paddingRight': 'paddingInlineEnd',
      'borderLeft': 'borderInlineStart',
      'borderRight': 'borderInlineEnd',
      'left': 'insetInlineStart',
      'right': 'insetInlineEnd',
      'textAlign': styles.textAlign === 'left' ? 'start' : styles.textAlign === 'right' ? 'end' : styles.textAlign
    };

    Object.keys(propertyMap).forEach(oldProp => {
      if (oldProp in converted) {
        converted[propertyMap[oldProp]] = converted[oldProp];
        delete converted[oldProp];
      }
    });

    return converted;
  }

  addDirectionAwareClass(element, className) {
    const direction = this.currentDirection;
    element.classList.add(`${className}-${direction}`);
  }

  removeDirectionAwareClass(element, className) {
    element.classList.remove(`${className}-rtl`, `${className}-ltr`);
  }

  getAlignmentValue(alignment) {
    if (alignment === 'start') {
      return this.isRTL() ? 'right' : 'left';
    } else if (alignment === 'end') {
      return this.isRTL() ? 'left' : 'right';
    }
    return alignment;
  }

  mirrorTransform(transform) {
    if (!this.isRTL()) {
      return transform;
    }

    return transform.replace(/translateX\(([-\d.]+)/g, (match, value) => {
      return `translateX(${-parseFloat(value)}`;
    }).replace(/scaleX\(([-\d.]+)/g, (match, value) => {
      return `scaleX(${-parseFloat(value)}`;
    });
  }

  getScrollbarPosition() {
    return this.isRTL() ? 'left' : 'right';
  }

  adjustForScrollbar(element) {
    const scrollbarWidth = this.getScrollbarWidth();
    const position = this.getScrollbarPosition();

    if (position === 'left') {
      element.style.paddingLeft = `${scrollbarWidth}px`;
    } else {
      element.style.paddingRight = `${scrollbarWidth}px`;
    }
  }

  getScrollbarWidth() {
    const outer = document.createElement('div');
    outer.style.visibility = 'hidden';
    outer.style.overflow = 'scroll';
    document.body.appendChild(outer);

    const inner = document.createElement('div');
    outer.appendChild(inner);

    const scrollbarWidth = outer.offsetWidth - inner.offsetWidth;
    outer.parentNode.removeChild(outer);

    return scrollbarWidth;
  }
}

export const layoutManager = new LayoutManager();
