export class FeedbackManager {
  constructor() {
    this.container = null;
    this.initContainer();
  }

  initContainer() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.id = 'feedback-container';
      this.container.className = 'fixed top-4 left-1/2 -translate-x-1/2 z-[100] flex flex-col gap-3 w-full max-w-md px-4';
      this.container.setAttribute('role', 'status');
      this.container.setAttribute('aria-live', 'polite');
      document.body.appendChild(this.container);
    }
  }

  showSuccess(message, duration = 5000) {
    this.showNotification(message, 'success', duration);
  }

  showError(message, duration = 7000) {
    this.showNotification(message, 'error', duration);
  }

  showWarning(message, duration = 6000) {
    this.showNotification(message, 'warning', duration);
  }

  showInfo(message, duration = 5000) {
    this.showNotification(message, 'info', duration);
  }

  showNotification(message, type = 'info', duration = 5000) {
    const notification = document.createElement('div');
    const id = `notification-${Date.now()}`;
    notification.id = id;
    notification.className = 'notification-item animate-slide-down';

    const config = this.getTypeConfig(type);

    notification.innerHTML = `
      <div class="bg-white rounded-xl shadow-2xl border-l-4 ${config.borderColor} p-4 flex items-start gap-3">
        <div class="${config.iconBg} rounded-full p-2 shrink-0">
          <iconify-icon icon="${config.icon}" class="${config.iconColor} size-5"></iconify-icon>
        </div>
        <div class="flex-1 min-w-0">
          <p class="text-sm font-medium text-foreground leading-relaxed">${message}</p>
        </div>
        <button
          onclick="document.getElementById('${id}').remove()"
          class="shrink-0 hover:bg-[#F5F5F5] rounded-lg p-1 transition"
          aria-label="إغلاق التنبيه"
        >
          <iconify-icon icon="solar:close-circle-bold" class="size-5 text-muted-foreground"></iconify-icon>
        </button>
      </div>
    `;

    this.container.appendChild(notification);

    if (duration > 0) {
      setTimeout(() => {
        this.removeNotification(id);
      }, duration);
    }

    return id;
  }

  removeNotification(id) {
    const notification = document.getElementById(id);
    if (notification) {
      notification.style.animation = 'slide-up 0.3s ease-out reverse';
      setTimeout(() => notification.remove(), 300);
    }
  }

  getTypeConfig(type) {
    const configs = {
      success: {
        icon: 'solar:check-circle-bold',
        iconColor: 'text-[#4caf50]',
        iconBg: 'bg-[#e8f5e9]',
        borderColor: 'border-[#4caf50]'
      },
      error: {
        icon: 'solar:danger-circle-bold',
        iconColor: 'text-[#d32f2f]',
        iconBg: 'bg-[#ffebee]',
        borderColor: 'border-[#d32f2f]'
      },
      warning: {
        icon: 'solar:danger-triangle-bold',
        iconColor: 'text-[#ff9800]',
        iconBg: 'bg-[#fff3e0]',
        borderColor: 'border-[#ff9800]'
      },
      info: {
        icon: 'solar:info-circle-bold',
        iconColor: 'text-[#2196f3]',
        iconBg: 'bg-[#e3f2fd]',
        borderColor: 'border-[#2196f3]'
      }
    };

    return configs[type] || configs.info;
  }

  clearAll() {
    if (this.container) {
      this.container.innerHTML = '';
    }
  }
}

export class LoadingOverlay {
  constructor() {
    this.overlay = document.getElementById('loading-overlay');
    this.messageEl = null;
  }

  show(message = 'جاري التحميل...') {
    if (!this.overlay) {
      this.createOverlay();
    }

    if (this.messageEl) {
      this.messageEl.textContent = message;
    }

    this.overlay.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }

  hide() {
    if (this.overlay) {
      this.overlay.classList.add('hidden');
      document.body.style.overflow = '';
    }
  }

  createOverlay() {
    this.overlay = document.createElement('div');
    this.overlay.id = 'loading-overlay';
    this.overlay.className = 'hidden fixed inset-0 bg-black/30 backdrop-blur-sm z-50 flex items-center justify-center';

    this.overlay.innerHTML = `
      <div class="bg-white rounded-2xl p-8 shadow-2xl flex flex-col items-center gap-4">
        <div class="w-12 h-12 border-4 border-[#a77939] border-t-transparent rounded-full animate-spin"></div>
        <p class="text-foreground font-medium loading-message">جاري التحميل...</p>
      </div>
    `;

    this.messageEl = this.overlay.querySelector('.loading-message');
    document.body.appendChild(this.overlay);
  }

  updateMessage(message) {
    if (this.messageEl) {
      this.messageEl.textContent = message;
    }
  }
}

export class SuccessModal {
  constructor() {
    this.modal = null;
  }

  show(config = {}) {
    const {
      title = 'تم بنجاح',
      message = 'تمت العملية بنجاح',
      icon = 'solar:check-circle-bold',
      iconColor = 'text-[#4caf50]',
      iconBg = 'bg-[#e8f5e9]',
      primaryButton = 'حسناً',
      onPrimaryClick = null,
      secondaryButton = null,
      onSecondaryClick = null,
      autoClose = false,
      autoCloseDuration = 3000
    } = config;

    this.createModal();

    this.modal.innerHTML = `
      <div class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[100] animate-slide-down" onclick="if(event.target === this) this.remove()">
        <div class="bg-white rounded-2xl p-6 sm:p-8 max-w-md w-full mx-4 space-y-6 shadow-2xl">
          <div class="flex flex-col items-center text-center gap-4">
            <div class="${iconBg} rounded-full p-4">
              <iconify-icon icon="${icon}" class="${iconColor} size-12"></iconify-icon>
            </div>
            <div class="space-y-2">
              <h3 class="text-xl sm:text-2xl font-bold text-foreground">${title}</h3>
              <p class="text-sm sm:text-base text-muted-foreground leading-relaxed">${message}</p>
            </div>
          </div>
          <div class="flex gap-3 ${secondaryButton ? '' : 'justify-center'}">
            ${secondaryButton ? `
              <button class="secondary-btn flex-1 py-3 border-2 border-[#E0E0E0] text-foreground rounded-xl font-medium hover:bg-[#F5F5F5] active:scale-95 transition">
                ${secondaryButton}
              </button>
            ` : ''}
            <button class="primary-btn ${secondaryButton ? 'flex-1' : 'px-12'} py-3 bg-[#4caf50] text-white rounded-xl font-medium hover:bg-[#45a049] active:scale-95 transition">
              ${primaryButton}
            </button>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(this.modal);
    document.body.style.overflow = 'hidden';

    const primaryBtn = this.modal.querySelector('.primary-btn');
    if (primaryBtn) {
      primaryBtn.addEventListener('click', () => {
        if (onPrimaryClick) onPrimaryClick();
        this.hide();
      });
    }

    const secondaryBtn = this.modal.querySelector('.secondary-btn');
    if (secondaryBtn) {
      secondaryBtn.addEventListener('click', () => {
        if (onSecondaryClick) onSecondaryClick();
        this.hide();
      });
    }

    if (autoClose) {
      setTimeout(() => this.hide(), autoCloseDuration);
    }
  }

  createModal() {
    if (this.modal) {
      this.modal.remove();
    }
    this.modal = document.createElement('div');
    this.modal.id = 'success-modal';
  }

  hide() {
    if (this.modal) {
      this.modal.style.opacity = '0';
      setTimeout(() => {
        this.modal.remove();
        document.body.style.overflow = '';
      }, 200);
    }
  }
}
