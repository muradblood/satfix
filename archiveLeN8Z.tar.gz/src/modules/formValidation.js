import { FormValidator, ValidationRules } from './validation.js';
import { FeedbackManager, LoadingOverlay, SuccessModal } from './feedback.js';

let validator;
let feedbackManager;
let loadingOverlay;
let successModal;

export function initValidation() {
  const form = document.querySelector('form');
  if (!form) return;

  validator = new FormValidator(form);
  feedbackManager = new FeedbackManager();
  loadingOverlay = new LoadingOverlay();
  successModal = new SuccessModal();

  setupSearchFormValidation();
  setupAuthFormValidation();
  setupFormSubmission();
}

function setupSearchFormValidation() {
  validator.addRule('depart-location', [
    ValidationRules.required('الرجاء اختيار محطة المغادرة'),
    ValidationRules.minLength(2, 'اسم المحطة قصير جداً'),
    ValidationRules.notSameAs('arrival-location', 'محطتا المغادرة والوصول لا يمكن أن تكونا متطابقتين')
  ]);

  validator.addRule('arrival-location', [
    ValidationRules.required('الرجاء اختيار محطة الوصول'),
    ValidationRules.minLength(2, 'اسم المحطة قصير جداً'),
    ValidationRules.notSameAs('depart-location', 'محطتا المغادرة والوصول لا يمكن أن تكونا متطابقتين')
  ]);

  validator.addRule('depart-date', [
    ValidationRules.required('الرجاء اختيار موعد المغادرة'),
    ValidationRules.dateNotPast('لا يمكن اختيار تاريخ في الماضي')
  ]);

  const returnDateField = document.getElementById('return-date');
  if (returnDateField) {
    const tripObserver = new MutationObserver(() => {
      const returnSection = document.getElementById('return-date-section');
      if (returnSection && !returnSection.classList.contains('hidden')) {
        validator.addRule('return-date', [
          ValidationRules.required('الرجاء اختيار موعد العودة'),
          ValidationRules.dateNotPast('لا يمكن اختيار تاريخ في الماضي'),
          ValidationRules.dateAfter('depart-date', 'تاريخ العودة يجب أن يكون بعد تاريخ المغادرة')
        ]);
      }
    });

    const returnSection = document.getElementById('return-date-section');
    if (returnSection) {
      tripObserver.observe(returnSection, { attributes: true, attributeFilter: ['class'] });
    }
  }

  const departLocation = document.getElementById('depart-location');
  const arrivalLocation = document.getElementById('arrival-location');

  if (departLocation && arrivalLocation) {
    departLocation.addEventListener('change', () => {
      if (arrivalLocation.value) {
        validator.validateField('arrival-location');
      }
    });

    arrivalLocation.addEventListener('change', () => {
      if (departLocation.value) {
        validator.validateField('depart-location');
      }
    });
  }

  const departDate = document.getElementById('depart-date');
  const returnDate = document.getElementById('return-date');

  if (departDate && returnDate) {
    departDate.addEventListener('change', () => {
      const returnSection = document.getElementById('return-date-section');
      if (returnSection && !returnSection.classList.contains('hidden') && returnDate.value) {
        validator.validateField('return-date');
      }
    });
  }
}

function setupAuthFormValidation() {
  const authModal = document.getElementById('auth-modal');
  if (!authModal) return;

  const authEmail = document.getElementById('auth-email');
  const authPassword = document.getElementById('auth-password');

  if (authEmail) {
    attachAuthFieldValidation(authEmail, [
      ValidationRules.required('الرجاء إدخال البريد الإلكتروني'),
      ValidationRules.email('البريد الإلكتروني غير صالح')
    ]);
  }

  if (authPassword) {
    attachAuthFieldValidation(authPassword, [
      ValidationRules.required('الرجاء إدخال كلمة المرور'),
      ValidationRules.minLength(6, 'كلمة المرور يجب أن تحتوي على 6 أحرف على الأقل')
    ]);
  }
}

function attachAuthFieldValidation(field, rules) {
  let touchedField = false;

  field.addEventListener('blur', () => {
    touchedField = true;
    validateAuthField(field, rules);
  });

  field.addEventListener('input', () => {
    if (touchedField) {
      validateAuthField(field, rules);
    }
  });
}

function validateAuthField(field, rules) {
  const value = field.value.trim();
  let isValid = true;
  let errorMessage = '';

  for (const rule of rules) {
    const result = rule.validate(value, field);
    if (!result.valid) {
      isValid = false;
      errorMessage = result.message;
      break;
    }
  }

  if (isValid) {
    clearAuthFieldError(field);
    if (value) {
      showAuthFieldSuccess(field);
    }
  } else {
    showAuthFieldError(field, errorMessage);
  }

  return isValid;
}

function showAuthFieldError(field, message) {
  field.classList.remove('border-[#E0E0E0]', 'border-[#4caf50]');
  field.classList.add('border-[#d32f2f]', 'focus:border-[#d32f2f]', 'focus:ring-[#d32f2f]/20');

  let errorEl = field.parentElement.querySelector('.auth-error-message');
  if (!errorEl) {
    errorEl = document.createElement('div');
    errorEl.className = 'auth-error-message flex items-start gap-2 mt-2 text-sm text-[#d32f2f]';
    errorEl.setAttribute('role', 'alert');
    field.parentElement.appendChild(errorEl);
  }

  errorEl.innerHTML = `
    <iconify-icon icon="solar:danger-circle-bold" class="size-4 mt-0.5 shrink-0"></iconify-icon>
    <span>${message}</span>
  `;
}

function clearAuthFieldError(field) {
  field.classList.remove('border-[#d32f2f]', 'focus:border-[#d32f2f]', 'focus:ring-[#d32f2f]/20');
  field.classList.add('border-[#E0E0E0]');

  const errorEl = field.parentElement.querySelector('.auth-error-message');
  if (errorEl) {
    errorEl.remove();
  }
}

function showAuthFieldSuccess(field) {
  field.classList.remove('border-[#E0E0E0]', 'border-[#d32f2f]');
  field.classList.add('border-[#4caf50]');
}

function setupFormSubmission() {
  const searchBtn = document.getElementById('search-btn');
  if (searchBtn) {
    searchBtn.addEventListener('click', async (e) => {
      e.preventDefault();

      if (!validator.validateAll()) {
        feedbackManager.showError('الرجاء تصحيح الأخطاء في النموذج');
        return;
      }

      const formData = {
        from: document.getElementById('depart-location').value,
        to: document.getElementById('arrival-location').value,
        departDate: document.getElementById('depart-date').value,
        returnDate: document.getElementById('return-date')?.value || null,
        passengers: document.getElementById('passenger-selector').value,
        busType: document.getElementById('bus-type-select').value
      };

      try {
        loadingOverlay.show('جاري البحث عن الرحلات المتاحة...');

        await new Promise(resolve => setTimeout(resolve, 1500));

        loadingOverlay.hide();

        const resultsCount = Math.floor(Math.random() * 10) + 5;

        successModal.show({
          title: 'تم البحث بنجاح',
          message: `تم العثور على ${resultsCount} رحلة متاحة من ${formData.from} إلى ${formData.to}`,
          icon: 'solar:map-point-search-bold',
          iconColor: 'text-[#a77939]',
          iconBg: 'bg-[#f5f5f0]',
          primaryButton: 'عرض النتائج',
          secondaryButton: 'بحث جديد',
          onSecondaryClick: () => {
            resetSearchForm();
          }
        });

      } catch (error) {
        loadingOverlay.hide();
        feedbackManager.showError('حدث خطأ أثناء البحث. الرجاء المحاولة مرة أخرى');
        console.error('Search error:', error);
      }
    });
  }

  const authLoginBtn = document.getElementById('auth-login');
  const authSignupBtn = document.getElementById('auth-signup');

  if (authLoginBtn) {
    authLoginBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      await handleAuthSubmit('login');
    });
  }

  if (authSignupBtn) {
    authSignupBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      await handleAuthSubmit('signup');
    });
  }
}

async function handleAuthSubmit(type) {
  const emailField = document.getElementById('auth-email');
  const passwordField = document.getElementById('auth-password');

  if (!emailField || !passwordField) return;

  const emailRules = [
    ValidationRules.required('الرجاء إدخال البريد الإلكتروني'),
    ValidationRules.email('البريد الإلكتروني غير صالح')
  ];

  const passwordRules = [
    ValidationRules.required('الرجاء إدخال كلمة المرور'),
    ValidationRules.minLength(6, 'كلمة المرور يجب أن تحتوي على 6 أحرف على الأقل')
  ];

  const emailValid = validateAuthField(emailField, emailRules);
  const passwordValid = validateAuthField(passwordField, passwordRules);

  if (!emailValid || !passwordValid) {
    feedbackManager.showError('الرجاء تصحيح الأخطاء في النموذج');
    return;
  }

  try {
    loadingOverlay.show(type === 'login' ? 'جاري تسجيل الدخول...' : 'جاري إنشاء الحساب...');

    await new Promise(resolve => setTimeout(resolve, 1500));

    loadingOverlay.hide();

    const authModal = document.getElementById('auth-modal');
    if (authModal) {
      authModal.classList.add('hidden');
    }

    successModal.show({
      title: type === 'login' ? 'تم تسجيل الدخول' : 'تم إنشاء الحساب',
      message: type === 'login'
        ? 'مرحباً بعودتك! تم تسجيل دخولك بنجاح'
        : 'تم إنشاء حسابك بنجاح. مرحباً بك!',
      autoClose: true,
      autoCloseDuration: 3000
    });

    emailField.value = '';
    passwordField.value = '';
    clearAuthFieldError(emailField);
    clearAuthFieldError(passwordField);

  } catch (error) {
    loadingOverlay.hide();
    feedbackManager.showError(
      type === 'login'
        ? 'فشل تسجيل الدخول. الرجاء التحقق من البيانات'
        : 'فشل إنشاء الحساب. الرجاء المحاولة مرة أخرى'
    );
    console.error('Auth error:', error);
  }
}

function resetSearchForm() {
  document.getElementById('depart-location').value = '';
  document.getElementById('arrival-location').value = '';
  document.getElementById('depart-date').value = new Date().toISOString().split('T')[0];

  const returnDate = document.getElementById('return-date');
  if (returnDate) returnDate.value = '';

  document.getElementById('passenger-selector').value = '1';
  document.getElementById('bus-type-select').value = '';

  validator.reset();

  feedbackManager.showInfo('تم مسح النموذج. يمكنك البدء ببحث جديد');
}

export function showValidationError(message) {
  if (feedbackManager) {
    feedbackManager.showError(message);
  }
}

export function showValidationSuccess(message) {
  if (feedbackManager) {
    feedbackManager.showSuccess(message);
  }
}

export function getValidator() {
  return validator;
}

export function getFeedbackManager() {
  return feedbackManager;
}
