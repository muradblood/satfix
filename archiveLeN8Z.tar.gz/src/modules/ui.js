import { apiClient } from '../main.js';

export async function initUI() {
  setupTabButtons();
  setupTripTypeButtons();
  setupSwapLocations();
  setupDatePicker();
  setupPassengerSelector();
  await setupStationAutocomplete();
}

async function setupStationAutocomplete() {
  const { data: stations, error } = await supabase
    .from('stations')
    .select('name, city')
    .order('name');

  if (error) {
    console.error('Error loading stations:', error);
    return;
  }

  const departInput = document.getElementById('depart-location');
  const arrivalInput = document.getElementById('arrival-location');

  if (departInput) {
    setupAutocomplete(departInput, stations);
  }

  if (arrivalInput) {
    setupAutocomplete(arrivalInput, stations);
  }
}

function setupAutocomplete(input, stations) {
  const container = input.parentElement;
  const listId = `${input.id}-list`;

  let datalist = document.getElementById(listId);
  if (!datalist) {
    datalist = document.createElement('div');
    datalist.id = listId;
    datalist.className = 'absolute z-50 w-full bg-white border border-[#E0E0E0] rounded-xl mt-1 shadow-lg max-h-60 overflow-auto hidden';
    container.appendChild(datalist);
  }

  input.addEventListener('input', () => {
    const value = input.value.trim();
    if (value.length < 2) {
      datalist.classList.add('hidden');
      return;
    }

    const filtered = stations.filter(s =>
      s.name.includes(value) || s.city.includes(value)
    );

    if (filtered.length === 0) {
      datalist.classList.add('hidden');
      return;
    }

    datalist.innerHTML = filtered.map(station => `
      <div class="px-4 py-3 hover:bg-[#F5F5F5] cursor-pointer transition" data-name="${station.name}">
        <div class="font-medium text-foreground">${station.name}</div>
        <div class="text-xs text-muted-foreground">${station.city}</div>
      </div>
    `).join('');

    datalist.classList.remove('hidden');

    datalist.querySelectorAll('[data-name]').forEach(item => {
      item.addEventListener('click', () => {
        input.value = item.dataset.name;
        datalist.classList.add('hidden');
      });
    });
  });

  input.addEventListener('blur', () => {
    setTimeout(() => datalist.classList.add('hidden'), 200);
  });

  input.addEventListener('focus', () => {
    if (input.value.length >= 2) {
      input.dispatchEvent(new Event('input'));
    }
  });
}

function setupTabButtons() {
  const domesticBtn = document.getElementById('tab-domestic');
  const internationalBtn = document.getElementById('tab-international');
  const ticketsBtn = document.getElementById('tab-tickets');

  if (domesticBtn) {
    domesticBtn.addEventListener('click', () => {
      window.appState.currentTab = 'domestic';
      updateTabUI();
    });
  }

  if (internationalBtn) {
    internationalBtn.addEventListener('click', () => {
      window.appState.currentTab = 'international';
      updateTabUI();
    });
  }

  if (ticketsBtn) {
    ticketsBtn.addEventListener('click', () => {
      window.appState.currentTab = 'tickets';
      updateTabUI();
    });
  }
}

function updateTabUI() {
  const tabs = ['tab-domestic', 'tab-international', 'tab-tickets'];
  tabs.forEach(tab => {
    const elem = document.getElementById(tab);
    if (!elem) return;

    if (tab === `tab-${window.appState.currentTab}`) {
      elem.classList.add('active');
    } else {
      elem.classList.remove('active');
    }
  });
}

function setupTripTypeButtons() {
  const onewayBtn = document.getElementById('trip-oneway');
  const roundtripBtn = document.getElementById('trip-roundtrip');

  if (onewayBtn) {
    onewayBtn.addEventListener('click', () => {
      window.appState.tripType = 'oneway';
      updateTripTypeUI();
    });
  }

  if (roundtripBtn) {
    roundtripBtn.addEventListener('click', () => {
      window.appState.tripType = 'roundtrip';
      updateTripTypeUI();
    });
  }
}

function updateTripTypeUI() {
  const onewayBtn = document.getElementById('trip-oneway');
  const roundtripBtn = document.getElementById('trip-roundtrip');
  const returnDateSection = document.getElementById('return-date-section');

  if (window.appState.tripType === 'oneway') {
    if (onewayBtn) {
      onewayBtn.classList.add('bg-[#a77939]', 'text-white');
      onewayBtn.classList.remove('bg-transparent', 'border-2', 'border-[#D0D0D0]', 'text-[#9E9E9E]');
    }
    if (roundtripBtn) {
      roundtripBtn.classList.remove('bg-[#a77939]', 'text-white');
      roundtripBtn.classList.add('bg-transparent', 'border-2', 'border-[#D0D0D0]', 'text-[#9E9E9E]');
    }
    if (returnDateSection) returnDateSection.classList.add('hidden');
  } else {
    if (onewayBtn) {
      onewayBtn.classList.remove('bg-[#a77939]', 'text-white');
      onewayBtn.classList.add('bg-transparent', 'border-2', 'border-[#D0D0D0]', 'text-[#9E9E9E]');
    }
    if (roundtripBtn) {
      roundtripBtn.classList.add('bg-[#a77939]', 'text-white');
      roundtripBtn.classList.remove('bg-transparent', 'border-2', 'border-[#D0D0D0]', 'text-[#9E9E9E]');
    }
    if (returnDateSection) returnDateSection.classList.remove('hidden');
  }
}

function setupSwapLocations() {
  const swapBtn = document.getElementById('swap-locations');
  if (!swapBtn) return;

  swapBtn.addEventListener('click', () => {
    const departInput = document.getElementById('depart-location');
    const arrivalInput = document.getElementById('arrival-location');

    if (departInput && arrivalInput) {
      [departInput.value, arrivalInput.value] = [arrivalInput.value, departInput.value];
    }
  });
}

function setupDatePicker() {
  const departDate = document.getElementById('depart-date');
  const returnDate = document.getElementById('return-date');

  const today = new Date().toISOString().split('T')[0];

  if (departDate) {
    departDate.min = today;
    departDate.value = today;

    departDate.addEventListener('change', () => {
      if (returnDate && departDate.value) {
        returnDate.min = departDate.value;
        if (returnDate.value && returnDate.value < departDate.value) {
          returnDate.value = departDate.value;
        }
      }
    });
  }

  if (returnDate) {
    returnDate.min = today;
  }
}

function setupPassengerSelector() {
  const passengerInput = document.getElementById('passenger-selector');
  const decreaseBtn = document.getElementById('passenger-decrease');
  const increaseBtn = document.getElementById('passenger-increase');

  if (!passengerInput || !decreaseBtn || !increaseBtn) return;

  decreaseBtn.addEventListener('click', () => {
    let current = parseInt(passengerInput.value) || 1;
    if (current > 1) {
      passengerInput.value = current - 1;
      passengerInput.dispatchEvent(new Event('change'));
    }
  });

  increaseBtn.addEventListener('click', () => {
    let current = parseInt(passengerInput.value) || 1;
    const max = parseInt(passengerInput.max) || 10;
    if (current < max) {
      passengerInput.value = current + 1;
      passengerInput.dispatchEvent(new Event('change'));
    }
  });

  passengerInput.addEventListener('input', () => {
    let value = parseInt(passengerInput.value);
    const min = parseInt(passengerInput.min) || 1;
    const max = parseInt(passengerInput.max) || 10;

    if (value < min) {
      passengerInput.value = min;
    } else if (value > max) {
      passengerInput.value = max;
    }
  });
}
