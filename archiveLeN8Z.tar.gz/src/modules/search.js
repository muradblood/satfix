import { apiClient } from '../main.js';

export function initSearch() {
  const searchBtn = document.getElementById('search-btn');
  if (searchBtn) {
    searchBtn.addEventListener('click', performSearch);
  }
}

async function performSearch() {
  const departLocation = document.getElementById('depart-location')?.value;
  const arrivalLocation = document.getElementById('arrival-location')?.value;
  const departDate = document.getElementById('depart-date')?.value;
  const busType = document.getElementById('bus-type-select')?.value;

  if (!departLocation || !arrivalLocation || !departDate) {
    showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
    return;
  }

  const loadingOverlay = document.getElementById('loading-overlay');
  const searchBtn = document.getElementById('search-btn');
  const resultsContainer = document.getElementById('search-results');

  try {
    loadingOverlay?.classList.remove('hidden');
    searchBtn.disabled = true;
    resultsContainer.innerHTML = '';

    window.appState.searchFilters = {
      departLocation,
      arrivalLocation,
      departDate,
      tripType: window.appState.tripType,
      returnDate: window.appState.tripType === 'roundtrip'
        ? document.getElementById('return-date')?.value
        : null
    };

    const { data: stations, error: stationError } = await supabase
      .from('stations')
      .select('id, name, code')
      .ilike('name', `%${departLocation}%`);

    if (stationError) throw stationError;

    if (!stations || stations.length === 0) {
      showToast('محطة المغادرة غير موجودة', 'error');
      return;
    }

    const departStationId = stations[0].id;

    const { data: arrivalStations, error: arrivalError } = await supabase
      .from('stations')
      .select('id, name, code')
      .ilike('name', `%${arrivalLocation}%`);

    if (arrivalError) throw arrivalError;

    if (!arrivalStations || arrivalStations.length === 0) {
      showToast('محطة الوصول غير موجودة', 'error');
      return;
    }

    const arrivalStationId = arrivalStations[0].id;

    const { data: routes, error: routeError } = await supabase
      .from('bus_routes')
      .select('id')
      .eq('departure_station_id', departStationId)
      .eq('arrival_station_id', arrivalStationId);

    if (routeError) throw routeError;

    if (!routes || routes.length === 0) {
      displaySearchResults([], departLocation, arrivalLocation);
      return;
    }

    const routeIds = routes.map(r => r.id);

    // Build the query with optional bus type filter
    let tripsQuery = supabase
      .from('trips')
      .select(`
        id, bus_id, route_id, departure_time, price_per_seat, available_seats,
        buses (id, name, bus_type, capacity),
        bus_routes (duration_minutes, distance_km)
      `)
      .in('route_id', routeIds)
      .gte('departure_time', new Date(departDate).toISOString())
      .lte('departure_time', new Date(new Date(departDate).getTime() + 86400000).toISOString())
      .gt('available_seats', 0); // Only show trips with available seats

    // Add bus type filter if specified
    if (busType) {
      tripsQuery = tripsQuery.eq('buses.bus_type', busType);
    }

    // Execute the query with ordering
    const { data: trips, error: tripError } = await tripsQuery
      .order('departure_time', { ascending: true });

    if (tripError) throw tripError;

    displaySearchResults(trips, departLocation, arrivalLocation);

    resultsContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });

  } catch (error) {
    console.error('Search error:', error);
    showToast('حدث خطأ في البحث، يرجى المحاولة مرة أخرى', 'error');
  } finally {
    loadingOverlay?.classList.add('hidden');
    searchBtn.disabled = false;
  }
}

function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `fixed top-20 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-xl shadow-lg text-white font-medium text-sm sm:text-base ${
    type === 'error' ? 'bg-red-500' : type === 'success' ? 'bg-green-500' : 'bg-[#a77939]'
  } animate-slide-down`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

function displaySearchResults(trips, departLocation, arrivalLocation) {
  const resultsContainer = document.getElementById('search-results');
  if (!resultsContainer) return;

  if (!trips || trips.length === 0) {
    resultsContainer.innerHTML = `
      <div class="flex flex-col items-center justify-center py-12 sm:py-16 px-4">
        <div class="bg-[#F5F5F5] rounded-full p-6 sm:p-8 mb-4">
          <iconify-icon icon="solar:bus-bold" class="size-12 sm:size-16 text-muted-foreground"></iconify-icon>
        </div>
        <h3 class="text-lg sm:text-xl font-bold text-foreground mb-2 text-center">لا توجد رحلات متاحة</h3>
        <p class="text-sm sm:text-base text-muted-foreground text-center">جرب البحث في تاريخ آخر أو محطات مختلفة</p>
      </div>
    `;
    return;
  }

  const resultHeader = `
    <div class="bg-[#a77939]/10 rounded-xl p-3 sm:p-4 mb-4">
      <div class="flex items-center justify-between">
        <div>
          <p class="text-xs sm:text-sm text-muted-foreground">وجدنا</p>
          <p class="text-lg sm:text-xl font-bold text-[#a77939]">${trips.length} رحلة متاحة</p>
        </div>
        <iconify-icon icon="solar:check-circle-bold" class="size-8 sm:size-10 text-[#a77939]"></iconify-icon>
      </div>
    </div>
  `;

  const tripCards = trips.map(trip => {
    const departureTime = new Date(trip.departure_time);
    const arrivalTime = new Date(departureTime.getTime() + (trip.bus_routes.duration_minutes * 60000));
    const deptHour = String(departureTime.getHours()).padStart(2, '0');
    const deptMin = String(departureTime.getMinutes()).padStart(2, '0');
    const arrHour = String(arrivalTime.getHours()).padStart(2, '0');
    const arrMin = String(arrivalTime.getMinutes()).padStart(2, '0');
    const hours = Math.floor(trip.bus_routes.duration_minutes / 60);
    const minutes = trip.bus_routes.duration_minutes % 60;
    const durationText = hours > 0 ? `${hours} س ${minutes} د` : `${minutes} د`;

    const busTypeText = trip.buses.bus_type === 'standard' ? 'عادية' : trip.buses.bus_type === 'vip' ? 'VIP' : 'فاخرة';
    const busTypeIcon = trip.buses.bus_type === 'standard' ? 'solar:bus-bold' : trip.buses.bus_type === 'vip' ? 'solar:star-bold' : 'solar:crown-bold';

    return `
      <div class="bg-white rounded-xl sm:rounded-2xl p-3 sm:p-4 shadow-sm border border-[#E0E0E0] hover:shadow-lg hover:border-[#a77939]/30 transition-all">
        <div class="flex justify-between items-start mb-3 sm:mb-4">
          <div class="flex-1">
            <h3 class="text-sm sm:text-base font-bold text-foreground mb-1">${trip.buses.name}</h3>
            <div class="flex items-center gap-1.5 sm:gap-2">
              <iconify-icon icon="${busTypeIcon}" class="size-3.5 sm:size-4 text-[#a77939]"></iconify-icon>
              <span class="text-xs sm:text-sm text-muted-foreground">${busTypeText}</span>
            </div>
          </div>
          <div class="text-left">
            <p class="text-lg sm:text-xl font-bold text-[#a77939]">${trip.price_per_seat} <span class="text-xs sm:text-sm">ر.س</span></p>
            <p class="text-[10px] sm:text-xs text-muted-foreground">${trip.available_seats} مقاعد متاحة</p>
          </div>
        </div>

        <div class="bg-[#F8F6F3] rounded-lg sm:rounded-xl p-3 sm:p-4 mb-3 sm:mb-4">
          <div class="flex justify-between items-center">
            <div class="text-center flex-1">
              <p class="text-xl sm:text-2xl font-bold text-foreground mb-1">${deptHour}:${deptMin}</p>
              <p class="text-[10px] sm:text-xs text-muted-foreground truncate px-1">${departLocation}</p>
            </div>
            <div class="flex flex-col items-center px-2 sm:px-4">
              <iconify-icon icon="solar:arrow-left-bold" class="size-5 sm:size-6 text-[#a77939] mb-1"></iconify-icon>
              <p class="text-[10px] sm:text-xs text-muted-foreground whitespace-nowrap">${durationText}</p>
            </div>
            <div class="text-center flex-1">
              <p class="text-xl sm:text-2xl font-bold text-foreground mb-1">${arrHour}:${arrMin}</p>
              <p class="text-[10px] sm:text-xs text-muted-foreground truncate px-1">${arrivalLocation}</p>
            </div>
          </div>
        </div>

        <div class="flex gap-2 sm:gap-3">
          <button class="flex-1 py-2.5 sm:py-3 bg-[#a77939] text-white rounded-lg sm:rounded-xl font-semibold text-xs sm:text-sm hover:bg-[#935c2e] active:scale-95 transition-all shadow-md" onclick="window.bookTrip('${trip.id}')">
            <span class="flex items-center justify-center gap-1.5">
              <iconify-icon icon="solar:ticket-bold" class="size-4 sm:size-5"></iconify-icon>
              حجز الآن
            </span>
          </button>
        </div>
      </div>
    `;
  }).join('');

  resultsContainer.innerHTML = resultHeader + tripCards;
}

export async function bookTrip(tripId) {
  if (!window.appState.user) {
    showToast('يرجى تسجيل الدخول أولاً للحجز', 'error');
    const signinBtn = document.getElementById('signin-btn');
    if (signinBtn) {
      setTimeout(() => signinBtn.click(), 500);
    }
    return;
  }

  showToast('جاري تجهيز نموذج الحجز...', 'info');

  setTimeout(() => {
    showToast('نموذج الحجز قيد التطوير - سيتم إضافته قريباً', 'info');
  }, 1000);
}

window.bookTrip = bookTrip;

export async function getBookingHistory() {
  if (!window.appState.user) return [];

  try {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        id, trip_id, passenger_name, passenger_phone, status, total_price, booking_date,
        trips (
          departure_time, price_per_seat,
          buses (name, bus_type),
          bus_routes (duration_minutes)
        )
      `)
      .eq('user_id', window.appState.user.id)
      .order('booking_date', { ascending: false });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching bookings:', error);
    return [];
  }
}
