import { createClient } from '@supabase/supabase-js';
import { initAuth } from './modules/auth.js';
import { initUI } from './modules/ui.js';
import { initSearch } from './modules/search.js';
import { initTables } from './modules/tables.js';
import { initValidation } from './modules/formValidation.js';
import { i18n } from './modules/i18n.js';
import { layoutManager } from './modules/layoutManager.js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
export const supabase = createClient(supabaseUrl, supabaseKey);

window.appState = {
  user: null,
  currentTab: 'domestic',
  tripType: 'oneway',
  searchFilters: {},
  locale: 'ar'
};

export { i18n, layoutManager };

async function init() {
  const savedLocale = localStorage.getItem('locale') || 'ar';
  await i18n.init(savedLocale);
  layoutManager.init();

  await initAuth();
  initUI();
  initSearch();
  initTables();
  initValidation();

  window.appState.locale = i18n.getLocale();
}

init().catch(console.error);
