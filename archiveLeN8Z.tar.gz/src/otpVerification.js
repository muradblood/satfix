// لا نستخدم apiClient هنا حالياً، فيمكن حذف السطر أو تركه لو ناوي تضيف استدعاء API لاحقاً
// import { apiClient } from './lib/api-client.js';

let otpLength = 6;
let currentOtp = '';
let correctOtp = '';
let timeLeft = 60;
let timerInterval = null;
let bookingData = null;

document.addEventListener('DOMContentLoaded', () => {
  loadBookingData();
  generateOtp();
  createOtpInputs();
  setupEventListeners();
  startTimer();
});

function loadBookingData() {
  const bookingId = sessionStorage.getItem('bookingId');
  const bookingReference = sessionStorage.getItem('bookingReference');
  const paymentData = JSON.parse(sessionStorage.getItem('paymentData') || '{}');

  // الأهم فعلياً هو bookingReference + بيانات الدفع
  if (!bookingReference) {
    alert('لم يتم العثور على بيانات الحجز. سيتم إعادة التوجيه للصفحة الرئيسية.');
    window.location.href = '/index.html';
    return;
  }

  bookingData = {
    bookingId,
    bookingReference,
    paymentData,
  };

  const phoneNumber = paymentData.managerPhone || '05XXXXXXXX';
  const maskedPhone =
    phoneNumber.substring(0, 3) + 'X '.repeat(3) + phoneNumber.substring(phoneNumber.length - 3);
  document.getElementById('phoneNumber').textContent = maskedPhone;
}

function generateOtp() {
  // توليد رمز داخلياً، من المفترض نفس الكود يرسل من السيرفر عبر SMS
  correctOtp = Math.floor(Math.random() * Math.pow(10, otpLength))
    .toString()
    .padStart(otpLength, '0');

  // لا نعرض الكود في الـ console ولا alert
  // console.log('OTP:', correctOtp); // ممنوع في الإنتاج
}


function createOtpInputs() {
  const container = document.getElementById('otpContainer');
  container.innerHTML = '';

  for (let i = 0; i < otpLength; i++) {
    const input = document.createElement('input');
    input.type = 'text';
    input.maxLength = 1;
    input.className = 'otp-input';
    input.inputMode = 'numeric';
    input.pattern = '[0-9]';
    input.id = `otp-${i}`;

    input.addEventListener('input', (e) => handleOtpInput(e, i));
    input.addEventListener('keydown', (e) => handleKeyDown(e, i));
    input.addEventListener('paste', handlePaste);

    container.appendChild(input);
  }

  document.getElementById('otp-0').focus();
}

function handleOtpInput(e, index) {
  const input = e.target;
  const value = input.value;

  if (!/^\d$/.test(value)) {
    input.value = '';
    return;
  }

  input.classList.add('filled');
  updateCurrentOtp();

  if (value && index < otpLength - 1) {
    document.getElementById(`otp-${index + 1}`).focus();
  }

  if (index === otpLength - 1 && getCurrentOtp().length === otpLength) {
    verifyOtp();
  }
}

function handleKeyDown(e, index) {
  if (e.key === 'Backspace') {
    const input = e.target;
    if (!input.value && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      prevInput.focus();
      prevInput.value = '';
      prevInput.classList.remove('filled');
      updateCurrentOtp();
    } else if (input.value) {
      input.value = '';
      input.classList.remove('filled');
      updateCurrentOtp();
    }
  } else if (e.key === 'ArrowLeft' && index > 0) {
    document.getElementById(`otp-${index - 1}`).focus();
  } else if (e.key === 'ArrowRight' && index < otpLength - 1) {
    document.getElementById(`otp-${index + 1}`).focus();
  }
}

function handlePaste(e) {
  e.preventDefault();
  const pastedData = e.clipboardData.getData('text').replace(/\D/g, '');

  if (pastedData.length >= otpLength) {
    for (let i = 0; i < otpLength; i++) {
      const input = document.getElementById(`otp-${i}`);
      input.value = pastedData[i];
      input.classList.add('filled');
    }
    updateCurrentOtp();
    document.getElementById(`otp-${otpLength - 1}`).focus();

    setTimeout(() => {
      verifyOtp();
    }, 100);
  }
}

function updateCurrentOtp() {
  currentOtp = getCurrentOtp();
}

function getCurrentOtp() {
  let otp = '';
  for (let i = 0; i < otpLength; i++) {
    const input = document.getElementById(`otp-${i}`);
    otp += input.value;
  }
  return otp;
}

function clearOtpInputs() {
  for (let i = 0; i < otpLength; i++) {
    const input = document.getElementById(`otp-${i}`);
    input.value = '';
    input.classList.remove('filled', 'error');
  }
  document.getElementById('otp-0').focus();
}

function showError(message) {
  const errorMsg = document.getElementById('errorMessage');
  errorMsg.textContent = message;
  errorMsg.style.opacity = '1';

  for (let i = 0; i < otpLength; i++) {
    const input = document.getElementById(`otp-${i}`);
    input.classList.add('error');
  }

  setTimeout(() => {
    errorMsg.style.opacity = '0';
    for (let i = 0; i < otpLength; i++) {
      const input = document.getElementById(`otp-${i}`);
      input.classList.remove('error');
    }
  }, 3000);
}

async function verifyOtp() {
  const enteredOtp = getCurrentOtp();

  if (enteredOtp.length !== otpLength) {
    showError('يرجى إدخال رمز التحقق كاملاً');
    return;
  }

  const verifyBtn = document.getElementById('verifyBtn');
  verifyBtn.disabled = true;
  verifyBtn.innerHTML = `
    <div class="animate-spin size-6 border-4 border-primary-foreground border-t-transparent rounded-full"></div>
    <span>جاري التحقق...</span>
  `;

  // محاكاة تأخير التحقق
  await new Promise((resolve) => setTimeout(resolve, 1000));

  if (enteredOtp === correctOtp) {
    await processPayment();
  } else {
    verifyBtn.disabled = false;
    verifyBtn.innerHTML = `
      <iconify-icon icon="solar:check-circle-bold" class="size-6"></iconify-icon>
      <span>تأكيد الدفع</span>
    `;
    showError('رمز التحقق غير صحيح، يرجى المحاولة مرة أخرى');
    clearOtpInputs();
  }
}

async function processPayment() {
  try {
    // هنا ممكن مستقبلاً استدعاء API في الباك إند لتأكيد الدفع وتحديث حالة الحجز

    stopTimer();
    showSuccessModal();

    setTimeout(() => {
      // تنظيف بيانات الجلسة
      sessionStorage.removeItem('bookingData');
      sessionStorage.removeItem('selectedSeats');
      sessionStorage.removeItem('selectedTrip');
      sessionStorage.removeItem('paymentData');

      const ref = bookingData.bookingReference || '';
      if (ref) {
        // تتبّع الحجز بالمرجع
        window.location.href = `/track-booking.html?ref=${encodeURIComponent(ref)}`;
      } else {
        window.location.href = '/index.html';
      }
    }, 3000);
  } catch (error) {
    console.error('Payment processing error:', error);
    alert('حدث خطأ أثناء معالجة الدفع. يرجى المحاولة مرة أخرى.');

    const verifyBtn = document.getElementById('verifyBtn');
    verifyBtn.disabled = false;
    verifyBtn.innerHTML = `
      <iconify-icon icon="solar:check-circle-bold" class="size-6"></iconify-icon>
      <span>تأكيد الدفع</span>
    `;
  }
}

function showSuccessModal() {
  const modal = document.getElementById('successModal');
  const modalContent = modal.querySelector('.bg-card');

  document.getElementById('bookingRef').textContent =
    bookingData.bookingReference || 'غير متوفر';

  modal.classList.remove('pointer-events-none', 'opacity-0');
  modal.style.opacity = '1';

  setTimeout(() => {
    modalContent.style.transform = 'scale(1)';
  }, 50);
}

function startTimer() {
  const timerElement = document.getElementById('timer');
  const resendBtn = document.getElementById('resendBtn');

  timerInterval = setInterval(() => {
    timeLeft--;
    timerElement.textContent = timeLeft;

    if (timeLeft <= 0) {
      stopTimer();
      resendBtn.disabled = false;
      timerElement.textContent = '0';
      showError('انتهى وقت رمز التحقق. يرجى طلب رمز جديد');
    }
  }, 1000);
}

function stopTimer() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

function resetTimer() {
  stopTimer();
  timeLeft = 60;
  document.getElementById('timer').textContent = timeLeft;

  const circle = document.querySelector('.timer-circle');
  if (circle) {
    circle.style.animation = 'none';
    setTimeout(() => {
      circle.style.animation = 'countdown 60s linear forwards';
    }, 10);
  }

  startTimer();
}

function setupEventListeners() {
  const backBtn = document.getElementById('backBtn');
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      if (confirm('هل تريد العودة وإلغاء عملية الدفع؟')) {
        stopTimer();
        window.history.back();
      }
    });
  }

  const verifyBtn = document.getElementById('verifyBtn');
  if (verifyBtn) {
    verifyBtn.addEventListener('click', () => {
      verifyOtp();
    });
  }

  const resendBtn = document.getElementById('resendBtn');
  if (resendBtn) {
    resendBtn.addEventListener('click', () => {
      resendBtn.disabled = true;
      clearOtpInputs();
      generateOtp();
      resetTimer();

      setTimeout(() => {
        alert('تم إرسال رمز تحقق جديد');
      }, 500);
    });
  }
}

window.addEventListener('beforeunload', () => {
  stopTimer();
});
