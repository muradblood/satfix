import { apiClient } from './lib/api-client.js';

let currentUser = null;
let stations = [];

document.addEventListener('DOMContentLoaded', async () => {
  await checkAuth();
  await loadStations();
  initializeEventListeners();
});

async function checkAuth() {
  const { data: { session } } = await supabase.auth.getSession();

  if (session) {
    currentUser = session.user;
    document.getElementById('loginPrompt').classList.add('hidden');
    document.getElementById('profileContent').classList.remove('hidden');
    await loadUserProfile();
  } else {
    document.getElementById('loginPrompt').classList.remove('hidden');
    document.getElementById('profileContent').classList.add('hidden');
  }
}

async function loadUserProfile() {
  try {
    const { data: profile } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('user_id', currentUser.id)
      .maybeSingle();

    if (profile) {
      displayUserInfo(profile);
    } else {
      displayUserInfo({ full_name: currentUser.email });
    }

    await loadUserStats();
    await loadFavorites();
    await loadBookings();

  } catch (error) {
    console.error('Error loading profile:', error);
  }
}

function displayUserInfo(profile) {
  const name = profile.full_name || currentUser.email;
  document.getElementById('userName').textContent = name;
  document.getElementById('userEmail').textContent = currentUser.email;

  const initials = name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  document.getElementById('avatarInitials').textContent = initials;
}

async function loadUserStats() {
  try {
    const { count: bookingsCount } = await supabase
      .from('bookings')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', currentUser.id);

    const { count: favoritesCount } = await supabase
      .from('favorite_routes')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', currentUser.id);

    const { count: reviewsCount } = await supabase
      .from('trip_reviews')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', currentUser.id);

    document.getElementById('totalBookings').textContent = bookingsCount || 0;
    document.getElementById('totalFavorites').textContent = favoritesCount || 0;
    document.getElementById('totalReviews').textContent = reviewsCount || 0;

  } catch (error) {
    console.error('Error loading stats:', error);
  }
}

async function loadFavorites() {
  try {
    const { data: favorites, error } = await supabase
      .from('favorite_routes')
      .select(`
        *,
        departure_station:stations!favorite_routes_departure_station_id_fkey (name, city),
        arrival_station:stations!favorite_routes_arrival_station_id_fkey (name, city)
      `)
      .eq('user_id', currentUser.id)
      .order('created_at', { ascending: false });

    if (error) throw error;

    const container = document.getElementById('favoritesList');

    if (!favorites || favorites.length === 0) {
      container.innerHTML = '<div class="text-center py-8 text-muted-foreground">لا توجد مسارات مفضلة بعد</div>';
      return;
    }

    container.innerHTML = favorites.map(fav => `
      <div class="flex items-center gap-3 p-4 bg-secondary/20 rounded-xl">
        <iconify-icon icon="solar:star-bold" class="size-5 text-primary"></iconify-icon>
        <div class="flex-1">
          <p class="font-semibold text-foreground">
            ${fav.departure_station.name} → ${fav.arrival_station.name}
          </p>
          ${fav.nickname ? `<p class="text-sm text-muted-foreground">${fav.nickname}</p>` : ''}
        </div>
        <button onclick="window.searchFavorite('${fav.departure_station_id}', '${fav.arrival_station_id}')" class="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 transition">
          بحث
        </button>
        <button onclick="window.deleteFavorite('${fav.id}')" class="size-8 flex items-center justify-center text-destructive hover:bg-destructive/10 rounded-lg transition">
          <iconify-icon icon="solar:trash-bin-2-bold" class="size-5"></iconify-icon>
        </button>
      </div>
    `).join('');

  } catch (error) {
    console.error('Error loading favorites:', error);
  }
}

async function loadBookings() {
  try {
    const { data: bookings, error } = await supabase
      .from('bookings')
      .select(`
        *,
        trip:trips (
          *,
          route:bus_routes (
            departure_station:stations!bus_routes_departure_station_id_fkey (name, city),
            arrival_station:stations!bus_routes_arrival_station_id_fkey (name, city)
          )
        )
      `)
      .eq('user_id', currentUser.id)
      .order('booking_date', { ascending: false })
      .limit(5);

    if (error) throw error;

    const container = document.getElementById('bookingsList');

    if (!bookings || bookings.length === 0) {
      container.innerHTML = '<div class="text-center py-8 text-muted-foreground">لا توجد حجوزات بعد</div>';
      return;
    }

    container.innerHTML = bookings.map(booking => {
      const statusColors = {
        'pending': 'bg-yellow-500',
        'confirmed': 'bg-accent',
        'cancelled': 'bg-destructive'
      };

      return `
        <a href="/track-booking.html?id=${booking.id}" class="block p-4 bg-card border-2 border-border rounded-xl hover:bg-secondary/20 transition">
          <div class="flex items-start justify-between mb-2">
            <div class="flex-1">
              <p class="font-semibold text-foreground">
                ${booking.trip.route.departure_station.name} → ${booking.trip.route.arrival_station.name}
              </p>
              <p class="text-sm text-muted-foreground mt-1">
                ${formatDate(booking.trip.departure_time)}
              </p>
            </div>
            <span class="size-3 ${statusColors[booking.status]} rounded-full"></span>
          </div>
          <div class="flex items-center gap-4 text-sm text-muted-foreground">
            <span>${booking.seats.length} مقعد</span>
            <span>•</span>
            <span>${booking.total_price} ريال</span>
          </div>
        </a>
      `;
    }).join('');

  } catch (error) {
    console.error('Error loading bookings:', error);
  }
}

async function loadStations() {
  try {
    const { data, error } = await supabase
      .from('stations')
      .select('*')
      .order('name');

    if (error) throw error;

    stations = data || [];

    const departureSelect = document.getElementById('favDeparture');
    const arrivalSelect = document.getElementById('favArrival');

    const options = stations.map(s => `<option value="${s.id}">${s.name} - ${s.city}</option>`).join('');

    departureSelect.innerHTML = '<option value="">اختر المحطة</option>' + options;
    arrivalSelect.innerHTML = '<option value="">اختر المحطة</option>' + options;

  } catch (error) {
    console.error('Error loading stations:', error);
  }
}

function initializeEventListeners() {
  document.getElementById('logoutBtn')?.addEventListener('click', handleLogout);
  document.getElementById('addFavoriteBtn')?.addEventListener('click', showAddFavoriteModal);
  document.getElementById('closeFavoriteModal')?.addEventListener('click', hideAddFavoriteModal);
  document.getElementById('addFavoriteForm')?.addEventListener('submit', handleAddFavorite);

  window.deleteFavorite = deleteFavorite;
  window.searchFavorite = searchFavorite;
}

async function handleLogout() {
  try {
    await supabase.auth.signOut();
    window.location.href = '/index.html';
  } catch (error) {
    console.error('Error logging out:', error);
  }
}

function showAddFavoriteModal() {
  document.getElementById('addFavoriteModal').classList.remove('hidden');
}

function hideAddFavoriteModal() {
  document.getElementById('addFavoriteModal').classList.add('hidden');
  document.getElementById('addFavoriteForm').reset();
}

async function handleAddFavorite(e) {
  e.preventDefault();

  const departureId = document.getElementById('favDeparture').value;
  const arrivalId = document.getElementById('favArrival').value;
  const nickname = document.getElementById('favNickname').value;

  if (!departureId || !arrivalId) {
    alert('الرجاء اختيار محطتي المغادرة والوصول');
    return;
  }

  if (departureId === arrivalId) {
    alert('لا يمكن أن تكون محطة المغادرة والوصول متطابقة');
    return;
  }

  try {
    const { error } = await supabase
      .from('favorite_routes')
      .insert({
        user_id: currentUser.id,
        departure_station_id: departureId,
        arrival_station_id: arrivalId,
        nickname: nickname || null
      });

    if (error) throw error;

    hideAddFavoriteModal();
    await loadFavorites();
    await loadUserStats();

  } catch (error) {
    console.error('Error adding favorite:', error);
    alert('حدث خطأ أثناء إضافة المفضلة');
  }
}

async function deleteFavorite(favoriteId) {
  const confirmed = confirm('هل تريد حذف هذا المسار من المفضلة؟');
  if (!confirmed) return;

  try {
    const { error } = await supabase
      .from('favorite_routes')
      .delete()
      .eq('id', favoriteId);

    if (error) throw error;

    await loadFavorites();
    await loadUserStats();

  } catch (error) {
    console.error('Error deleting favorite:', error);
    alert('حدث خطأ أثناء حذف المفضلة');
  }
}

function searchFavorite(departureId, arrivalId) {
  const departure = stations.find(s => s.id === departureId);
  const arrival = stations.find(s => s.id === arrivalId);

  if (departure && arrival) {
    window.location.href = `/trip-results.html?from=${departure.code}&to=${arrival.code}&date=${new Date().toISOString().split('T')[0]}&passengers=1`;
  }
}

function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('ar-SA', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}