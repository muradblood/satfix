import { apiClient } from '../lib/api-client.js';
import { checkAdminAuth as guardCheck, handleLogout } from './authGuard.js';

let currentUser = null;
let currentView = 'dashboard';

document.addEventListener('DOMContentLoaded', async () => {
  await checkAdminAuth();
  initializeNavigation();
  await loadDashboardData();
  setupLogoutButton();
});

async function checkAdminAuth() {
  const session = await guardCheck();

  if (!session) {
    return;
  }

  currentUser = session.user;

  const { data: adminRole } = await supabase
    .from('admin_roles')
    .select('*')
    .eq('user_id', currentUser.id)
    .eq('is_active', true)
    .maybeSingle();

  if (!adminRole) {
    alert('ليس لديك صلاحيات الوصول إلى لوحة التحكم');
    window.location.href = '/';
    return;
  }

  displayAdminInfo();
}

function displayAdminInfo() {
  const name = currentUser.email.split('@')[0];
  document.getElementById('adminName').textContent = name;
}

function initializeNavigation() {
  const navItems = document.querySelectorAll('.nav-item');

  navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const view = item.getAttribute('href').replace('#', '');
      switchView(view);

      navItems.forEach(nav => nav.classList.remove('active'));
      item.classList.add('active');
    });
  });

}

function setupLogoutButton() {
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      if (confirm('هل أنت متأكد من تسجيل الخروج؟')) {
        await handleLogout();
      }
    });
  }
}

function switchView(view) {
  const views = ['dashboard', 'trips', 'bookings', 'buses', 'stations', 'reviews'];

  views.forEach(v => {
    const element = document.getElementById(`${v}-view`);
    if (element) {
      element.classList.add('hidden');
    }
  });

  const targetView = document.getElementById(`${view}-view`);
  if (targetView) {
    targetView.classList.remove('hidden');
    currentView = view;
  }
}

async function loadDashboardData() {
  try {
    await Promise.all([
      loadStats(),
      loadRecentBookings(),
      loadUpcomingTrips(),
      loadRecentReviews()
    ]);
  } catch (error) {
    console.error('Error loading dashboard data:', error);
  }
}

async function loadStats() {
  try {
    const { count: bookingsCount } = await supabase
      .from('bookings')
      .select('*', { count: 'exact', head: true });

    const { data: bookings } = await supabase
      .from('bookings')
      .select('total_price');

    const totalRevenue = bookings?.reduce((sum, b) => sum + parseFloat(b.total_price || 0), 0) || 0;

    const { count: activeTripsCount } = await supabase
      .from('trips')
      .select('*', { count: 'exact', head: true })
      .gte('departure_time', new Date().toISOString());

    const { data: { users } } = await supabase.auth.admin.listUsers();
    const totalUsers = users?.length || 0;

    document.getElementById('totalBookings').textContent = bookingsCount || 0;
    document.getElementById('totalRevenue').textContent = totalRevenue.toFixed(0);
    document.getElementById('activeTrips').textContent = activeTripsCount || 0;
    document.getElementById('totalUsers').textContent = totalUsers;

  } catch (error) {
    console.error('Error loading stats:', error);
  }
}

async function loadRecentBookings() {
  try {
    const { data: bookings, error } = await supabase
      .from('bookings')
      .select(`
        *,
        trip:trips (
          *,
          route:bus_routes (
            departure_station:stations!bus_routes_departure_station_id_fkey (name),
            arrival_station:stations!bus_routes_arrival_station_id_fkey (name)
          )
        )
      `)
      .order('created_at', { ascending: false })
      .limit(5);

    if (error) throw error;

    const container = document.getElementById('recentBookings');

    if (!bookings || bookings.length === 0) {
      container.innerHTML = '<div class="text-center py-8 text-muted-foreground">لا توجد حجوزات</div>';
      return;
    }

    container.innerHTML = bookings.map(booking => {
      const statusColors = {
        'pending': 'bg-yellow-500',
        'confirmed': 'bg-accent',
        'cancelled': 'bg-destructive'
      };

      return `
        <div class="flex items-center gap-3 p-3 bg-secondary/20 rounded-lg">
          <span class="size-2 ${statusColors[booking.status]} rounded-full"></span>
          <div class="flex-1 min-w-0">
            <p class="font-medium text-foreground truncate">
              ${booking.trip.route.departure_station.name} → ${booking.trip.route.arrival_station.name}
            </p>
            <p class="text-sm text-muted-foreground">${booking.passenger_name}</p>
          </div>
          <span class="text-sm font-semibold text-primary">${booking.total_price} ريال</span>
        </div>
      `;
    }).join('');

  } catch (error) {
    console.error('Error loading recent bookings:', error);
  }
}

async function loadUpcomingTrips() {
  try {
    const { data: trips, error } = await supabase
      .from('trips')
      .select(`
        *,
        route:bus_routes (
          departure_station:stations!bus_routes_departure_station_id_fkey (name),
          arrival_station:stations!bus_routes_arrival_station_id_fkey (name)
        ),
        bus:buses (name, bus_type)
      `)
      .gte('departure_time', new Date().toISOString())
      .order('departure_time', { ascending: true })
      .limit(5);

    if (error) throw error;

    const container = document.getElementById('upcomingTrips');

    if (!trips || trips.length === 0) {
      container.innerHTML = '<div class="text-center py-8 text-muted-foreground">لا توجد رحلات قادمة</div>';
      return;
    }

    container.innerHTML = trips.map(trip => `
      <div class="flex items-center gap-3 p-3 bg-secondary/20 rounded-lg">
        <iconify-icon icon="solar:bus-bold" class="size-5 text-primary"></iconify-icon>
        <div class="flex-1 min-w-0">
          <p class="font-medium text-foreground truncate">
            ${trip.route.departure_station.name} → ${trip.route.arrival_station.name}
          </p>
          <p class="text-sm text-muted-foreground">${formatDateTime(trip.departure_time)}</p>
        </div>
        <span class="text-sm font-semibold text-accent">${trip.available_seats} مقعد</span>
      </div>
    `).join('');

  } catch (error) {
    console.error('Error loading upcoming trips:', error);
  }
}

async function loadRecentReviews() {
  try {
    const { data: reviews, error } = await supabase
      .from('trip_reviews')
      .select(`
        *,
        trip:trips (
          route:bus_routes (
            departure_station:stations!bus_routes_departure_station_id_fkey (name),
            arrival_station:stations!bus_routes_arrival_station_id_fkey (name)
          )
        )
      `)
      .order('created_at', { ascending: false })
      .limit(5);

    if (error) throw error;

    const container = document.getElementById('recentReviews');

    if (!reviews || reviews.length === 0) {
      container.innerHTML = '<div class="text-center py-8 text-muted-foreground">لا توجد تقييمات</div>';
      return;
    }

    container.innerHTML = reviews.map(review => `
      <div class="flex items-start gap-3 p-4 bg-secondary/20 rounded-lg">
        <div class="flex items-center gap-1">
          ${Array(review.rating).fill('<iconify-icon icon="solar:star-bold" class="size-4 text-yellow-500"></iconify-icon>').join('')}
          ${Array(5 - review.rating).fill('<iconify-icon icon="solar:star-bold" class="size-4 text-muted"></iconify-icon>').join('')}
        </div>
        <div class="flex-1 min-w-0">
          <p class="font-medium text-foreground truncate">
            ${review.trip.route.departure_station.name} → ${review.trip.route.arrival_station.name}
          </p>
          <p class="text-sm text-muted-foreground mt-1">${review.comment || 'بدون تعليق'}</p>
        </div>
      </div>
    `).join('');

  } catch (error) {
    console.error('Error loading recent reviews:', error);
  }
}


function formatDateTime(dateString) {
  const date = new Date(dateString);
  return date.toLocaleString('ar-SA', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}