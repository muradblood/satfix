import { apiClient } from '../lib/api-client.js';

export async function checkAdminAuth() {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();

    if (error) {
      console.error('Auth check error:', error);
      redirectToLogin();
      return null;
    }

    if (!session) {
      redirectToLogin();
      return null;
    }

    return session;

  } catch (error) {
    console.error('Auth guard error:', error);
    redirectToLogin();
    return null;
  }
}

export function redirectToLogin() {
  const currentPath = window.location.pathname;
  if (!currentPath.includes('/admin/login.html')) {
    window.location.href = '/admin/login.html';
  }
}

export async function handleLogout() {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    window.location.href = '/admin/login.html';
  } catch (error) {
    console.error('Logout error:', error);
    alert('حدث خطأ أثناء تسجيل الخروج');
  }
}

export function setupAuthListener(callback) {
  return supabase.auth.onAuthStateChange((event, session) => {
    if (event === 'SIGNED_OUT') {
      redirectToLogin();
    } else if (event === 'SIGNED_IN' && callback) {
      callback(session);
    }
  });
}
