export default {
  common: {
    search: 'بحث',
    cancel: 'إلغاء',
    save: 'حفظ',
    delete: 'حذف',
    edit: 'تعديل',
    close: 'إغلاق',
    back: 'رجوع',
    next: 'التالي',
    previous: 'السابق',
    submit: 'إرسال',
    confirm: 'تأكيد',
    loading: 'جاري التحميل...',
    error: 'خطأ',
    success: 'نجح',
    warning: 'تحذير',
    info: 'معلومات',
    yes: 'نعم',
    no: 'لا',
    ok: 'حسناً',
    required: 'مطلوب',
    optional: 'اختياري'
  },

  navigation: {
    home: 'الرئيسية',
    search: 'بحث',
    tickets: 'التذاكر',
    profile: 'الملف الشخصي',
    settings: 'الإعدادات',
    help: 'مساعدة',
    logout: 'تسجيل الخروج'
  },

  tabs: {
    domestic: 'داخلية',
    international: 'دولية',
    tickets: 'التذاكر'
  },

  tripType: {
    oneway: 'ذهاب فقط',
    roundtrip: 'ذهاب وعودة'
  },

  form: {
    departureStation: 'محطة المغادرة',
    arrivalStation: 'محطة الوصول',
    departureDate: 'موعد المغادرة',
    returnDate: 'موعد العودة',
    passengers: 'عدد المسافرين',
    busType: 'نوع الحافلة',
    searchPlaceholder: 'ابحث عن محطة...',
    selectBusType: 'اختر نوع الحافلة',
    increasePassengers: 'زيادة عدد المسافرين',
    decreasePassengers: 'تقليل عدد المسافرين',
    swapLocations: 'تبديل محطتي المغادرة والوصول',
    searchForTrips: 'بحث عن الرحلات'
  },

  busTypes: {
    standard: 'عادية',
    vip: 'VIP',
    luxury: 'فاخرة'
  },

  validation: {
    required: 'هذا الحقل مطلوب',
    invalidEmail: 'البريد الإلكتروني غير صالح',
    minLength: 'يجب أن يحتوي على {min} أحرف على الأقل',
    maxLength: 'يجب ألا يتجاوز {max} حرف',
    passwordTooShort: 'كلمة المرور يجب أن تحتوي على 6 أحرف على الأقل',
    departureRequired: 'الرجاء اختيار محطة المغادرة',
    arrivalRequired: 'الرجاء اختيار محطة الوصول',
    dateRequired: 'الرجاء اختيار التاريخ',
    dateInPast: 'لا يمكن اختيار تاريخ في الماضي',
    returnAfterDeparture: 'تاريخ العودة يجب أن يكون بعد تاريخ المغادرة',
    sameStations: 'محطتا المغادرة والوصول لا يمكن أن تكونا متطابقتين',
    stationTooShort: 'اسم المحطة قصير جداً',
    fixErrors: 'الرجاء تصحيح الأخطاء في النموذج'
  },

  auth: {
    signIn: 'دخول',
    signUp: 'إنشاء حساب',
    signOut: 'تسجيل الخروج',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    forgotPassword: 'نسيت كلمة المرور؟',
    noAccount: 'ليس لديك حساب؟',
    hasAccount: 'لديك حساب بالفعل؟',
    signInTitle: 'دخول أو إنشاء حساب',
    signInSuccess: 'تم تسجيل الدخول بنجاح',
    signUpSuccess: 'تم إنشاء الحساب بنجاح',
    signInError: 'فشل تسجيل الدخول. الرجاء التحقق من البيانات',
    signUpError: 'فشل إنشاء الحساب. الرجاء المحاولة مرة أخرى',
    welcomeBack: 'مرحباً بعودتك!',
    welcome: 'مرحباً بك!'
  },

  search: {
    searching: 'جاري البحث عن الرحلات المتاحة...',
    searchSuccess: 'تم البحث بنجاح',
    searchError: 'حدث خطأ أثناء البحث. الرجاء المحاولة مرة أخرى',
    resultsFound: 'تم العثور على {count} رحلة متاحة',
    noResults: 'لا توجد رحلات متاحة',
    viewResults: 'عرض النتائج',
    newSearch: 'بحث جديد',
    formCleared: 'تم مسح النموذج. يمكنك البدء ببحث جديد',
    from: 'من',
    to: 'إلى'
  },

  messages: {
    success: 'تمت العملية بنجاح',
    error: 'حدث خطأ',
    warning: 'تحذير',
    info: 'معلومات',
    dataUpdated: 'تم تحديث البيانات',
    dataSaved: 'تم حفظ البيانات',
    systemUpdated: 'تم تحديث النظام',
    checkData: 'يرجى مراجعة البيانات'
  },

  time: {
    now: 'الآن',
    today: 'اليوم',
    yesterday: 'أمس',
    tomorrow: 'غداً',
    thisWeek: 'هذا الأسبوع',
    lastWeek: 'الأسبوع الماضي',
    nextWeek: 'الأسبوع القادم',
    thisMonth: 'هذا الشهر',
    lastMonth: 'الشهر الماضي',
    nextMonth: 'الشهر القادم',
    days: 'أيام',
    hours: 'ساعات',
    minutes: 'دقائق',
    seconds: 'ثوان'
  },

  date: {
    format: {
      short: 'DD/MM/YYYY',
      long: 'dddd، D MMMM YYYY',
      time: 'HH:mm',
      datetime: 'DD/MM/YYYY HH:mm'
    }
  },

  numbers: {
    passenger: {
      zero: 'لا يوجد مسافرون',
      one: 'مسافر واحد',
      two: 'مسافران',
      few: '{count} مسافرين',
      many: '{count} مسافراً',
      other: '{count} مسافر'
    },
    trip: {
      zero: 'لا توجد رحلات',
      one: 'رحلة واحدة',
      two: 'رحلتان',
      few: '{count} رحلات',
      many: '{count} رحلة',
      other: '{count} رحلة'
    }
  },

  accessibility: {
    menu: 'القائمة',
    closeDialog: 'إغلاق النافذة',
    loading: 'جاري التحميل',
    searchResults: 'نتائج البحث',
    selectLanguage: 'اختر اللغة',
    skipToMain: 'الانتقال إلى المحتوى الرئيسي'
  },

  errors: {
    networkError: 'خطأ في الاتصال بالشبكة',
    serverError: 'خطأ في الخادم',
    notFound: 'غير موجود',
    unauthorized: 'غير مصرح',
    forbidden: 'محظور',
    tryAgain: 'الرجاء المحاولة مرة أخرى',
    contactSupport: 'الرجاء التواصل مع الدعم الفني'
  }
};
