export default {
  common: {
    search: 'Search',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    close: 'Close',
    back: 'Back',
    next: 'Next',
    previous: 'Previous',
    submit: 'Submit',
    confirm: 'Confirm',
    loading: 'Loading...',
    error: 'Error',
    success: 'Success',
    warning: 'Warning',
    info: 'Information',
    yes: 'Yes',
    no: 'No',
    ok: 'OK',
    required: 'Required',
    optional: 'Optional'
  },

  navigation: {
    home: 'Home',
    search: 'Search',
    tickets: 'Tickets',
    profile: 'Profile',
    settings: 'Settings',
    help: 'Help',
    logout: 'Logout'
  },

  tabs: {
    domestic: 'Domestic',
    international: 'International',
    tickets: 'Tickets'
  },

  tripType: {
    oneway: 'One Way',
    roundtrip: 'Round Trip'
  },

  form: {
    departureStation: 'Departure Station',
    arrivalStation: 'Arrival Station',
    departureDate: 'Departure Date',
    returnDate: 'Return Date',
    passengers: 'Number of Passengers',
    busType: 'Bus Type',
    searchPlaceholder: 'Search for a station...',
    selectBusType: 'Select bus type',
    increasePassengers: 'Increase passenger count',
    decreasePassengers: 'Decrease passenger count',
    swapLocations: 'Swap departure and arrival stations',
    searchForTrips: 'Search for Trips'
  },

  busTypes: {
    standard: 'Standard',
    vip: 'VIP',
    luxury: 'Luxury'
  },

  validation: {
    required: 'This field is required',
    invalidEmail: 'Invalid email address',
    minLength: 'Must contain at least {min} characters',
    maxLength: 'Must not exceed {max} characters',
    passwordTooShort: 'Password must be at least 6 characters',
    departureRequired: 'Please select departure station',
    arrivalRequired: 'Please select arrival station',
    dateRequired: 'Please select date',
    dateInPast: 'Cannot select a date in the past',
    returnAfterDeparture: 'Return date must be after departure date',
    sameStations: 'Departure and arrival stations cannot be the same',
    stationTooShort: 'Station name is too short',
    fixErrors: 'Please fix the errors in the form'
  },

  auth: {
    signIn: 'Sign In',
    signUp: 'Sign Up',
    signOut: 'Sign Out',
    email: 'Email',
    password: 'Password',
    forgotPassword: 'Forgot Password?',
    noAccount: "Don't have an account?",
    hasAccount: 'Already have an account?',
    signInTitle: 'Sign In or Create Account',
    signInSuccess: 'Successfully signed in',
    signUpSuccess: 'Account created successfully',
    signInError: 'Sign in failed. Please check your credentials',
    signUpError: 'Sign up failed. Please try again',
    welcomeBack: 'Welcome back!',
    welcome: 'Welcome!'
  },

  search: {
    searching: 'Searching for available trips...',
    searchSuccess: 'Search completed successfully',
    searchError: 'An error occurred during search. Please try again',
    resultsFound: 'Found {count} available trips',
    noResults: 'No trips available',
    viewResults: 'View Results',
    newSearch: 'New Search',
    formCleared: 'Form cleared. You can start a new search',
    from: 'From',
    to: 'To'
  },

  messages: {
    success: 'Operation completed successfully',
    error: 'An error occurred',
    warning: 'Warning',
    info: 'Information',
    dataUpdated: 'Data updated',
    dataSaved: 'Data saved',
    systemUpdated: 'System updated',
    checkData: 'Please review the data'
  },

  time: {
    now: 'Now',
    today: 'Today',
    yesterday: 'Yesterday',
    tomorrow: 'Tomorrow',
    thisWeek: 'This week',
    lastWeek: 'Last week',
    nextWeek: 'Next week',
    thisMonth: 'This month',
    lastMonth: 'Last month',
    nextMonth: 'Next month',
    days: 'days',
    hours: 'hours',
    minutes: 'minutes',
    seconds: 'seconds'
  },

  date: {
    format: {
      short: 'MM/DD/YYYY',
      long: 'dddd, MMMM D, YYYY',
      time: 'HH:mm',
      datetime: 'MM/DD/YYYY HH:mm'
    }
  },

  numbers: {
    passenger: {
      one: '1 passenger',
      other: '{count} passengers'
    },
    trip: {
      one: '1 trip',
      other: '{count} trips'
    }
  },

  accessibility: {
    menu: 'Menu',
    closeDialog: 'Close dialog',
    loading: 'Loading',
    searchResults: 'Search results',
    selectLanguage: 'Select language',
    skipToMain: 'Skip to main content'
  },

  errors: {
    networkError: 'Network connection error',
    serverError: 'Server error',
    notFound: 'Not found',
    unauthorized: 'Unauthorized',
    forbidden: 'Forbidden',
    tryAgain: 'Please try again',
    contactSupport: 'Please contact support'
  }
};
