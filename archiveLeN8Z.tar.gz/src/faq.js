const faqs = [
  {
    icon: 'solar:calendar-mark-bold',
    question: 'كيف يمكنني حجز تذكرة؟',
    answer: 'يمكنك حجز تذكرتك بسهولة من خلال تطبيقنا أو الموقع الإلكتروني. اختر محطة المغادرة والوصول، حدد التاريخ وعدد المسافرين، ثم اضغط على زر البحث. ستظهر لك جميع الرحلات المتاحة ويمكنك اختيار الأنسب لك وإتمام عملية الدفع.'
  },
  {
    icon: 'solar:card-bold',
    question: 'ما هي وسائل الدفع المتاحة؟',
    answer: 'نوفر عدة وسائل دفع آمنة: البطاقات الائتمانية (Visa، MasterCard)، بطاقة مدى، Apple Pay. جميع المعاملات مشفرة ومؤمنة بأعلى معايير الأمان.'
  },
  {
    icon: 'solar:close-circle-bold',
    question: 'كيف يمكنني إلغاء الحجز؟',
    answer: 'يمكنك إلغاء حجزك من خلال صفحة "رحلاتي" في التطبيق. تختلف سياسة الاسترجاع حسب وقت الإلغاء: قبل 48 ساعة (استرداد كامل)، قبل 24-48 ساعة (75%)، قبل 12-24 ساعة (50%)، أقل من 12 ساعة (لا يمكن الاسترجاع).'
  },
  {
    icon: 'solar:suitcase-bold',
    question: 'ما هي سياسة الأمتعة؟',
    answer: 'يُسمح بحقيبة واحدة لا تتجاوز 20 كجم في المخزن السفلي، وحقيبة يد صغيرة داخل الحافلة. الأمتعة الزائدة قد تخضع لرسوم إضافية.'
  },
  {
    icon: 'solar:map-point-bold',
    question: 'أين تقع المحطات؟',
    answer: 'لدينا محطات في جميع المدن الرئيسية بالمملكة. يمكنك الاطلاع على مواقع المحطات التفصيلية من خلال قسم "الخطوط والوجهات" في التطبيق، أو عبر خرائط Google.'
  },
  {
    icon: 'solar:wallet-bold',
    question: 'ما هي سياسة الاسترجاع؟',
    answer: 'يتم معالجة طلبات الاسترجاع خلال 7-10 أيام عمل ويتم إرجاع المبلغ لنفس وسيلة الدفع المستخدمة. نسبة الاسترجاع تعتمد على وقت الإلغاء قبل موعد الرحلة.'
  },
  {
    icon: 'solar:ticket-bold',
    question: 'هل يمكنني تعديل موعد الرحلة؟',
    answer: 'نعم، يمكنك تعديل موعد رحلتك مرة واحدة مجاناً قبل 24 ساعة من موعد المغادرة. التعديلات اللاحقة أو التعديل في وقت لاحق قد يخضع لرسوم إضافية حسب التوفر.'
  },
  {
    icon: 'solar:clock-circle-bold',
    question: 'متى يجب أن أصل للمحطة؟',
    answer: 'يُنصح بالحضور إلى المحطة قبل موعد المغادرة بـ 30 دقيقة على الأقل لإتمام إجراءات الصعود والتأكد من مقعدك.'
  },
  {
    icon: 'solar:user-id-bold',
    question: 'هل أحتاج إلى هوية لركوب الحافلة؟',
    answer: 'نعم، يجب إبراز بطاقة الهوية الوطنية أو جواز السفر (للأجانب) عند الصعود إلى الحافلة. هذا إجراء أمني إلزامي لجميع الركاب.'
  },
  {
    icon: 'solar:smartphone-2-bold',
    question: 'هل يتوفر WiFi في الحافلة؟',
    answer: 'نعم، جميع حافلاتنا الحديثة مجهزة بخدمة WiFi مجانية، مقابس شحن USB، ومقاعد مريحة قابلة للإمالة لضمان رحلة مريحة.'
  }
];

document.addEventListener('DOMContentLoaded', () => {
  const backBtn = document.getElementById('backBtn');
  const container = document.getElementById('faqContainer');

  backBtn.addEventListener('click', () => {
    window.history.back();
  });

  renderFaqs();

  function renderFaqs() {
    container.innerHTML = faqs.map((faq, index) => `
      <div class="bg-card rounded-xl overflow-hidden" data-index="${index}">
        <button class="faq-question w-full flex items-center justify-between p-4 text-right">
          <div class="flex items-center gap-3 flex-1">
            <iconify-icon
              icon="${faq.icon}"
              class="size-6 ${index === 0 ? 'text-primary' : 'text-muted-foreground'}"
            ></iconify-icon>
            <h3 class="font-semibold text-base">${faq.question}</h3>
          </div>
          <iconify-icon
            icon="${index === 0 ? 'solar:alt-arrow-down-bold' : 'solar:alt-arrow-left-bold'}"
            class="size-5 ${index === 0 ? 'text-primary' : 'text-muted-foreground'} faq-arrow"
          ></iconify-icon>
        </button>
        <div class="faq-answer ${index === 0 ? 'open' : ''}">
          <div class="px-4 pb-4">
            <p class="text-sm text-muted-foreground leading-relaxed">
              ${faq.answer}
            </p>
          </div>
        </div>
      </div>
    `).join('');

    const questions = container.querySelectorAll('.faq-question');
    questions.forEach(question => {
      question.addEventListener('click', toggleFaq);
    });
  }

  function toggleFaq(e) {
    const button = e.currentTarget;
    const faqItem = button.closest('[data-index]');
    const answer = faqItem.querySelector('.faq-answer');
    const icon = faqItem.querySelector('.faq-question iconify-icon:first-child');
    const arrow = faqItem.querySelector('.faq-arrow');
    const isOpen = answer.classList.contains('open');

    if (isOpen) {
      answer.classList.remove('open');
      icon.classList.remove('text-primary');
      icon.classList.add('text-muted-foreground');
      arrow.classList.remove('text-primary');
      arrow.classList.add('text-muted-foreground');
      arrow.setAttribute('icon', 'solar:alt-arrow-left-bold');
    } else {
      answer.classList.add('open');
      icon.classList.remove('text-muted-foreground');
      icon.classList.add('text-primary');
      arrow.classList.remove('text-muted-foreground');
      arrow.classList.add('text-primary');
      arrow.setAttribute('icon', 'solar:alt-arrow-down-bold');
    }
  }
});