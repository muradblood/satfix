import { apiClient } from '../lib/api-client.js';

export async function sendTelegramNotification(eventType, data) {
  try {
    const { data: settings, error: settingsError } = await supabase
      .from('telegram_settings')
      .select('*')
      .maybeSingle();

    if (settingsError) {
      console.error('Error fetching telegram settings:', settingsError);
      return { success: false, error: settingsError.message };
    }

    if (!settings || !settings.is_active || !settings.bot_token || !settings.chat_id) {
      console.log('Telegram notifications not configured or disabled');
      return { success: false, error: 'Telegram not configured' };
    }

    const events = settings.notification_events || {};
    if (!events[eventType]) {
      console.log(`Event type ${eventType} is disabled`);
      return { success: false, error: 'Event type disabled' };
    }

    const message = formatMessage(eventType, data);

    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-telegram`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        bot_token: settings.bot_token,
        chat_id: settings.chat_id,
        message: message
      })
    });

    const result = await response.json();
    return result;

  } catch (error) {
    console.error('Error sending telegram notification:', error);
    return { success: false, error: error.message };
  }
}

function formatMessage(eventType, data) {
  const timestamp = new Date().toLocaleString('ar-SA', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  switch (eventType) {
    case 'new_booking':
      return `
🎫 *حجز جديد*

👤 *اسم الراكب:* ${data.passengerName || 'غير محدد'}
📱 *رقم الجوال:* ${data.phone || 'غير محدد'}
🎫 *رقم الحجز:* ${data.bookingId || 'غير محدد'}

🚌 *تفاصيل الرحلة:*
📍 من: ${data.fromStation || 'غير محدد'}
📍 إلى: ${data.toStation || 'غير محدد'}
📅 التاريخ: ${data.departureDate || 'غير محدد'}
🕐 الوقت: ${data.departureTime || 'غير محدد'}

💺 *المقاعد:* ${data.seats ? data.seats.join(', ') : 'غير محدد'}
👥 *عدد المسافرين:* ${data.passengers || '1'}
💰 *المبلغ الإجمالي:* ${data.totalAmount || '0'} ر.س

⏰ ${timestamp}
      `.trim();

    case 'booking_cancelled':
      return `
❌ *تم إلغاء حجز*

🎫 *رقم الحجز:* ${data.bookingId || 'غير محدد'}
👤 *اسم الراكب:* ${data.passengerName || 'غير محدد'}
📱 *رقم الجوال:* ${data.phone || 'غير محدد'}

🚌 *تفاصيل الرحلة:*
📍 من: ${data.fromStation || 'غير محدد'}
📍 إلى: ${data.toStation || 'غير محدد'}
📅 التاريخ: ${data.departureDate || 'غير محدد'}

💰 *المبلغ المسترد:* ${data.refundAmount || '0'} ر.س

⏰ ${timestamp}
      `.trim();

    case 'payment_completed':
      return `
✅ *تم الدفع بنجاح*

🎫 *رقم الحجز:* ${data.bookingId || 'غير محدد'}
👤 *اسم الراكب:* ${data.passengerName || 'غير محدد'}
📱 *رقم الجوال:* ${data.phone || 'غير محدد'}

💳 *طريقة الدفع:* ${data.paymentMethod || 'غير محدد'}
💰 *المبلغ المدفوع:* ${data.amount || '0'} ر.س
🔖 *رقم العملية:* ${data.transactionId || 'غير محدد'}

⏰ ${timestamp}
      `.trim();

    default:
      return `
📢 *إشعار جديد*

${JSON.stringify(data, null, 2)}

⏰ ${timestamp}
      `.trim();
  }
}

export async function testTelegramConnection(botToken, chatId) {
  try {
    const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-telegram`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        bot_token: botToken,
        chat_id: chatId,
        message: '🎉 اختبار الاتصال\n\nالبوت يعمل بشكل صحيح!',
        test: true
      })
    });

    return await response.json();
  } catch (error) {
    console.error('Test connection error:', error);
    return { success: false, error: error.message };
  }
}
