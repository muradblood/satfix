import { apiClient } from '../lib/api-client.js';

/**
 * البحث عن الرحلات عبر API PHP
 * يستقبل:
 *  - fromStationId
 *  - toStationId
 *  - departureDate (YYYY-MM-DD)
 *  - passengers (number)
 *  - directOnly (boolean)
 */
export async function searchTrips(searchParams) {
  const {
    fromStationId,
    toStationId,
    departureDate,
    passengers,
    directOnly,
  } = searchParams;

  try {
    const params = {
      from: fromStationId,
      to: toStationId,
      date: departureDate,
      passengers: passengers,
    };

    if (directOnly) {
      params.direct = 'true';
    }

    // apiClient.searchTrips يستخدم:
    // GET /api/api.php?endpoint=trips&from=..&to=..&date=..&passengers=..&direct=true
    const result = await apiClient.searchTrips(params);

    // النتيجة مفروض تكون:
    // { success: true/false, data: [...], error?: string }
    return result;
  } catch (error) {
    console.error('Error searching trips:', error);
    return {
      success: false,
      error: error.message || 'حدث خطأ أثناء البحث عن الرحلات',
    };
  }
}
