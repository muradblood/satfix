import { apiClient } from '../lib/api-client.js';
import { sendTelegramNotification } from './telegramService.js';

/**
 * إنشاء حجز جديد عبر API PHP
 * bookingDetails يأتي من passengerDetails.js:
 *  - tripId
 *  - managerDetails { name, phone, email, nationalId }
 *  - passengers [{ name, nationalId, gender, age, seatNumber }]
 *  - selectedSeats [{ seatNumber }]
 *  - totalPrice
 */
export async function createBooking(bookingDetails) {
  const { tripId, managerDetails, passengers, selectedSeats, totalPrice } = bookingDetails;

  try {
    // تجهيز البيانات بالشكل الذي يتوقعه PHP
    const bookingPayload = {
      trip_id: tripId,
      manager_name: managerDetails.name,
      manager_email: managerDetails.email,
      manager_phone: managerDetails.phone,
      manager_national_id: managerDetails.nationalId,
      total_passengers: passengers.length,
      seats: selectedSeats.map((s) => s.seatNumber.toString()),
      passengers: passengers.map((p) => ({
        full_name: p.name,
        national_id: p.nationalId,
        date_of_birth: null, // ما عندنا تاريخ ميلاد في الفورم حالياً
        gender: p.gender || null,
        phone: managerDetails.phone || null,
        seat_number: p.seatNumber ? p.seatNumber.toString() : null,
        passenger_type: 'adult',
      })),
    };

    // استدعاء API PHP
    const response = await apiClient.createBooking(bookingPayload);

    if (!response || !response.success) {
      throw new Error(response?.error || 'فشل إنشاء الحجز');
    }

    const bookingId = response.data.booking_id;
    const bookingReference = response.data.booking_reference;
    const finalTotalPrice = response.data.total_price ?? totalPrice;

    // محاولة إرسال إشعار تيليجرام (لو فشل ما نكسر الحجز)
    try {
      await sendTelegramNotification('new_booking', {
        bookingId,
        bookingReference,
        passengerName: managerDetails.name,
        phone: managerDetails.phone,
        // لو حاب تضيف من/إلى/تاريخ، احفظها في bookingData قبل وتابعها هنا
        seats: selectedSeats.map((s) => s.seatNumber),
        passengers: passengers.length,
        totalAmount: finalTotalPrice,
      });
    } catch (telegramError) {
      console.error('Telegram notification error:', telegramError);
      // نتجاهل خطأ تيليجرام، الحجز تم أصلاً
    }

    // نحافظ على نفس شكل النتيجة المتوقعة في passengerDetails.js
    return {
      success: true,
      data: {
        bookingId,
        bookingReference,
      },
    };
  } catch (error) {
    console.error('Booking creation error:', error);
    return {
      success: false,
      error: error.message || 'حدث خطأ أثناء إنشاء الحجز',
    };
  }
}

/**
 * جلب الحجز (بالمرجع) عبر API PHP
 * ملاحظة: الـ PHP API يعتمد على booking_reference وليس ID رقمي
 */
export async function getBookingById(bookingReference) {
  try {
    const response = await apiClient.getBooking(bookingReference);

    if (!response || !response.success) {
      throw new Error(response?.error || 'الحجز غير موجود');
    }

    return {
      success: true,
      data: response.data,
    };
  } catch (error) {
    console.error('Error fetching booking:', error);
    return {
      success: false,
      error: error.message || 'حدث خطأ أثناء جلب بيانات الحجز',
    };
  }
}
