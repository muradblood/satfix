// لا نستخدم apiClient هنا حالياً، فتم حذفه
// import { apiClient } from './lib/api-client.js';

let bookingData = null;
let totalAmount = 0;
let selectedPaymentMethodIndex = 0;

document.addEventListener('DOMContentLoaded', () => {
  loadBookingData();
  setupPaymentHandling();
});

function loadBookingData() {
  const bookingId = sessionStorage.getItem('bookingId'); // قد نحتاجه لاحقاً، لكن ليس شرطاً أساسياً هنا
  const bookingReference = sessionStorage.getItem('bookingReference');
  const tripData = JSON.parse(sessionStorage.getItem('selectedTrip') || '{}');
  const selectedSeats = JSON.parse(sessionStorage.getItem('selectedSeats') || '[]');
  const bookingInfo = JSON.parse(sessionStorage.getItem('bookingData') || '{}');

  // تحقق منطقي: لازم يكون عندنا حجز + مقاعد + بيانات رحلة
  if (!bookingReference || !bookingInfo.fromStation || selectedSeats.length === 0) {
    alert('لا توجد بيانات حجز كافية. سيتم إعادة التوجيه للصفحة الرئيسية.');
    window.location.href = '/index.html';
    return;
  }

  bookingData = {
    bookingId,
    bookingReference,
    tripData,
    selectedSeats,
    bookingInfo,
  };

  // أولاً نحاول استخدام totalPrice من bookingData إن كان مخزّن
  if (typeof bookingInfo.totalPrice === 'number' && bookingInfo.totalPrice > 0) {
    totalAmount = bookingInfo.totalPrice;
  } else {
    // وإلا نحسبه من سعر الرحلة × عدد المقاعد
    totalAmount = (tripData.price || 0) * selectedSeats.length;
  }

  displayBookingSummary();
}

function displayBookingSummary() {
  // استخدام أسماء المحطات والتاريخ من bookingData
  const fromName = bookingData.bookingInfo.fromStation || 'غير محددة';
  const toName = bookingData.bookingInfo.toStation || 'غير محددة';
  let formattedDate = 'غير محدد';

  if (bookingData.bookingInfo.departureDate) {
    const d = new Date(bookingData.bookingInfo.departureDate);
    if (!isNaN(d.getTime())) {
      formattedDate = d.toLocaleDateString('ar-SA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    } else {
      formattedDate = bookingData.bookingInfo.departureDate;
    }
  }

  const passengersCount = bookingData.selectedSeats.length;

  // هذه التحديدات تعتمد على هيكل الـ HTML عندك في صفحة الدفع
  // لو فيه IDs يكون أفضل، لكن بنمشي على الموجود
  const labels = document.querySelectorAll('.space-y-2 .text-sm.font-medium');

  if (labels[0]) labels[0].textContent = fromName;
  if (labels[1]) labels[1].textContent = toName;
  if (labels[2]) labels[2].textContent = formattedDate;
  if (labels[3]) labels[3].textContent = `${passengersCount} مسافر`;

  const totalEl = document.querySelector('.text-xl.font-bold.text-primary');
  if (totalEl) {
    totalEl.textContent = `${totalAmount} ريال`;
  }
}

function setupPaymentHandling() {
  const backBtn = document.querySelector('button[class*="size-11"]:first-child');
  if (backBtn) {
    backBtn.addEventListener('click', () => {
      window.history.back();
    });
  }

  const paymentButtons = document.querySelectorAll('.space-y-2 > button');
  paymentButtons.forEach((button, index) => {
    button.addEventListener('click', () => selectPaymentMethod(index));
  });

  const submitButton = document.querySelector('.fixed button');
  if (submitButton) {
    submitButton.addEventListener('click', handlePayment);
  }

  const cardNumberInput = document.querySelector('input[placeholder="0000 0000 0000 0000"]');
  if (cardNumberInput) {
    cardNumberInput.addEventListener('input', formatCardNumber);
  }

  const expiryInput = document.querySelector('input[placeholder="MM/YY"]');
  if (expiryInput) {
    expiryInput.addEventListener('input', formatExpiry);
  }

  const cvvInput = document.querySelector('input[placeholder="000"]');
  if (cvvInput) {
    cvvInput.addEventListener('input', (e) => {
      e.target.value = e.target.value.replace(/\D/g, '').slice(0, 3);
    });
  }
}

function selectPaymentMethod(index) {
  selectedPaymentMethodIndex = index;
  const buttons = document.querySelectorAll('.space-y-2 > button');

  buttons.forEach((btn, i) => {
    const radio = btn.querySelector('.size-5.rounded-full');
    if (!radio) return;

    if (i === index) {
      btn.classList.remove('bg-input', 'border-border');
      btn.classList.add('bg-secondary', 'border-2', 'border-primary');

      radio.classList.remove('border-border');
      radio.classList.add('border-primary', 'bg-primary');
      radio.innerHTML = '<div class="size-2 rounded-full bg-primary-foreground"></div>';
    } else {
      btn.classList.remove('bg-secondary', 'border-2', 'border-primary');
      btn.classList.add('bg-input', 'border', 'border-border');

      radio.classList.remove('border-primary', 'bg-primary');
      radio.classList.add('border-border');
      radio.innerHTML = '';
    }
  });
}

function getSelectedPaymentMethod() {
  const methods = ['credit_card', 'debit_card', 'apple_pay'];
  return methods[selectedPaymentMethodIndex] || 'credit_card';
}

function formatCardNumber(e) {
  let value = e.target.value.replace(/\s/g, '').replace(/\D/g, '');
  let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
  e.target.value = formattedValue.slice(0, 19);
}

function formatExpiry(e) {
  let value = e.target.value.replace(/\D/g, '');
  if (value.length >= 2) {
    value = value.slice(0, 2) + '/' + value.slice(2, 4);
  }
  e.target.value = value.slice(0, 5);
}

async function handlePayment() {
  const termsCheckbox = document.getElementById('terms');

  if (!termsCheckbox || !termsCheckbox.checked) {
    alert('يرجى الموافقة على الشروط والأحكام');
    return;
  }

  if (!validatePaymentForm()) {
    alert('يرجى إدخال جميع معلومات الدفع بشكل صحيح');
    return;
  }

  const submitButton = document.querySelector('.fixed button');
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.innerHTML = `
      <div class="animate-spin size-6 border-4 border-primary-foreground border-t-transparent rounded-full"></div>
      <span>جاري المعالجة...</span>
    `;
  }

  // محاكاة عملية الدفع (مكانك تشبك مع بوابة حقيقية لاحقاً)
  await new Promise((resolve) => setTimeout(resolve, 1000));

  const selectedPaymentMethod = getSelectedPaymentMethod();
  const managerPhone = bookingData.bookingInfo?.managerPhone || '05XXXXXXXX';

  const paymentData = {
    paymentMethod: selectedPaymentMethod,
    managerPhone: managerPhone,
    bookingReference: bookingData.bookingReference,
    amount: totalAmount,
  };
  sessionStorage.setItem('paymentData', JSON.stringify(paymentData));

  window.location.href = '/otp-verification.html';
}

function validatePaymentForm() {
  const cardNumberInput = document.querySelector('input[placeholder="0000 0000 0000 0000"]');
  const expiryInput = document.querySelector('input[placeholder="MM/YY"]');
  const cvvInput = document.querySelector('input[placeholder="000"]');
  const cardHolderInput = document.querySelector('input[placeholder="كما هو مكتوب على البطاقة"]');

  if (!cardNumberInput || !expiryInput || !cvvInput || !cardHolderInput) {
    return false;
  }

  const cardNumber = cardNumberInput.value;
  const expiry = expiryInput.value;
  const cvv = cvvInput.value;
  const cardHolder = cardHolderInput.value;

  if (!cardNumber || cardNumber.replace(/\s/g, '').length < 16) {
    return false;
  }

  if (!expiry || expiry.length !== 5) {
    return false;
  }

  const [month, year] = expiry.split('/');
  if (parseInt(month) < 1 || parseInt(month) > 12) {
    return false;
  }

  if (!cvv || cvv.length < 3) {
    return false;
  }

  if (!cardHolder || cardHolder.trim().length < 3) {
    return false;
  }

  return true;
}
