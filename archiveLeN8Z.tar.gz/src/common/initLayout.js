import { createHeader, initHeaderEvents } from '../components/header.js';
import { createFooter } from '../components/footer.js';

export function initLayout(options = {}) {
  const {
    title = '',
    showBackButton = false,
    backUrl = 'index.html',
    showMenu = true,
    transparent = false
  } = options;

  const headerContainer = document.getElementById('headerContainer');
  const footerContainer = document.getElementById('footerContainer');

  if (headerContainer) {
    headerContainer.innerHTML = createHeader({
      title,
      showBackButton,
      backUrl,
      showMenu,
      transparent
    });

    initHeaderEvents();
  }

  if (footerContainer) {
    footerContainer.innerHTML = createFooter();
  }
}
