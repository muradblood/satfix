export function setupNavigation() {
  const navButtons = document.querySelectorAll('[data-nav]');

  navButtons.forEach(button => {
    button.addEventListener('click', () => {
      const target = button.getAttribute('data-nav');

      switch(target) {
        case 'home':
          window.location.href = '/index.html';
          break;
        case 'trips':
          window.location.href = '/track-booking.html';
          break;
        case 'about':
          window.location.href = '/about-saptco.html';
          break;
        case 'routes':
          window.location.href = '/routes.html';
          break;
        case 'faq':
          window.location.href = '/faq.html';
          break;
        case 'privacy':
          window.location.href = '/privacy-policy.html';
          break;
        case 'terms':
          window.location.href = '/terms.html';
          break;
        default:
          break;
      }
    });
  });
}

export function setActiveNav(currentPage) {
  const navButtons = document.querySelectorAll('[data-nav]');

  navButtons.forEach(button => {
    const target = button.getAttribute('data-nav');
    const icon = button.querySelector('iconify-icon');
    const text = button.querySelector('span');

    if (target === currentPage) {
      icon?.classList.remove('text-muted-foreground');
      icon?.classList.add('text-primary');
      text?.classList.remove('text-muted-foreground');
      text?.classList.add('text-primary', 'font-medium');
    } else {
      icon?.classList.remove('text-primary');
      icon?.classList.add('text-muted-foreground');
      text?.classList.remove('text-primary', 'font-medium');
      text?.classList.add('text-muted-foreground');
    }
  });
}