import { apiClient } from '../lib/api-client.js';

export class StationSearchSelect {
  constructor(inputElement, options = {}) {
    this.input = inputElement;
    this.options = {
      placeholder: options.placeholder || 'ابحث عن المحطة...',
      onChange: options.onChange || (() => {}),
      ...options,
    };

    this.stations = [];
    this.filteredStations = [];
    this.isOpen = false;
    this.selectedIndex = -1;
    this.selectedStation = null;

    this.init();
  }

  async init() {
    await this.loadStations();
    this.createUI();
    this.attachEvents();
  }

  async loadStations() {
    try {
      // استدعاء API PHP بدل supabase
      const response = await apiClient.getStations();

      if (!response || !response.success) {
        console.error('API error loading stations:', response && response.error);
        this.stations = [];
        this.filteredStations = [];
        this.showError('فشل تحميل المحطات');
        return;
      }

      const data = response.data || [];

      // تحويل شكل البيانات القادمة من API
      // API يرجع: id, name_ar, name_en, city, ...
      this.stations = data.map((row) => ({
        id: row.id,
        name: row.name_ar || row.name_en || row.city || '',
        code: row.city || '',
        city: row.city || '',
      }));

      this.filteredStations = this.stations;
    } catch (error) {
      console.error('Error loading stations:', error);
      this.stations = [];
      this.filteredStations = [];
      this.showError('خطأ في الاتصال بالخادم');
    }
  }

  showError(message) {
    if (this.dropdown) {
      this.dropdown.innerHTML = `
        <div class="p-4 text-center text-destructive">
          <iconify-icon icon="solar:danger-circle-bold" class="size-8 mx-auto mb-2"></iconify-icon>
          <p class="text-sm">${message}</p>
        </div>
      `;
    }
  }

  createUI() {
    const wrapper = document.createElement('div');
    wrapper.className = 'relative station-search-wrapper';

    this.input.parentNode.insertBefore(wrapper, this.input);
    wrapper.appendChild(this.input);

    this.input.setAttribute('autocomplete', 'off');
    this.input.setAttribute('placeholder', this.options.placeholder);
    this.input.className =
      'w-full pr-12 pl-4 py-3.5 rounded-xl bg-input text-foreground border-2 border-transparent transition focus:border-primary focus:outline-none';

    this.dropdown = document.createElement('div');
    this.dropdown.className =
      'absolute top-full left-0 right-0 mt-2 bg-card border-2 border-border rounded-xl shadow-xl max-h-64 overflow-y-auto z-50 hidden';
    wrapper.appendChild(this.dropdown);

    this.wrapper = wrapper;
  }

  attachEvents() {
    this.input.addEventListener('input', (e) => this.handleInput(e));
    this.input.addEventListener('focus', () => this.open());
    this.input.addEventListener('keydown', (e) => this.handleKeydown(e));

    document.addEventListener('click', (e) => {
      if (!this.wrapper.contains(e.target)) {
        this.close();
      }
    });
  }

  handleInput(e) {
    const query = e.target.value.trim().toLowerCase();

    if (query === '') {
      this.filteredStations = this.stations;
    } else {
      this.filteredStations = this.stations.filter((station) =>
        station.name.toLowerCase().includes(query) ||
        station.city.toLowerCase().includes(query) ||
        station.code.toLowerCase().includes(query)
      );
    }

    this.selectedIndex = -1;
    this.render();
    this.open();
  }

  handleKeydown(e) {
    if (!this.isOpen) {
      if (e.key === 'ArrowDown' || e.key === 'Enter') {
        this.open();
        e.preventDefault();
      }
      return;
    }

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        this.selectedIndex = Math.min(
          this.selectedIndex + 1,
          this.filteredStations.length - 1
        );
        this.render();
        this.scrollToSelected();
        break;

      case 'ArrowUp':
        e.preventDefault();
        this.selectedIndex = Math.max(this.selectedIndex - 1, -1);
        this.render();
        this.scrollToSelected();
        break;

      case 'Enter':
        e.preventDefault();
        if (this.selectedIndex >= 0 && this.filteredStations[this.selectedIndex]) {
          this.selectStation(this.filteredStations[this.selectedIndex]);
        }
        break;

      case 'Escape':
        this.close();
        break;
    }
  }

  scrollToSelected() {
    if (this.selectedIndex >= 0) {
      const selectedElement = this.dropdown.querySelector(
        `[data-index="${this.selectedIndex}"]`
      );
      if (selectedElement) {
        selectedElement.scrollIntoView({ block: 'nearest' });
      }
    }
  }

  selectStation(station) {
    this.selectedStation = station;
    this.input.value = station.name;
    this.input.dataset.stationId = station.id;
    this.input.dataset.stationCode = station.code;
    this.close();
    this.options.onChange(station);
  }

  open() {
    this.isOpen = true;
    this.dropdown.classList.remove('hidden');
    this.render();
  }

  close() {
    this.isOpen = false;
    this.dropdown.classList.add('hidden');
  }

  render() {
    if (this.filteredStations.length === 0) {
      this.dropdown.innerHTML = `
        <div class="p-4 text-center text-muted-foreground">
          <iconify-icon icon="solar:magnifer-linear" class="size-8 mx-auto mb-2 opacity-50"></iconify-icon>
          <p class="text-sm">لا توجد محطات مطابقة</p>
        </div>
      `;
      return;
    }

    this.dropdown.innerHTML = this.filteredStations
      .map(
        (station, index) => `
      <div
        class="station-option px-4 py-3 cursor-pointer transition-colors border-b border-border last:border-b-0 ${
          index === this.selectedIndex ? 'bg-primary/10' : 'hover:bg-secondary/50'
        }"
        data-index="${index}"
        data-station-id="${station.id}"
      >
        <div class="flex items-center gap-3">
          <div class="flex-shrink-0 flex items-center justify-center size-10 bg-primary/20 rounded-lg">
            <iconify-icon icon="solar:map-point-bold" class="size-5 text-primary"></iconify-icon>
          </div>
          <div class="flex-1 min-w-0">
            <p class="text-sm font-semibold text-foreground truncate">${station.name}</p>
            <p class="text-xs text-muted-foreground">${station.city}</p>
          </div>
          <div class="flex-shrink-0">
            <span class="px-2 py-1 bg-secondary text-secondary-foreground text-xs font-medium rounded">${station.code}</span>
          </div>
        </div>
      </div>
    `
      )
      .join('');

    this.dropdown.querySelectorAll('.station-option').forEach((option, index) => {
      option.addEventListener('click', () => {
        this.selectStation(this.filteredStations[index]);
      });
    });
  }

  getValue() {
    return this.selectedStation ? this.selectedStation.name : this.input.value;
  }

  setValue(stationName) {
    const station = this.stations.find((s) => s.name === stationName);
    if (station) {
      this.selectStation(station);
    }
  }

  clear() {
    this.input.value = '';
    this.selectedStation = null;
    delete this.input.dataset.stationId;
    delete this.input.dataset.stationCode;
    this.filteredStations = this.stations;
  }
}
