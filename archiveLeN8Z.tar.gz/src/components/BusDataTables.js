import { AccessibleTable } from './AccessibleTable.js';
import { apiClient } from '../main.js';

/**
 * Bus Booking Data Tables
 * Implements accessible tables for different bus booking data views
 */

export class BusDataTables {
  constructor() {
    this.tables = new Map();
  }

  // Stations Table
  async createStationsTable(container) {
    const columns = [
      {
        key: 'name',
        label: 'Station Name',
        sortable: true
      },
      {
        key: 'city',
        label: 'City',
        sortable: true
      },
      {
        key: 'code',
        label: 'Station Code',
        sortable: true
      },
      {
        key: 'created_at',
        label: 'Date Added',
        sortable: true,
        formatter: (value) => {
          if (!value) return '—';
          return new Date(value).toLocaleDateString('ar-SA', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
          });
        },
        sortFn: (a, b) => new Date(a) - new Date(b)
      }
    ];

    const table = new AccessibleTable(container, {
      caption: 'Bus Stations Directory - Complete list of available bus stations',
      sortable: true,
      filterable: true,
      paginated: true,
      pageSize: 10
    });

    try {
      const { data: stations, error } = await supabase
        .from('stations')
        .select('*')
        .order('name');

      if (error) throw error;

      table.setData(stations, columns);
      this.tables.set('stations', table);
      
      return table;
    } catch (error) {
      console.error('Error loading stations:', error);
      this.showErrorMessage(container, 'Failed to load stations data');
    }
  }

  // Trips Table
  async createTripsTable(container, filters = {}) {
    const columns = [
      {
        key: 'departure_station',
        label: 'From',
        sortable: true,
        formatter: (value, row) => {
          return `<strong>${row.departure_station}</strong><br>
                  <small class="text-muted-foreground">${row.departure_city}</small>`;
        }
      },
      {
        key: 'arrival_station',
        label: 'To',
        sortable: true,
        formatter: (value, row) => {
          return `<strong>${row.arrival_station}</strong><br>
                  <small class="text-muted-foreground">${row.arrival_city}</small>`;
        }
      },
      {
        key: 'departure_time',
        label: 'Departure',
        sortable: true,
        formatter: (value) => {
          if (!value) return '—';
          const date = new Date(value);
          return `<div class="departure-info">
                    <div class="departure-time">${date.toLocaleTimeString('ar-SA', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}</div>
                    <div class="departure-date">${date.toLocaleDateString('ar-SA', {
                      month: 'short',
                      day: 'numeric'
                    })}</div>
                  </div>`;
        },
        sortFn: (a, b) => new Date(a) - new Date(b)
      },
      {
        key: 'duration_minutes',
        label: 'Duration',
        sortable: true,
        formatter: (value) => {
          if (!value) return '—';
          const hours = Math.floor(value / 60);
          const minutes = value % 60;
          return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
        }
      },
      {
        key: 'bus_name',
        label: 'Bus',
        sortable: true,
        formatter: (value, row) => {
          const typeIcons = {
            standard: 'solar:bus-bold',
            vip: 'solar:star-bold',
            luxury: 'solar:crown-bold'
          };
          const typeLabels = {
            standard: 'Standard',
            vip: 'VIP',
            luxury: 'Luxury'
          };
          
          return `<div class="bus-info">
                    <div class="bus-name">${value}</div>
                    <div class="bus-type">
                      <iconify-icon icon="${typeIcons[row.bus_type] || typeIcons.standard}"></iconify-icon>
                      ${typeLabels[row.bus_type] || 'Standard'}
                    </div>
                  </div>`;
        }
      },
      {
        key: 'price_per_seat',
        label: 'Price',
        sortable: true,
        formatter: (value) => {
          if (!value) return '—';
          return `<span class="price">${value} <small>SAR</small></span>`;
        }
      },
      {
        key: 'available_seats',
        label: 'Available Seats',
        sortable: true,
        formatter: (value, row) => {
          const percentage = (value / row.bus_capacity) * 100;
          const statusClass = percentage > 50 ? 'high' : percentage > 20 ? 'medium' : 'low';
          
          return `<div class="seat-availability ${statusClass}">
                    <span class="seat-count">${value}</span>
                    <div class="seat-bar">
                      <div class="seat-fill" style="width: ${percentage}%"></div>
                    </div>
                  </div>`;
        }
      },
      {
        key: 'actions',
        label: 'Actions',
        sortable: false,
        formatter: (value, row) => {
          return `<div class="table-actions">
                    <button 
                      class="action-btn book-btn" 
                      onclick="window.bookTrip('${row.trip_id}')"
                      aria-label="Book trip from ${row.departure_station} to ${row.arrival_station}"
                    >
                      <iconify-icon icon="solar:ticket-bold"></iconify-icon>
                      Book
                    </button>
                  </div>`;
        }
      }
    ];

    const table = new AccessibleTable(container, {
      caption: 'Available Bus Trips - Search results showing departure times, prices, and availability',
      sortable: true,
      filterable: true,
      paginated: true,
      pageSize: 5
    });

    try {
      const { data: trips, error } = await supabase
        .from('trips')
        .select(`
          id,
          departure_time,
          price_per_seat,
          available_seats,
          buses (
            id,
            name,
            bus_type,
            capacity
          ),
          bus_routes (
            duration_minutes,
            distance_km,
            departure_station:stations!bus_routes_departure_station_id_fkey (
              name,
              city
            ),
            arrival_station:stations!bus_routes_arrival_station_id_fkey (
              name,
              city
            )
          )
        `)
        .gte('departure_time', new Date().toISOString())
        .gt('available_seats', 0)
        .order('departure_time');

      if (error) throw error;

      // Transform data for table display
      const transformedData = trips.map(trip => ({
        trip_id: trip.id,
        departure_station: trip.bus_routes.departure_station.name,
        departure_city: trip.bus_routes.departure_station.city,
        arrival_station: trip.bus_routes.arrival_station.name,
        arrival_city: trip.bus_routes.arrival_station.city,
        departure_time: trip.departure_time,
        duration_minutes: trip.bus_routes.duration_minutes,
        bus_name: trip.buses.name,
        bus_type: trip.buses.bus_type,
        bus_capacity: trip.buses.capacity,
        price_per_seat: trip.price_per_seat,
        available_seats: trip.available_seats
      }));

      table.setData(transformedData, columns);
      this.tables.set('trips', table);
      
      return table;
    } catch (error) {
      console.error('Error loading trips:', error);
      this.showErrorMessage(container, 'Failed to load trips data');
    }
  }

  // Bookings Table (for user's booking history)
  async createBookingsTable(container, userId) {
    const columns = [
      {
        key: 'booking_id',
        label: 'Booking ID',
        sortable: true,
        formatter: (value) => `<code class="booking-id">${value.slice(0, 8)}</code>`
      },
      {
        key: 'route',
        label: 'Route',
        sortable: false,
        formatter: (value, row) => {
          return `<div class="route-info">
                    <div class="route-from">${row.departure_station}</div>
                    <iconify-icon icon="solar:arrow-right-bold" class="route-arrow"></iconify-icon>
                    <div class="route-to">${row.arrival_station}</div>
                  </div>`;
        }
      },
      {
        key: 'departure_time',
        label: 'Travel Date',
        sortable: true,
        formatter: (value) => {
          if (!value) return '—';
          const date = new Date(value);
          return `<div class="travel-date">
                    <div class="travel-time">${date.toLocaleTimeString('ar-SA', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}</div>
                    <div class="travel-day">${date.toLocaleDateString('ar-SA', {
                      weekday: 'short',
                      month: 'short',
                      day: 'numeric'
                    })}</div>
                  </div>`;
        },
        sortFn: (a, b) => new Date(a) - new Date(b)
      },
      {
        key: 'passenger_name',
        label: 'Passenger',
        sortable: true
      },
      {
        key: 'seats',
        label: 'Seats',
        sortable: false,
        formatter: (value) => {
          if (!Array.isArray(value)) return '—';
          return `<div class="seat-numbers">
                    ${value.map(seat => `<span class="seat-badge">${seat}</span>`).join('')}
                  </div>`;
        }
      },
      {
        key: 'total_price',
        label: 'Total Price',
        sortable: true,
        formatter: (value) => {
          if (!value) return '—';
          return `<span class="total-price">${value} <small>SAR</small></span>`;
        }
      },
      {
        key: 'status',
        label: 'Status',
        sortable: true,
        formatter: (value) => {
          const statusConfig = {
            pending: { icon: 'solar:clock-circle-bold', class: 'status-pending', label: 'Pending' },
            confirmed: { icon: 'solar:check-circle-bold', class: 'status-confirmed', label: 'Confirmed' },
            cancelled: { icon: 'solar:close-circle-bold', class: 'status-cancelled', label: 'Cancelled' }
          };
          
          const config = statusConfig[value] || statusConfig.pending;
          
          return `<div class="booking-status ${config.class}">
                    <iconify-icon icon="${config.icon}"></iconify-icon>
                    <span>${config.label}</span>
                  </div>`;
        }
      },
      {
        key: 'actions',
        label: 'Actions',
        sortable: false,
        formatter: (value, row) => {
          const canCancel = row.status === 'confirmed' && new Date(row.departure_time) > new Date();
          
          return `<div class="table-actions">
                    <button 
                      class="action-btn view-btn" 
                      onclick="window.viewBooking('${row.booking_id}')"
                      aria-label="View booking details for ${row.booking_id}"
                    >
                      <iconify-icon icon="solar:eye-bold"></iconify-icon>
                      View
                    </button>
                    ${canCancel ? `
                      <button 
                        class="action-btn cancel-btn" 
                        onclick="window.cancelBooking('${row.booking_id}')"
                        aria-label="Cancel booking ${row.booking_id}"
                      >
                        <iconify-icon icon="solar:close-circle-bold"></iconify-icon>
                        Cancel
                      </button>
                    ` : ''}
                  </div>`;
        }
      }
    ];

    const table = new AccessibleTable(container, {
      caption: 'Your Booking History - Complete list of your bus ticket bookings',
      sortable: true,
      filterable: true,
      paginated: true,
      pageSize: 10
    });

    if (!userId) {
      this.showErrorMessage(container, 'Please log in to view your bookings');
      return;
    }

    try {
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select(`
          id,
          passenger_name,
          seats,
          total_price,
          status,
          booking_date,
          trips (
            departure_time,
            bus_routes (
              departure_station:stations!bus_routes_departure_station_id_fkey (name),
              arrival_station:stations!bus_routes_arrival_station_id_fkey (name)
            )
          )
        `)
        .eq('user_id', userId)
        .order('booking_date', { ascending: false });

      if (error) throw error;

      // Transform data for table display
      const transformedData = bookings.map(booking => ({
        booking_id: booking.id,
        departure_station: booking.trips.bus_routes.departure_station.name,
        arrival_station: booking.trips.bus_routes.arrival_station.name,
        departure_time: booking.trips.departure_time,
        passenger_name: booking.passenger_name,
        seats: booking.seats,
        total_price: booking.total_price,
        status: booking.status,
        booking_date: booking.booking_date
      }));

      table.setData(transformedData, columns);
      this.tables.set('bookings', table);
      
      return table;
    } catch (error) {
      console.error('Error loading bookings:', error);
      this.showErrorMessage(container, 'Failed to load booking history');
    }
  }

  showErrorMessage(container, message) {
    container.innerHTML = `
      <div class="error-message" role="alert">
        <iconify-icon icon="solar:danger-circle-bold" class="error-icon"></iconify-icon>
        <p>${message}</p>
      </div>
    `;
  }

  // Utility methods
  getTable(name) {
    return this.tables.get(name);
  }

  refreshTable(name) {
    const table = this.tables.get(name);
    if (table) {
      // Re-fetch data and update table
      // Implementation depends on table type
    }
  }

  clearAllFilters() {
    this.tables.forEach(table => {
      table.clearFilters();
    });
  }
}

// Global functions for button actions
window.bookTrip = function(tripId) {
  // Implementation for booking a trip
  console.log('Booking trip:', tripId);
};

window.viewBooking = function(bookingId) {
  // Implementation for viewing booking details
  console.log('Viewing booking:', bookingId);
};

window.cancelBooking = function(bookingId) {
  // Implementation for canceling a booking
  console.log('Canceling booking:', bookingId);
};