import { i18n } from '../main.js';
import { layoutManager } from '../main.js';

export class LanguageSwitcher {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.currentLocale = i18n.getLocale();
    this.render();
    this.attachEventListeners();
  }

  render() {
    const locales = [
      { code: 'ar', name: 'العربية', flag: '🇸🇦' },
      { code: 'en', name: 'English', flag: '🇺🇸' }
    ];

    const currentLocaleData = locales.find(l => l.code === this.currentLocale);

    const html = `
      <div class="relative language-switcher">
        <button
          id="language-toggle"
          class="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-[#F5F5F5] transition active:scale-95"
          aria-label="${i18n.t('accessibility.selectLanguage')}"
          aria-haspopup="true"
          aria-expanded="false"
        >
          <span class="text-lg">${currentLocaleData.flag}</span>
          <span class="text-sm font-medium text-foreground hidden sm:inline">${currentLocaleData.name}</span>
          <iconify-icon icon="solar:alt-arrow-down-bold" class="size-4 text-muted-foreground"></iconify-icon>
        </button>

        <div
          id="language-menu"
          class="hidden absolute top-full mt-2 bg-white rounded-xl shadow-2xl border border-[#E0E0E0] min-w-[160px] z-50"
          role="menu"
          aria-orientation="vertical"
        >
          ${locales.map(locale => `
            <button
              class="language-option w-full flex items-center gap-3 px-4 py-3 hover:bg-[#F5F5F5] transition text-left first:rounded-t-xl last:rounded-b-xl ${locale.code === this.currentLocale ? 'bg-[#f5f5f0]' : ''}"
              data-locale="${locale.code}"
              role="menuitem"
              ${locale.code === this.currentLocale ? 'aria-current="true"' : ''}
            >
              <span class="text-xl">${locale.flag}</span>
              <span class="flex-1 text-sm font-medium text-foreground">${locale.name}</span>
              ${locale.code === this.currentLocale ? '<iconify-icon icon="solar:check-circle-bold" class="size-5 text-[#4caf50]"></iconify-icon>' : ''}
            </button>
          `).join('')}
        </div>
      </div>
    `;

    if (this.container) {
      this.container.innerHTML = html;
    }
  }

  attachEventListeners() {
    const toggle = document.getElementById('language-toggle');
    const menu = document.getElementById('language-menu');
    const options = document.querySelectorAll('.language-option');

    if (toggle && menu) {
      toggle.addEventListener('click', (e) => {
        e.stopPropagation();
        const isExpanded = toggle.getAttribute('aria-expanded') === 'true';
        this.toggleMenu(!isExpanded);
      });

      document.addEventListener('click', (e) => {
        if (!this.container.contains(e.target)) {
          this.toggleMenu(false);
        }
      });

      options.forEach(option => {
        option.addEventListener('click', async (e) => {
          const locale = option.getAttribute('data-locale');
          if (locale !== this.currentLocale) {
            await this.changeLanguage(locale);
          }
          this.toggleMenu(false);
        });
      });
    }
  }

  toggleMenu(show) {
    const toggle = document.getElementById('language-toggle');
    const menu = document.getElementById('language-menu');

    if (toggle && menu) {
      if (show) {
        menu.classList.remove('hidden');
        toggle.setAttribute('aria-expanded', 'true');

        const direction = layoutManager.getDirection();
        if (direction === 'rtl') {
          menu.style.right = '0';
          menu.style.left = 'auto';
        } else {
          menu.style.left = '0';
          menu.style.right = 'auto';
        }
      } else {
        menu.classList.add('hidden');
        toggle.setAttribute('aria-expanded', 'false');
      }
    }
  }

  async changeLanguage(locale) {
    const loadingOverlay = document.getElementById('loading-overlay');
    if (loadingOverlay) {
      loadingOverlay.classList.remove('hidden');
    }

    try {
      await i18n.changeLocale(locale);
      this.currentLocale = locale;

      localStorage.setItem('locale', locale);
      window.appState.locale = locale;

      this.updatePageContent();

      this.render();
      this.attachEventListeners();

      if (loadingOverlay) {
        setTimeout(() => {
          loadingOverlay.classList.add('hidden');
        }, 300);
      }
    } catch (error) {
      console.error('Error changing language:', error);
      if (loadingOverlay) {
        loadingOverlay.classList.add('hidden');
      }
    }
  }

  updatePageContent() {
    document.querySelectorAll('[data-i18n]').forEach(element => {
      const key = element.getAttribute('data-i18n');
      const text = i18n.t(key);
      if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
        element.placeholder = text;
      } else {
        element.textContent = text;
      }
    });

    document.querySelectorAll('[data-i18n-html]').forEach(element => {
      const key = element.getAttribute('data-i18n-html');
      element.innerHTML = i18n.t(key);
    });

    document.querySelectorAll('[data-i18n-aria]').forEach(element => {
      const key = element.getAttribute('data-i18n-aria');
      const attr = element.getAttribute('data-aria-attr') || 'aria-label';
      element.setAttribute(attr, i18n.t(key));
    });

    document.title = i18n.t('app.title') || 'SAPTCO';

    const event = new CustomEvent('languageChanged', {
      detail: { locale: this.currentLocale }
    });
    window.dispatchEvent(event);
  }

  destroy() {
    if (this.container) {
      this.container.innerHTML = '';
    }
  }
}

export function createLanguageSwitcher(containerId) {
  return new LanguageSwitcher(containerId);
}
