export function createHeader(options = {}) {
  const {
    title = '',
    showBackButton = false,
    backUrl = 'index.html',
    showMenu = true,
    transparent = false
  } = options;

  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  const storedLang = localStorage.getItem('saptco_language') || 'ar';
  const langDisplay = storedLang === 'ar' ? 'En' : 'ع';

  const headerHTML = `
    <header id="mainHeader" class="sticky top-0 z-50 bg-gradient-to-b from-card via-card to-card/95 backdrop-blur-md shadow-lg border-b border-border/50 transition-all duration-500">
      <div class="w-full">
        <div class="flex items-center justify-between px-6 py-4">
          ${showMenu ? `
            <div class="flex items-center gap-2">
              <button id="menuToggle" class="group relative flex items-center justify-center w-11 h-11 bg-gradient-to-br from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 rounded-xl transition-all duration-300 shadow-md hover:shadow-xl hover:scale-105 active:scale-95">
                <iconify-icon id="menuIcon" icon="solar:hamburger-menu-bold" class="size-5 text-primary-foreground transition-transform duration-300"></iconify-icon>
              </button>
              <button id="darkModeToggle" data-dark-mode-toggle class="group relative flex items-center justify-center w-11 h-11 bg-gradient-to-br from-secondary to-secondary/80 hover:from-secondary/90 hover:to-secondary/70 rounded-xl transition-all duration-300 shadow-md hover:shadow-xl hover:scale-105 active:scale-95">
                <iconify-icon icon="solar:moon-bold" class="size-5 text-secondary-foreground transition-transform duration-300"></iconify-icon>
              </button>
              <button id="languageToggle" class="group relative flex items-center justify-center w-11 h-11 bg-gradient-to-br from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 rounded-xl transition-all duration-300 shadow-md hover:shadow-xl hover:scale-105 active:scale-95">
                <span class="text-sm font-bold text-accent-foreground transition-transform duration-300">${langDisplay}</span>
              </button>
            </div>
          ` : showBackButton ? `
            <a href="${backUrl}" class="group relative flex items-center justify-center w-11 h-11 bg-gradient-to-br from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 rounded-xl transition-all duration-300 shadow-md hover:shadow-xl hover:scale-105 active:scale-95">
              <iconify-icon icon="solar:arrow-right-linear" class="size-5 text-primary-foreground"></iconify-icon>
            </a>
          ` : '<div class="w-11"></div>'}

          <a href="index.html" class="flex items-center justify-center transition-transform duration-300 hover:scale-105 active:scale-95">
            <img src="/logo.png" alt="SAPTCO" class="h-14 md:h-16 object-contain drop-shadow-lg">
          </a>

          ${showMenu ? `
            <a href="profile.html" class="group relative flex items-center justify-center w-11 h-11 bg-gradient-to-br from-muted to-muted/80 hover:from-muted/90 hover:to-muted/70 rounded-xl transition-all duration-300 shadow-md hover:shadow-xl hover:scale-105 active:scale-95">
              <iconify-icon icon="solar:user-bold" class="size-5 text-foreground"></iconify-icon>
            </a>
          ` : '<div class="w-11"></div>'}
        </div>
      </div>
      <div id="headerProgress" class="h-1 bg-primary origin-left scale-x-0 transition-transform duration-300"></div>
    </header>

    ${!showBackButton ? `
      <div id="mobileMenu" class="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 hidden lg:hidden opacity-0 transition-opacity duration-300">
        <div class="fixed right-0 top-0 bottom-0 w-80 bg-gradient-to-b from-card to-card/95 shadow-2xl transform transition-all duration-500 ease-out translate-x-full" id="mobileMenuPanel">
          <div class="flex items-center justify-between p-5 border-b border-border/50 bg-gradient-to-r from-primary/5 to-transparent">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <iconify-icon icon="solar:menu-dots-bold" class="size-5 text-primary"></iconify-icon>
              </div>
              <h2 class="text-lg font-bold text-foreground">القائمة الرئيسية</h2>
            </div>
            <button id="menuClose" class="group flex items-center justify-center size-10 hover:bg-muted/50 rounded-xl transition-all duration-300 hover:rotate-90">
              <iconify-icon icon="solar:close-circle-bold" class="size-6 text-foreground group-hover:text-primary transition-colors"></iconify-icon>
            </button>
          </div>
          <nav class="p-4 space-y-2 overflow-y-auto max-h-[calc(100vh-80px)]">
            <a href="index.html" class="menu-item flex items-center gap-3 px-4 py-3.5 rounded-xl hover:bg-gradient-to-r hover:from-primary/10 hover:to-transparent transition-all duration-300 text-foreground group ${currentPage === 'index.html' ? 'bg-gradient-to-r from-primary/10 to-transparent border-r-4 border-primary' : ''}">
              <div class="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <iconify-icon icon="solar:home-bold" class="size-5 ${currentPage === 'index.html' ? 'text-primary' : 'text-muted-foreground'}"></iconify-icon>
              </div>
              <span class="font-medium ${currentPage === 'index.html' ? 'text-primary font-semibold' : ''}">الرئيسية</span>
              ${currentPage === 'index.html' ? '<div class="mr-auto w-2 h-2 rounded-full bg-primary animate-pulse"></div>' : ''}
            </a>
            <a href="track-booking.html" class="menu-item flex items-center gap-3 px-4 py-3.5 rounded-xl hover:bg-gradient-to-r hover:from-primary/10 hover:to-transparent transition-all duration-300 text-foreground group ${currentPage === 'track-booking.html' ? 'bg-gradient-to-r from-primary/10 to-transparent border-r-4 border-primary' : ''}">
              <div class="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <iconify-icon icon="solar:document-text-bold" class="size-5 ${currentPage === 'track-booking.html' ? 'text-primary' : 'text-muted-foreground'}"></iconify-icon>
              </div>
              <span class="font-medium ${currentPage === 'track-booking.html' ? 'text-primary font-semibold' : ''}">تتبع الحجز</span>
              ${currentPage === 'track-booking.html' ? '<div class="mr-auto w-2 h-2 rounded-full bg-primary animate-pulse"></div>' : ''}
            </a>
            <a href="about-saptco.html" class="menu-item flex items-center gap-3 px-4 py-3.5 rounded-xl hover:bg-gradient-to-r hover:from-primary/10 hover:to-transparent transition-all duration-300 text-foreground group ${currentPage === 'about-saptco.html' ? 'bg-gradient-to-r from-primary/10 to-transparent border-r-4 border-primary' : ''}">
              <div class="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <iconify-icon icon="solar:info-circle-bold" class="size-5 ${currentPage === 'about-saptco.html' ? 'text-primary' : 'text-muted-foreground'}"></iconify-icon>
              </div>
              <span class="font-medium ${currentPage === 'about-saptco.html' ? 'text-primary font-semibold' : ''}">عن سابتكو</span>
              ${currentPage === 'about-saptco.html' ? '<div class="mr-auto w-2 h-2 rounded-full bg-primary animate-pulse"></div>' : ''}
            </a>
            <a href="faq.html" class="menu-item flex items-center gap-3 px-4 py-3.5 rounded-xl hover:bg-gradient-to-r hover:from-primary/10 hover:to-transparent transition-all duration-300 text-foreground group ${currentPage === 'faq.html' ? 'bg-gradient-to-r from-primary/10 to-transparent border-r-4 border-primary' : ''}">
              <div class="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <iconify-icon icon="solar:question-circle-bold" class="size-5 ${currentPage === 'faq.html' ? 'text-primary' : 'text-muted-foreground'}"></iconify-icon>
              </div>
              <span class="font-medium ${currentPage === 'faq.html' ? 'text-primary font-semibold' : ''}">الأسئلة الشائعة</span>
              ${currentPage === 'faq.html' ? '<div class="mr-auto w-2 h-2 rounded-full bg-primary animate-pulse"></div>' : ''}
            </a>
            <a href="profile.html" class="menu-item flex items-center gap-3 px-4 py-3.5 rounded-xl hover:bg-gradient-to-r hover:from-primary/10 hover:to-transparent transition-all duration-300 text-foreground group ${currentPage === 'profile.html' ? 'bg-gradient-to-r from-primary/10 to-transparent border-r-4 border-primary' : ''}">
              <div class="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <iconify-icon icon="solar:user-bold" class="size-5 ${currentPage === 'profile.html' ? 'text-primary' : 'text-muted-foreground'}"></iconify-icon>
              </div>
              <span class="font-medium ${currentPage === 'profile.html' ? 'text-primary font-semibold' : ''}">الملف الشخصي</span>
              ${currentPage === 'profile.html' ? '<div class="mr-auto w-2 h-2 rounded-full bg-primary animate-pulse"></div>' : ''}
            </a>
            <div class="h-px bg-border/50 my-4"></div>
            <div class="px-4 py-3 rounded-xl bg-gradient-to-br from-primary/5 to-secondary/5 border border-border/30">
              <div class="flex items-center gap-2 text-xs text-muted-foreground mb-2">
                <iconify-icon icon="solar:info-circle-bold" class="size-4"></iconify-icon>
                <span class="font-medium">نصيحة سريعة</span>
              </div>
              <p class="text-xs text-muted-foreground leading-relaxed">استخدم البحث السريع للوصول إلى وجهتك المفضلة بسرعة</p>
            </div>
          </nav>
        </div>
      </div>
    ` : ''}
  `;

  return headerHTML;
}

export function initHeaderEvents() {
  const menuToggle = document.getElementById('menuToggle');
  const menuClose = document.getElementById('menuClose');
  const mobileMenu = document.getElementById('mobileMenu');
  const mobileMenuPanel = document.getElementById('mobileMenuPanel');
  const menuIcon = document.getElementById('menuIcon');

  if (menuToggle && mobileMenu && mobileMenuPanel) {
    let menuOpen = false;

    const openMenu = () => {
      menuOpen = true;
      mobileMenu.classList.remove('hidden');
      if (menuIcon) {
        menuIcon.setAttribute('icon', 'solar:close-circle-bold');
        menuIcon.classList.add('rotate-90');
      }
      requestAnimationFrame(() => {
        mobileMenu.classList.remove('opacity-0');
        mobileMenuPanel.classList.remove('translate-x-full');
      });
    };

    const closeMenu = () => {
      menuOpen = false;
      mobileMenu.classList.add('opacity-0');
      mobileMenuPanel.classList.add('translate-x-full');
      if (menuIcon) {
        menuIcon.setAttribute('icon', 'solar:hamburger-menu-bold');
        menuIcon.classList.remove('rotate-90');
      }
      setTimeout(() => {
        mobileMenu.classList.add('hidden');
      }, 300);
    };

    menuToggle.addEventListener('click', () => {
      if (menuOpen) {
        closeMenu();
      } else {
        openMenu();
      }
    });

    if (menuClose) {
      menuClose.addEventListener('click', closeMenu);
    }

    mobileMenu.addEventListener('click', (e) => {
      if (e.target === mobileMenu) {
        closeMenu();
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && menuOpen) {
        closeMenu();
      }
    });
  }

  const languageToggle = document.getElementById('languageToggle');
  if (languageToggle) {
    languageToggle.addEventListener('click', async () => {
      const currentLang = localStorage.getItem('saptco_language') || 'ar';
      const newLang = currentLang === 'ar' ? 'en' : 'ar';
      const displayText = newLang === 'ar' ? 'En' : 'ع';

      localStorage.setItem('saptco_language', newLang);
      languageToggle.querySelector('span').textContent = displayText;

      document.documentElement.setAttribute('lang', newLang);
      document.documentElement.setAttribute('dir', newLang === 'ar' ? 'rtl' : 'ltr');

      languageToggle.classList.add('scale-90');
      setTimeout(() => {
        languageToggle.classList.remove('scale-90');
      }, 150);

      window.dispatchEvent(new CustomEvent('languageChanged', { detail: { language: newLang } }));
    });
  }

  setupScrollEffect();
}

function setupScrollEffect() {
  const header = document.getElementById('mainHeader');
  const progress = document.getElementById('headerProgress');
  let lastScroll = 0;

  if (!header || !progress) return;

  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const scrollPercent = (currentScroll / docHeight) * 100;

    progress.style.transform = `scaleX(${scrollPercent / 100})`;

    if (currentScroll > lastScroll && currentScroll > 100) {
      header.style.transform = 'translateY(-100%)';
    } else {
      header.style.transform = 'translateY(0)';
    }

    if (currentScroll > 50) {
      header.classList.add('shadow-xl');
    } else {
      header.classList.remove('shadow-xl');
    }

    lastScroll = currentScroll;
  }, { passive: true });
}
