/**
 * Accessible Data Table Component
 * Provides full accessibility support with ARIA attributes, keyboard navigation, and sorting
 */

export class AccessibleTable {
  constructor(container, options = {}) {
    this.container = container;
    this.options = {
      sortable: true,
      filterable: false,
      paginated: false,
      pageSize: 10,
      ...options
    };
    this.data = [];
    this.sortColumn = null;
    this.sortDirection = 'asc';
    this.currentPage = 1;
    this.filteredData = [];
    
    this.init();
  }

  init() {
    this.container.setAttribute('role', 'region');
    this.container.setAttribute('aria-label', this.options.caption || 'Data table');
    this.container.classList.add('accessible-table-container');
    
    // Add keyboard event listeners
    this.container.addEventListener('keydown', this.handleKeydown.bind(this));
    
    // Add focus management
    this.container.setAttribute('tabindex', '0');
  }

  setData(data, columns) {
    this.data = data;
    this.columns = columns;
    this.filteredData = [...data];
    this.render();
  }

  render() {
    const tableHTML = this.generateTableHTML();
    this.container.innerHTML = tableHTML;
    
    // Add event listeners after rendering
    this.addEventListeners();
    
    // Announce changes to screen readers
    this.announceTableUpdate();
  }

  generateTableHTML() {
    const { caption, sortable } = this.options;
    const data = this.getPaginatedData();
    
    return `
      <div class="table-wrapper" role="table" aria-label="${caption || 'Data table'}">
        ${this.generateTableControls()}
        <table class="accessible-table" role="presentation">
          ${caption ? `<caption class="table-caption">${caption}</caption>` : ''}
          <thead>
            <tr role="row">
              ${this.columns.map((col, index) => `
                <th 
                  role="columnheader"
                  scope="col"
                  class="table-header ${sortable && col.sortable !== false ? 'sortable' : ''}"
                  ${sortable && col.sortable !== false ? `
                    tabindex="0"
                    aria-sort="${this.getSortState(col.key)}"
                    data-column="${col.key}"
                    data-column-index="${index}"
                  ` : ''}
                >
                  <div class="header-content">
                    <span class="header-text">${col.label}</span>
                    ${sortable && col.sortable !== false ? `
                      <span class="sort-indicator" aria-hidden="true">
                        <iconify-icon icon="solar:sort-vertical-bold" class="sort-icon"></iconify-icon>
                      </span>
                    ` : ''}
                  </div>
                </th>
              `).join('')}
            </tr>
          </thead>
          <tbody>
            ${data.map((row, rowIndex) => `
              <tr role="row" class="table-row" tabindex="0" data-row-index="${rowIndex}">
                ${this.columns.map((col, colIndex) => `
                  <td 
                    role="gridcell"
                    class="table-cell"
                    data-column="${col.key}"
                    ${col.key === this.columns[0].key ? 'scope="row"' : ''}
                  >
                    ${this.formatCellValue(row[col.key], col, row)}
                  </td>
                `).join('')}
              </tr>
            `).join('')}
          </tbody>
        </table>
        ${this.generateTableFooter()}
      </div>
      <div id="table-announcements" class="sr-only" aria-live="polite" aria-atomic="true"></div>
    `;
  }

  generateTableControls() {
    if (!this.options.filterable && !this.options.paginated) return '';
    
    return `
      <div class="table-controls" role="toolbar" aria-label="Table controls">
        ${this.options.filterable ? `
          <div class="filter-controls">
            <label for="table-filter" class="filter-label">Filter table:</label>
            <input 
              type="text" 
              id="table-filter" 
              class="filter-input"
              placeholder="Search..."
              aria-describedby="filter-help"
            >
            <div id="filter-help" class="sr-only">
              Type to filter table results. Results will update as you type.
            </div>
          </div>
        ` : ''}
        
        ${this.options.paginated ? `
          <div class="pagination-info" aria-live="polite">
            Showing ${this.getStartRecord()} to ${this.getEndRecord()} of ${this.filteredData.length} entries
          </div>
        ` : ''}
      </div>
    `;
  }

  generateTableFooter() {
    if (!this.options.paginated) return '';
    
    const totalPages = Math.ceil(this.filteredData.length / this.options.pageSize);
    
    return `
      <nav class="table-pagination" role="navigation" aria-label="Table pagination">
        <button 
          class="pagination-btn prev-btn" 
          ${this.currentPage === 1 ? 'disabled' : ''}
          aria-label="Go to previous page"
        >
          <iconify-icon icon="solar:arrow-left-bold"></iconify-icon>
          Previous
        </button>
        
        <div class="pagination-info">
          Page ${this.currentPage} of ${totalPages}
        </div>
        
        <button 
          class="pagination-btn next-btn"
          ${this.currentPage === totalPages ? 'disabled' : ''}
          aria-label="Go to next page"
        >
          Next
          <iconify-icon icon="solar:arrow-right-bold"></iconify-icon>
        </button>
      </nav>
    `;
  }

  formatCellValue(value, column, row) {
    if (column.formatter) {
      return column.formatter(value, row);
    }
    
    if (value === null || value === undefined) {
      return '<span class="empty-cell" aria-label="Empty">—</span>';
    }
    
    return String(value);
  }

  getSortState(columnKey) {
    if (this.sortColumn !== columnKey) return 'none';
    return this.sortDirection;
  }

  addEventListeners() {
    // Sort functionality
    if (this.options.sortable) {
      const sortableHeaders = this.container.querySelectorAll('.sortable');
      sortableHeaders.forEach(header => {
        header.addEventListener('click', this.handleSort.bind(this));
        header.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleSort(e);
          }
        });
      });
    }

    // Filter functionality
    if (this.options.filterable) {
      const filterInput = this.container.querySelector('#table-filter');
      if (filterInput) {
        filterInput.addEventListener('input', this.handleFilter.bind(this));
      }
    }

    // Pagination functionality
    if (this.options.paginated) {
      const prevBtn = this.container.querySelector('.prev-btn');
      const nextBtn = this.container.querySelector('.next-btn');
      
      if (prevBtn) {
        prevBtn.addEventListener('click', () => this.goToPage(this.currentPage - 1));
      }
      
      if (nextBtn) {
        nextBtn.addEventListener('click', () => this.goToPage(this.currentPage + 1));
      }
    }

    // Row focus management
    const rows = this.container.querySelectorAll('.table-row');
    rows.forEach(row => {
      row.addEventListener('focus', this.handleRowFocus.bind(this));
    });
  }

  handleSort(event) {
    const header = event.currentTarget;
    const columnKey = header.dataset.column;
    
    // Toggle sort direction if same column, otherwise set to ascending
    if (this.sortColumn === columnKey) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = columnKey;
      this.sortDirection = 'asc';
    }
    
    this.sortData();
    this.render();
    
    // Announce sort change
    const column = this.columns.find(col => col.key === columnKey);
    this.announceChange(`Table sorted by ${column.label} in ${this.sortDirection}ending order`);
  }

  handleFilter(event) {
    const filterValue = event.target.value.toLowerCase();
    
    this.filteredData = this.data.filter(row => {
      return this.columns.some(col => {
        const cellValue = String(row[col.key] || '').toLowerCase();
        return cellValue.includes(filterValue);
      });
    });
    
    this.currentPage = 1; // Reset to first page
    this.render();
    
    // Announce filter results
    this.announceChange(`Filter applied. Showing ${this.filteredData.length} of ${this.data.length} entries`);
  }

  handleKeydown(event) {
    const { key, target } = event;
    
    // Handle arrow key navigation within table
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(key)) {
      this.handleArrowNavigation(event);
    }
    
    // Handle Home/End keys
    if (key === 'Home' || key === 'End') {
      this.handleHomeEnd(event);
    }
  }

  handleArrowNavigation(event) {
    const { key, target } = event;
    
    if (!target.closest('.table-row') && !target.closest('.table-header')) return;
    
    event.preventDefault();
    
    const currentRow = target.closest('tr');
    const currentCell = target.closest('td, th');
    
    if (!currentRow || !currentCell) return;
    
    const rows = Array.from(this.container.querySelectorAll('tr'));
    const cells = Array.from(currentRow.querySelectorAll('td, th'));
    
    const rowIndex = rows.indexOf(currentRow);
    const cellIndex = cells.indexOf(currentCell);
    
    let newRow, newCell;
    
    switch (key) {
      case 'ArrowUp':
        newRow = rows[rowIndex - 1];
        if (newRow) {
          newCell = newRow.querySelectorAll('td, th')[cellIndex];
        }
        break;
        
      case 'ArrowDown':
        newRow = rows[rowIndex + 1];
        if (newRow) {
          newCell = newRow.querySelectorAll('td, th')[cellIndex];
        }
        break;
        
      case 'ArrowLeft':
        newCell = cells[cellIndex - 1];
        break;
        
      case 'ArrowRight':
        newCell = cells[cellIndex + 1];
        break;
    }
    
    if (newCell) {
      const focusableElement = newCell.querySelector('[tabindex="0"]') || newCell;
      if (focusableElement.tabIndex >= 0) {
        focusableElement.focus();
      }
    }
  }

  handleHomeEnd(event) {
    const { key, target } = event;
    
    if (!target.closest('.table-row')) return;
    
    event.preventDefault();
    
    const currentRow = target.closest('tr');
    const cells = Array.from(currentRow.querySelectorAll('td, th'));
    
    const targetCell = key === 'Home' ? cells[0] : cells[cells.length - 1];
    const focusableElement = targetCell.querySelector('[tabindex="0"]') || targetCell;
    
    if (focusableElement.tabIndex >= 0) {
      focusableElement.focus();
    }
  }

  handleRowFocus(event) {
    const row = event.currentTarget;
    const rowIndex = row.dataset.rowIndex;
    
    // Announce row information to screen readers
    const rowData = this.getPaginatedData()[rowIndex];
    if (rowData) {
      const description = this.columns
        .slice(0, 3) // Announce first 3 columns to avoid verbosity
        .map(col => `${col.label}: ${rowData[col.key]}`)
        .join(', ');
      
      this.announceChange(`Row ${parseInt(rowIndex) + 1}. ${description}`);
    }
  }

  sortData() {
    const column = this.columns.find(col => col.key === this.sortColumn);
    if (!column) return;
    
    this.filteredData.sort((a, b) => {
      let aVal = a[this.sortColumn];
      let bVal = b[this.sortColumn];
      
      // Handle null/undefined values
      if (aVal == null && bVal == null) return 0;
      if (aVal == null) return 1;
      if (bVal == null) return -1;
      
      // Apply custom sort function if provided
      if (column.sortFn) {
        return column.sortFn(aVal, bVal) * (this.sortDirection === 'desc' ? -1 : 1);
      }
      
      // Default sorting
      if (typeof aVal === 'string') {
        aVal = aVal.toLowerCase();
        bVal = bVal.toLowerCase();
      }
      
      if (aVal < bVal) return this.sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return this.sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }

  getPaginatedData() {
    if (!this.options.paginated) return this.filteredData;
    
    const start = (this.currentPage - 1) * this.options.pageSize;
    const end = start + this.options.pageSize;
    return this.filteredData.slice(start, end);
  }

  goToPage(page) {
    const totalPages = Math.ceil(this.filteredData.length / this.options.pageSize);
    
    if (page < 1 || page > totalPages) return;
    
    this.currentPage = page;
    this.render();
    
    this.announceChange(`Navigated to page ${page} of ${totalPages}`);
  }

  getStartRecord() {
    return Math.min((this.currentPage - 1) * this.options.pageSize + 1, this.filteredData.length);
  }

  getEndRecord() {
    return Math.min(this.currentPage * this.options.pageSize, this.filteredData.length);
  }

  announceTableUpdate() {
    const totalRows = this.filteredData.length;
    const visibleRows = this.getPaginatedData().length;
    
    let message = `Table updated. ${totalRows} total entries`;
    if (this.options.paginated) {
      message += `, showing ${visibleRows} entries on page ${this.currentPage}`;
    }
    
    this.announceChange(message);
  }

  announceChange(message) {
    const announcer = this.container.querySelector('#table-announcements');
    if (announcer) {
      announcer.textContent = message;
    }
  }

  // Public API methods
  updateData(newData) {
    this.setData(newData, this.columns);
  }

  clearFilters() {
    this.filteredData = [...this.data];
    this.currentPage = 1;
    const filterInput = this.container.querySelector('#table-filter');
    if (filterInput) {
      filterInput.value = '';
    }
    this.render();
  }

  exportData() {
    return {
      data: this.filteredData,
      sortColumn: this.sortColumn,
      sortDirection: this.sortDirection,
      currentPage: this.currentPage
    };
  }
}