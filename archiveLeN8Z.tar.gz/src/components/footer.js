export function createFooter() {
  const footerHTML = `
    <footer class="bg-card border-t-2 border-border mt-auto">
      <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <img src="/logo.png" alt="SAPTCO" class="h-12 mb-4 object-contain">
            <p class="text-sm text-muted-foreground leading-relaxed">
              الشركة السعودية للنقل الجماعي (سابتكو) هي الشركة الرائدة في مجال النقل البري في المملكة العربية السعودية
            </p>
          </div>

          <div>
            <h3 class="text-foreground font-semibold mb-4">روابط سريعة</h3>
            <ul class="space-y-2">
              <li>
                <a href="index.html" class="text-sm text-muted-foreground hover:text-primary transition">
                  الرئيسية
                </a>
              </li>
              <li>
                <a href="track-booking.html" class="text-sm text-muted-foreground hover:text-primary transition">
                  تتبع الحجز
                </a>
              </li>
              <li>
                <a href="about-saptco.html" class="text-sm text-muted-foreground hover:text-primary transition">
                  عن سابتكو
                </a>
              </li>
              <li>
                <a href="faq.html" class="text-sm text-muted-foreground hover:text-primary transition">
                  الأسئلة الشائعة
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 class="text-foreground font-semibold mb-4">خدماتنا</h3>
            <ul class="space-y-2">
              <li>
                <a href="index.html" class="text-sm text-muted-foreground hover:text-primary transition">
                  حجز التذاكر
                </a>
              </li>
              <li>
                <a href="index.html" class="text-sm text-muted-foreground hover:text-primary transition">
                  الرحلات الداخلية
                </a>
              </li>
              <li>
                <a href="index.html" class="text-sm text-muted-foreground hover:text-primary transition">
                  الرحلات الدولية
                </a>
              </li>
              <li>
                <a href="profile.html" class="text-sm text-muted-foreground hover:text-primary transition">
                  حسابي
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 class="text-foreground font-semibold mb-4">تواصل معنا</h3>
            <ul class="space-y-3">
              <li class="flex items-center gap-2 text-sm text-muted-foreground">
                <iconify-icon icon="solar:phone-bold" class="size-5 text-primary"></iconify-icon>
                <span dir="ltr">920000980</span>
              </li>
              <li class="flex items-center gap-2 text-sm text-muted-foreground">
                <iconify-icon icon="solar:letter-bold" class="size-5 text-primary"></iconify-icon>
                <span dir="ltr">info@saptco.com.sa</span>
              </li>
              <li class="flex items-center gap-2 text-sm text-muted-foreground">
                <iconify-icon icon="solar:map-point-bold" class="size-5 text-primary"></iconify-icon>
                <span>الرياض، المملكة العربية السعودية</span>
              </li>
            </ul>
            <div class="flex items-center gap-3 mt-4">
              <a href="#" class="flex items-center justify-center size-9 bg-primary/10 hover:bg-primary hover:text-primary-foreground rounded-lg transition">
                <iconify-icon icon="ri:twitter-x-fill" class="size-4"></iconify-icon>
              </a>
              <a href="#" class="flex items-center justify-center size-9 bg-primary/10 hover:bg-primary hover:text-primary-foreground rounded-lg transition">
                <iconify-icon icon="ri:facebook-fill" class="size-4"></iconify-icon>
              </a>
              <a href="#" class="flex items-center justify-center size-9 bg-primary/10 hover:bg-primary hover:text-primary-foreground rounded-lg transition">
                <iconify-icon icon="ri:instagram-fill" class="size-4"></iconify-icon>
              </a>
              <a href="#" class="flex items-center justify-center size-9 bg-primary/10 hover:bg-primary hover:text-primary-foreground rounded-lg transition">
                <iconify-icon icon="ri:linkedin-fill" class="size-4"></iconify-icon>
              </a>
            </div>
          </div>
        </div>

        <div class="mt-8 pt-6 border-t border-border">
          <div class="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <p>
              &copy; ${new Date().getFullYear()} الشركة السعودية للنقل الجماعي (سابتكو). جميع الحقوق محفوظة
            </p>
            <div class="flex items-center gap-4">
              <a href="#" class="hover:text-primary transition">سياسة الخصوصية</a>
              <span>|</span>
              <a href="#" class="hover:text-primary transition">الشروط والأحكام</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  `;

  return footerHTML;
}
