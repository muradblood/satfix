import {
  FormValidator,
  validators,
  showSuccessMessage,
  showErrorMessage,
  showLoadingOverlay,
  hideLoadingOverlay,
} from './modules/formValidator.js';
import { searchTrips } from './services/tripsService.js';
import { StationSearchSelect } from './components/StationSearchSelect.js';

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('bookingForm');
  const tripTypeInput = form.querySelector('[name="tripType"]');
  const roundtripBtn = document.getElementById('roundtripBtn');
  const onewayBtn = document.getElementById('onewayBtn');
  const returnDateField = document.getElementById('returnDateField');
  const swapStationsBtn = document.getElementById('swapStationsBtn');
  const decreaseBtn = document.getElementById('decreasePassengers');
  const increaseBtn = document.getElementById('increasePassengers');
  const passengerCountSpan = document.getElementById('passengerCount');
  const passengerInput = form.querySelector('[name="passengers"]');
  const passengerLabelSpan = passengerCountSpan.nextElementSibling;

  const fromStationInput = document.getElementById('fromStationSearch');
  const toStationInput = document.getElementById('toStationSearch');

  // مكوّن اختيار المحطات
  const fromStationSearch = new StationSearchSelect(fromStationInput, {
    placeholder: 'ابحث عن محطة المغادرة...',
    onChange: () => {
      validator.validateField('fromStation');
    },
  });

  const toStationSearch = new StationSearchSelect(toStationInput, {
    placeholder: 'ابحث عن محطة الوصول...',
    onChange: () => {
      validator.validateField('toStation');
    },
  });

  let passengerCount = 1;

  function updatePassengerLabel(count) {
    if (count === 1) {
      passengerLabelSpan.textContent = 'مسافر';
    } else if (count === 2) {
      passengerLabelSpan.textContent = 'مسافران';
    } else if (count >= 3 && count <= 10) {
      passengerLabelSpan.textContent = 'مسافرين';
    } else {
      passengerLabelSpan.textContent = 'مسافر';
    }
  }

  const validator = new FormValidator(form, {
    validateOnInput: true,
    validateOnBlur: true,
    showSuccessIndicators: true,
    debounceDelay: 400,
  });

  function updateValidationRules() {
    const tripType = tripTypeInput.value;

    validator.fields.clear();

    validator
      .addField('fromStation', [
        validators.required('يرجى اختيار محطة المغادرة'),
      ])
      .addField('toStation', [
        validators.required('يرجى اختيار محطة الوصول'),
        validators.notEqual('fromStation', 'محطة الوصول يجب أن تختلف عن محطة المغادرة'),
      ])
      .addField('departureDate', [
        validators.required('يرجى اختيار تاريخ المغادرة'),
        validators.futureDate('يرجى اختيار تاريخ في المستقبل'),
      ]);

    if (tripType === 'roundtrip') {
      validator.addField('returnDate', [
        validators.required('يرجى اختيار تاريخ العودة'),
        validators.futureDate('يرجى اختيار تاريخ في المستقبل'),
        validators.dateAfter('departureDate', 'تاريخ العودة يجب أن يكون بعد تاريخ المغادرة'),
      ]);
    }

    validator.addField('passengers', [
      validators.required('يرجى تحديد عدد المسافرين'),
      validators.minValue(1, 'يجب أن يكون هناك مسافر واحد على الأقل'),
      validators.maxValue(9, 'الحد الأقصى 9 مسافرين في الحجز الواحد'),
    ]);
  }

  updateValidationRules();

  // الحالة الافتراضية: ذهاب فقط
  returnDateField.style.display = 'none';

  roundtripBtn.addEventListener('click', () => {
    tripTypeInput.value = 'roundtrip';
    roundtripBtn.classList.add('bg-primary', 'text-primary-foreground');
    roundtripBtn.classList.remove('text-secondary-foreground');
    onewayBtn.classList.remove('bg-primary', 'text-primary-foreground');
    onewayBtn.classList.add('text-secondary-foreground');
    returnDateField.style.display = 'block';

    updateValidationRules();
  });

  onewayBtn.addEventListener('click', () => {
    tripTypeInput.value = 'oneway';
    onewayBtn.classList.add('bg-primary', 'text-primary-foreground');
    onewayBtn.classList.remove('text-secondary-foreground');
    roundtripBtn.classList.remove('bg-primary', 'text-primary-foreground');
    roundtripBtn.classList.add('text-secondary-foreground');
    returnDateField.style.display = 'none';

    const returnDateInput = form.querySelector('[name="returnDate"]');
    returnDateInput.value = '';

    const wrapper = returnDateInput.closest('.form-field');
    if (wrapper) {
      wrapper.classList.remove('field-valid', 'field-error');
      const errorMsg = wrapper.querySelector('.field-error-message');
      const successInd = wrapper.querySelector('.field-success-indicator');
      if (errorMsg) errorMsg.remove();
      if (successInd) successInd.remove();
    }

    updateValidationRules();
  });

  swapStationsBtn.addEventListener('click', () => {
    const fromValue = fromStationSearch.getValue();
    const toValue = toStationSearch.getValue();

    fromStationSearch.clear();
    toStationSearch.clear();

    if (toValue) fromStationSearch.setValue(toValue);
    if (fromValue) toStationSearch.setValue(fromValue);

    swapStationsBtn.style.transform = 'rotate(180deg)';
    setTimeout(() => {
      swapStationsBtn.style.transform = 'rotate(0deg)';
    }, 300);

    if (fromStationSearch.getValue()) {
      validator.validateField('fromStation');
    }
    if (toStationSearch.getValue()) {
      validator.validateField('toStation');
    }
  });

  decreaseBtn.addEventListener('click', () => {
    if (passengerCount > 1) {
      passengerCount--;
      passengerCountSpan.textContent = passengerCount;
      passengerInput.value = passengerCount;
      updatePassengerLabel(passengerCount);

      decreaseBtn.style.transform = 'scale(0.9)';
      setTimeout(() => {
        decreaseBtn.style.transform = 'scale(1)';
      }, 100);
    } else {
      decreaseBtn.classList.add('shake-animation');
      setTimeout(() => {
        decreaseBtn.classList.remove('shake-animation');
      }, 500);
    }
  });

  increaseBtn.addEventListener('click', () => {
    if (passengerCount < 9) {
      passengerCount++;
      passengerCountSpan.textContent = passengerCount;
      passengerInput.value = passengerCount;
      updatePassengerLabel(passengerCount);

      increaseBtn.style.transform = 'scale(0.9)';
      setTimeout(() => {
        increaseBtn.style.transform = 'scale(1)';
      }, 100);
    } else {
      increaseBtn.classList.add('shake-animation');
      showErrorMessage('الحد الأقصى 9 مسافرين في الحجز الواحد');
      setTimeout(() => {
        increaseBtn.classList.remove('shake-animation');
      }, 500);
    }
  });

  // إرسال النموذج
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const isValid = validator.validateAll();

    if (!isValid) {
      showErrorMessage('يرجى ملء جميع الحقول المطلوبة بشكل صحيح');

      const firstErrorField = form.querySelector('.field-error');
      if (firstErrorField) {
        firstErrorField.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const input = firstErrorField.querySelector('input, select');
        if (input) {
          setTimeout(() => input.focus(), 300);
        }
      }

      return;
    }

    const formData = validator.getValues();
    const tripType = tripTypeInput.value;

    // ⚠ هنا المهم: نأخذ المحطات كأوبجكت فيه id + name
    const fromStationObj = fromStationSearch.selectedStation;
    const toStationObj = toStationSearch.selectedStation;

    if (!fromStationObj || !toStationObj) {
      showErrorMessage('يرجى اختيار محطة المغادرة والوصول من القائمة');
      return;
    }

    const fromStationId = fromStationObj.id;
    const toStationId = toStationObj.id;
    const fromStationName = fromStationObj.name;
    const toStationName = toStationObj.name;

    showLoadingOverlay('جارٍ البحث عن الرحلات المتاحة...');

    try {
      const bookingData = {
        fromStationId,
        toStationId,
        fromStation: fromStationName,
        toStation: toStationName,
        departureDate: formData.departureDate,
        returnDate: tripType === 'roundtrip' ? formData.returnDate : null,
        passengers: parseInt(formData.passengers, 10),
        tripType: tripType,
        directOnly: form.querySelector('[name="directOnly"]').checked,
        searchDate: new Date().toISOString(),
      };

      // استدعاء الخدمة مع IDs
      const searchResult = await searchTrips({
        fromStationId,
        toStationId,
        departureDate: bookingData.departureDate,
        passengers: bookingData.passengers,
        directOnly: bookingData.directOnly,
      });

      if (!searchResult.success || !searchResult.data || searchResult.data.length === 0) {
        hideLoadingOverlay();
        showErrorMessage(
          searchResult.error || 'لا توجد رحلات متاحة لهذا المسار في التاريخ المحدد'
        );
        return;
      }

      // حفظ بيانات الحجز والنتائج
      sessionStorage.setItem('bookingData', JSON.stringify(bookingData));
      sessionStorage.setItem('searchResults', JSON.stringify(searchResult.data));

      const queryParams = new URLSearchParams({
        from: bookingData.fromStation,
        to: bookingData.toStation,
        departure: formData.departureDate,
        passengers: formData.passengers,
        tripType: tripType,
        directOnly: bookingData.directOnly ? '1' : '0',
      });

      if (tripType === 'roundtrip' && formData.returnDate) {
        queryParams.append('return', formData.returnDate);
      }

      hideLoadingOverlay();
      showSuccessMessage(`تم العثور على ${searchResult.data.length} رحلة متاحة!`);

      setTimeout(() => {
        window.location.href = `trip-results.html?${queryParams.toString()}`;
      }, 800);
    } catch (error) {
      hideLoadingOverlay();
      showErrorMessage('حدث خطأ أثناء البحث. يرجى المحاولة مرة أخرى');
      console.error('Search error:', error);
    }
  });

  const departureDateInput = form.querySelector('[name="departureDate"]');
  const returnDateInput = form.querySelector('[name="returnDate"]');

  departureDateInput.addEventListener('change', () => {
    if (returnDateInput.value && tripTypeInput.value === 'roundtrip') {
      validator.validateField('returnDate');
    }
  });

  const today = new Date().toISOString().split('T')[0];
  departureDateInput.setAttribute('min', today);
  returnDateInput.setAttribute('min', today);
});
