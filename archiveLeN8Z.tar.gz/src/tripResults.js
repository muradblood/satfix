// Handle trip selection and pass data to seat selection page

document.addEventListener('DOMContentLoaded', () => {
  // Get booking data and search results from sessionStorage
  const bookingData = JSON.parse(sessionStorage.getItem('bookingData') || '{}');
  const searchResults = JSON.parse(sessionStorage.getItem('searchResults') || '[]');

  // Display search summary
  displaySearchSummary();

  // Render trips dynamically if we have search results
  if (searchResults.length > 0) {
    renderTrips(searchResults);
  }

  // Add click handlers to all selection buttons
  const allButtons = document.querySelectorAll('button');
  let buttonIndex = 0;

  allButtons.forEach((button) => {
    if (button.textContent.trim() === 'اختيار') {
      const currentIndex = buttonIndex;
      button.addEventListener('click', () => {
        handleTripSelection(currentIndex);
      });
      buttonIndex++;
    }
  });

  function displaySearchSummary() {
    const passengersDisplay = document.getElementById('passengersDisplay');
    const departureDateDisplay = document.getElementById('departureDateDisplay');

    // Update passengers count
    if (passengersDisplay && bookingData.passengers) {
      const passengersNum = parseInt(bookingData.passengers);
      let passengersText = '';

      if (passengersNum === 1) {
        passengersText = 'مسافر واحد';
      } else if (passengersNum === 2) {
        passengersText = 'مسافران';
      } else if (passengersNum >= 3 && passengersNum <= 10) {
        passengersText = `${passengersNum} مسافرين`;
      } else {
        passengersText = `${passengersNum} مسافر`;
      }

      passengersDisplay.textContent = passengersText;
    }

    // Update departure date
    if (departureDateDisplay && bookingData.departureDate) {
      try {
        const dateObj = new Date(bookingData.departureDate);
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const formattedDate = dateObj.toLocaleDateString('ar-SA', options);
        departureDateDisplay.textContent = formattedDate;
      } catch (error) {
        console.error('Error formatting date:', error);
      }
    }

    console.log('Booking Data:', bookingData);
  }

  function renderTrips(trips) {
    // This function would dynamically render trips if needed
    // For now, the static HTML will display the trips
    console.log('Trips loaded from database:', trips);
  }

  function handleTripSelection(tripIndex) {
    // Use trips from search results or fall back to mock data
    const trips = searchResults.length > 0 ? searchResults : [
      {
        id: 1,
        busName: 'حافلة VIP',
        busType: 'vip',
        departureTime: '08:00',
        arrivalTime: '14:30',
        duration: '6 ساعات 30 دقيقة',
        price: 250,
        availableSeats: 12,
        amenities: ['واي-فاي', 'مكيف', 'مقاعد مريحة'],
        route: 'مباشر'
      }
    ];

    const selectedTrip = trips[tripIndex] || trips[0];

    // Save to sessionStorage
    sessionStorage.setItem('selectedTrip', JSON.stringify(selectedTrip));

    // Build URL with all necessary parameters
    const params = new URLSearchParams({
      tripId: selectedTrip.id || selectedTrip.trip_id || tripIndex,
      passengers: bookingData.passengers || 1,
      price: selectedTrip.price || selectedTrip.price_per_seat || 0,
      from: bookingData.fromStation || 'غير محدد',
      to: bookingData.toStation || 'غير محدد',
      date: bookingData.departureDate || new Date().toISOString().split('T')[0],
      time: selectedTrip.departureTime || selectedTrip.departure_time || '00:00'
    });

    // Navigate to seat selection page with parameters
    window.location.href = `seat-selection.html?${params.toString()}`;
  }

  // Add back button functionality
  const backButton = document.querySelector('a[href*="index.html"]');
  if (backButton) {
    backButton.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.href = 'index.html';
    });
  }

  // Check if we have booking data
  if (!bookingData.fromStation || !bookingData.toStation) {
    console.warn('No booking data found, redirecting to home page...');
    // Uncomment to enable redirect:
    // setTimeout(() => {
    //   window.location.href = 'index.html';
    // }, 2000);
  }
});
