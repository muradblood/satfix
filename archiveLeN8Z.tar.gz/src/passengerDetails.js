import {
  FormValidator,
  validators,
  showSuccessMessage,
  showErrorMessage,
  showLoadingOverlay,
  hideLoadingOverlay,
} from './modules/formValidator.js';
import { createBooking } from './services/bookingService.js';

document.addEventListener('DOMContentLoaded', () => {
  // بيانات الحجز من sessionStorage
  const bookingData = JSON.parse(sessionStorage.getItem('bookingData') || '{}');
  const selectedSeats = JSON.parse(sessionStorage.getItem('selectedSeats') || '[]');
  const tripData = JSON.parse(sessionStorage.getItem('selectedTrip') || '{}');

  // عرض الملخص
  displaySummary();

  // توليد فورمات الركاب
  generatePassengerForms();

  // إعداد التحقق والإرسال
  setupFormHandling();

  function displaySummary() {
    const routeSummary = document.getElementById('routeSummary');
    const dateSummary = document.getElementById('dateSummary');
    const seatsSummary = document.getElementById('seatsSummary');
    const totalPriceEl = document.getElementById('totalPrice');

    // المسار
    if (bookingData.fromStation && bookingData.toStation) {
      // من البيانات اللي خزّناها في bookingFormHandler.js (أسماء جاهزة)
      routeSummary.textContent = `${bookingData.toStation} ← ${bookingData.fromStation}`;
    } else {
      routeSummary.textContent = 'لم يتم تحديد المسار';
    }

    // التاريخ
    if (bookingData.departureDate) {
      const date = new Date(bookingData.departureDate);
      if (!isNaN(date.getTime())) {
        dateSummary.textContent = date.toLocaleDateString('ar-SA', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
        });
      } else {
        dateSummary.textContent = bookingData.departureDate;
      }
    } else {
      dateSummary.textContent = 'لم يتم تحديد التاريخ';
    }

    // المقاعد
    if (selectedSeats.length > 0) {
      seatsSummary.textContent = selectedSeats
        .map((s) => s.seatNumber)
        .join(', ');
    } else {
      seatsSummary.textContent = '0';
    }

    // الإجمالي
    if (tripData.price && selectedSeats.length > 0) {
      const total = Number(tripData.price) * selectedSeats.length;
      totalPriceEl.textContent = `${total} ريال`;
    } else {
      totalPriceEl.textContent = '0 ريال';
    }
  }

  function generatePassengerForms() {
    const container = document.getElementById('passengersContainer');
    const passengerCount = selectedSeats.length || parseInt(bookingData.passengers) || 1;

    for (let i = 0; i < passengerCount; i++) {
      const passengerCard = document.createElement('div');
      passengerCard.className = 'passenger-card';

      const seatNumber = selectedSeats[i]?.seatNumber || (i + 1);

      passengerCard.innerHTML = `
        <h3 class="font-bold text-lg mb-4 flex items-center gap-2">
          <iconify-icon icon="solar:user-bold" class="size-5 text-primary"></iconify-icon>
          الراكب ${i + 1} - المقعد ${seatNumber}
        </h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-sm font-medium mb-2">
              الاسم الكامل <span class="required-indicator">*</span>
            </label>
            <input
              type="text"
              name="passenger_${i}_name"
              class="form-input"
              placeholder="أدخل الاسم الكامل"
              required
            />
            <div class="field-error">يرجى إدخال الاسم الكامل</div>
          </div>
          <div>
            <label class="block text-sm font-medium mb-2">
              رقم الهوية <span class="required-indicator">*</span>
            </label>
            <input
              type="text"
              name="passenger_${i}_id"
              class="form-input"
              placeholder="1xxxxxxxxx"
              required
            />
            <div class="field-error">يرجى إدخال رقم هوية صحيح</div>
          </div>
          <div>
            <label class="block text-sm font-medium mb-2">
              الجنس <span class="required-indicator">*</span>
            </label>
            <select
              name="passenger_${i}_gender"
              class="form-input form-select"
              required
            >
              <option value="">اختر الجنس</option>
              <option value="male">ذكر</option>
              <option value="female">أنثى</option>
            </select>
            <div class="field-error">يرجى اختيار الجنس</div>
          </div>
          <div>
            <label class="block text-sm font-medium mb-2">
              العمر <span class="required-indicator">*</span>
            </label>
            <input
              type="number"
              name="passenger_${i}_age"
              class="form-input"
              placeholder="أدخل العمر"
              min="1"
              max="120"
              required
            />
            <div class="field-error">يرجى إدخال عمر صحيح</div>
          </div>
        </div>
      `;

      container.appendChild(passengerCard);
    }
  }

  function setupFormHandling() {
    const form = document.getElementById('passengerDetailsForm');

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      // تحقق من كل الحقول
      if (!validateForm()) {
        showErrorMessage('يرجى التأكد من إدخال جميع البيانات المطلوبة بشكل صحيح');
        return;
      }

      showLoadingOverlay('جارٍ حفظ بيانات الحجز...');

      const formData = new FormData(form);
      const managerDetails = {
        name: formData.get('managerName'),
        phone: formData.get('managerPhone'),
        email: formData.get('managerEmail'),
        nationalId: formData.get('managerID'),
      };

      // حفظ رقم جوال المدير في bookingData
      const updatedBookingData = {
        ...bookingData,
        managerPhone: managerDetails.phone,
      };
      sessionStorage.setItem('bookingData', JSON.stringify(updatedBookingData));

      const passengers = [];
      const passengerCount = selectedSeats.length || parseInt(bookingData.passengers) || 1;
      for (let i = 0; i < passengerCount; i++) {
        passengers.push({
          name: formData.get(`passenger_${i}_name`),
          nationalId: formData.get(`passenger_${i}_id`),
          gender: formData.get(`passenger_${i}_gender`),
          age: formData.get(`passenger_${i}_age`),
          seatNumber: selectedSeats[i]?.seatNumber || (i + 1),
        });
      }

      const totalPrice = (tripData.price || 0) * selectedSeats.length;

      const bookingResult = await createBooking({
        tripId: tripData.id,
        managerDetails: managerDetails,
        passengers: passengers,
        selectedSeats: selectedSeats,
        totalPrice: totalPrice,
      });

      hideLoadingOverlay();

      if (!bookingResult.success) {
        showErrorMessage(bookingResult.error || 'حدث خطأ أثناء إنشاء الحجز');
        return;
      }

      sessionStorage.setItem('bookingReference', bookingResult.data.bookingReference);
      sessionStorage.setItem('bookingId', bookingResult.data.bookingId);

      showSuccessMessage(
        'تم إنشاء الحجز بنجاح! رقم الحجز: ' + bookingResult.data.bookingReference
      );

      setTimeout(() => {
        window.location.href = '/payment.html';
      }, 1500);
    });
  }

  function validateForm() {
    let isValid = true;
    const form = document.getElementById('passengerDetailsForm');
    const inputs = form.querySelectorAll('input[required], select[required]');

    inputs.forEach((input) => {
      const errorDiv = input.parentElement.querySelector('.field-error');

      if (!input.value.trim()) {
        errorDiv.classList.add('show');
        input.style.borderColor = 'var(--destructive)';
        isValid = false;
      } else {
        errorDiv.classList.remove('show');
        input.style.borderColor = 'transparent';

        if (input.type === 'email') {
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(input.value)) {
            errorDiv.classList.add('show');
            input.style.borderColor = 'var(--destructive)';
            isValid = false;
          }
        }

        if (input.type === 'tel' && input.name === 'managerPhone') {
          const phoneRegex = /^05\d{8}$/;
          if (!phoneRegex.test(input.value)) {
            errorDiv.classList.add('show');
            errorDiv.textContent = 'يرجى إدخال رقم جوال سعودي صحيح (05xxxxxxxx)';
            input.style.borderColor = 'var(--destructive)';
            isValid = false;
          }
        }

        if (
          (input.name === 'managerID' ||
            (input.name.includes('passenger') && input.name.includes('_id'))) &&
          input.value
        ) {
          if (input.value.length !== 10 || !input.value.startsWith('1')) {
            errorDiv.classList.add('show');
            errorDiv.textContent = 'رقم الهوية يجب أن يبدأ بـ 1 ويتكون من 10 أرقام';
            input.style.borderColor = 'var(--destructive)';
            isValid = false;
          }
        }
      }
    });

    return isValid;
  }

  // التحقق الفوري أثناء الإدخال
  const form = document.getElementById('passengerDetailsForm');
  form.addEventListener('input', (e) => {
    if (e.target.matches('input, select')) {
      const errorDiv = e.target.parentElement.querySelector('.field-error');
      if (e.target.value.trim()) {
        errorDiv.classList.remove('show');
        e.target.style.borderColor = 'transparent';
      }
    }
  });

  // تأكد أن لدينا بيانات حجز
  if (!bookingData.fromStation || selectedSeats.length === 0) {
    showErrorMessage('لا توجد بيانات حجز. سيتم إعادة توجيهك للصفحة الرئيسية...');
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 2000);
  }
});
