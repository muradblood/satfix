# هيكل المشروع

هيكل منظم لنظام حجز الباصات - جاهز للنشر على Ubuntu 24.04

---

## 📁 الهيكل الكامل

```
bus-booking-system/
│
├── 📂 api/                          # واجهة برمجية PHP
│   ├── .htaccess                    # تكوين Apache للـ API
│   ├── config.php                   # إعدادات قاعدة البيانات والأمان
│   ├── auth.php                     # نظام المصادقة
│   └── api.php                      # نقاط النهاية الرئيسية
│
├── 📂 database/                     # قاعدة البيانات
│   ├── schema.sql                   # هيكل كامل (14 جدول)
│   └── generate_trips.sql           # توليد الرحلات التلقائي
│
├── 📂 admin/                        # لوحة التحكم
│   ├── index.html                   # الصفحة الرئيسية
│   ├── login.html                   # تسجيل الدخول
│   ├── setup.html                   # الإعداد الأولي
│   ├── telegram-settings.html       # إعدادات تيليجرام
│   └── generate-trips.html          # توليد الرحلات
│
├── 📂 src/                          # المصدر
│   ├── 📂 lib/
│   │   └── api-client.js            # عميل API
│   ├── 📂 modules/                  # وحدات JavaScript
│   ├── 📂 components/               # مكونات
│   ├── 📂 services/                 # خدمات
│   ├── 📂 locales/                  # ترجمات
│   └── 📂 styles/                   # أنماط CSS
│
├── 📂 public/                       # ملفات عامة
│   ├── favicon.ico
│   ├── logo.png
│   └── saptco-logo.jpg
│
├── 📂 dist/                         # ملفات مبنية (production)
│   ├── index.html
│   ├── 📂 assets/
│   └── 📂 admin/
│
├── 📂 docs/                         # التوثيق
│   ├── 📂 mysql/
│   │   ├── MYSQL_SETUP_GUIDE.md
│   │   └── MIGRATION_GUIDE.md
│   ├── AUTO_TRIP_GENERATION.md
│   └── accessibility-review-report.md
│
├── 📂 logs/                         # السجلات (يُنشأ تلقائياً)
│
├── .htaccess                        # تكوين Apache الرئيسي
├── .gitignore                       # ملفات Git المستبعدة
├── package.json                     # تبعيات npm
├── vite.config.js                   # تكوين Vite
│
├── 📄 README.md                     # تعليمات عامة
├── 📄 MYSQL_README.md               # دليل MySQL
├── 📄 DEPLOYMENT_GUIDE.md           # دليل النشر
├── 📄 PROJECT_STRUCTURE.md          # هذا الملف
└── 📄 AUTO_GENERATION_SUMMARY.md    # ملخص التوليد التلقائي

```

---

## 🎯 الملفات الأساسية للخادم

### الملفات المطلوبة للعمل:

```
✅ api/                    # واجهة برمجية
✅ database/               # قاعدة بيانات
✅ dist/                   # ملفات مبنية
✅ public/                 # صور وأصول
✅ .htaccess              # تكوين Apache
```

### الملفات الاختيارية (للتطوير فقط):

```
⚠️ src/                   # مصدر (للتطوير)
⚠️ node_modules/          # تبعيات (للتطوير)
⚠️ package.json           # npm (للتطوير)
⚠️ vite.config.js         # Vite (للتطوير)
```

---

## 📦 ما تم حذفه

### ملفات Supabase (غير مستخدمة):

```
❌ supabase/
❌ src/lib/supabase.js
❌ .env
❌ @supabase/supabase-js (من package.json)
```

### ملفات أخرى محذوفة:

```
❌ .bolt/
❌ .admin-credentials.txt
❌ book-tickets copy.html
```

---

## 🔑 الملفات الهامة

### 1. api/config.php
**الأهمية**: ⭐⭐⭐⭐⭐

يحتوي على:
- إعدادات قاعدة البيانات
- مفاتيح التشفير (JWT_SECRET)
- إعدادات OTP
- إعدادات CORS

**يجب تحديثه قبل النشر!**

### 2. database/schema.sql
**الأهمية**: ⭐⭐⭐⭐⭐

يحتوي على:
- 14 جدول كامل
- علاقات (Foreign Keys)
- فهارس محسّنة
- بيانات أولية

### 3. .htaccess
**الأهمية**: ⭐⭐⭐⭐

يحتوي على:
- إعادة توجيه API
- رؤوس الأمان
- إعدادات PHP
- Caching

### 4. api/.htaccess
**الأهمية**: ⭐⭐⭐⭐

يحتوي على:
- حماية config.php
- توجيه الطلبات
- معالجة CORS

---

## 📊 حجم الملفات

### ملفات الإنتاج (Production):

```
api/           ~50 KB
database/      ~100 KB
dist/          ~2 MB
public/        ~500 KB
docs/          ~200 KB
.htaccess      ~3 KB
─────────────────
الإجمالي:     ~3 MB
```

### مع ملفات التطوير:

```
+ src/         ~500 KB
+ node_modules/ ~50 MB
─────────────────
الإجمالي:     ~53 MB
```

---

## 🚀 للنشر على الخادم

### الملفات الضرورية فقط:

```bash
# قائمة الملفات للرفع
/api/
/database/
/dist/
/public/
/admin/
.htaccess
DEPLOYMENT_GUIDE.md
```

### طريقة الرفع:

```bash
# من جهازك المحلي
rsync -avz --exclude 'node_modules' \
           --exclude 'src' \
           --exclude '.git' \
           ./ user@server:/var/www/bus-booking-system/
```

---

## 🔄 سير العمل

### 1. التطوير المحلي:

```bash
npm install          # تثبيت التبعيات
npm run dev          # خادم تطوير
# التعديل في src/
npm run build        # بناء للإنتاج
```

### 2. النشر:

```bash
# بناء أولاً
npm run build

# رفع الملفات
rsync -avz dist/ api/ database/ public/ admin/ .htaccess \
  user@server:/var/www/bus-booking-system/

# على الخادم
sudo chown -R www-data:www-data /var/www/bus-booking-system
sudo systemctl restart apache2
```

---

## 📝 ملاحظات مهمة

### قبل النشر:

1. ✅ حدّث `api/config.php`
2. ✅ غيّر `JWT_SECRET`
3. ✅ عطّل `DEBUG_MODE`
4. ✅ استورد `database/schema.sql`
5. ✅ عيّن الصلاحيات الصحيحة

### بعد النشر:

1. ✅ اختبر API endpoints
2. ✅ اختبر تسجيل الدخول
3. ✅ اختبر الحجز
4. ✅ راجع logs
5. ✅ إعداد النسخ الاحتياطي

---

## 🔒 الأمان

### ملفات يجب حمايتها:

```
🔐 api/config.php       (chmod 600)
🔐 database/*.sql       (chmod 644)
🔐 .htaccess           (chmod 644)
🔐 api/.htaccess       (chmod 644)
```

### مجلدات يجب حمايتها:

```
🔐 api/                (منع الوصول المباشر لـ config.php)
🔐 logs/               (chmod 775)
```

---

## 📞 المراجع

- [دليل النشر الكامل](DEPLOYMENT_GUIDE.md)
- [دليل MySQL](docs/mysql/MYSQL_SETUP_GUIDE.md)
- [دليل توليد الرحلات](docs/AUTO_TRIP_GENERATION.md)

---

**✨ المشروع منظم وجاهز للنشر على Ubuntu 24.04**
