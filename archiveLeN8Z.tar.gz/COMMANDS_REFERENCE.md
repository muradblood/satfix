# مرجع الأوامر السريع

جميع الأوامر المطلوبة للنشر والصيانة في مكان واحد.

---

## 🚀 أوامر التثبيت الأساسية

### تحديث النظام
```bash
sudo apt update && sudo apt upgrade -y
```

### تثبيت كل شيء دفعة واحدة
```bash
sudo apt install -y apache2 php8.1 php8.1-fpm php8.1-mysql \
  php8.1-mbstring php8.1-curl php8.1-xml php8.1-json mysql-server
```

### تفعيل الوحدات
```bash
sudo a2enmod rewrite proxy_fcgi setenvif headers
sudo a2enconf php8.1-fpm
sudo systemctl restart apache2
```

---

## 🗄️ أوامر MySQL

### إنشاء قاعدة البيانات (نسخ ولصق)
```sql
CREATE DATABASE bus_booking_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'bus_admin'@'localhost' IDENTIFIED BY 'YOUR_PASSWORD_HERE';
GRANT ALL PRIVILEGES ON bus_booking_system.* TO 'bus_admin'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### استيراد قاعدة البيانات
```bash
mysql -u bus_admin -p bus_booking_system < database/schema.sql
mysql -u bus_admin -p bus_booking_system < database/generate_trips.sql
```

### أوامر MySQL مفيدة
```bash
# تسجيل الدخول
mysql -u bus_admin -p bus_booking_system

# عرض الجداول
SHOW TABLES;

# عرض بنية جدول
DESCRIBE users;

# عدد السجلات
SELECT COUNT(*) FROM trips;

# عمل نسخة احتياطية
mysqldump -u bus_admin -p bus_booking_system > backup.sql

# استعادة نسخة احتياطية
mysql -u bus_admin -p bus_booking_system < backup.sql
```

---

## 📁 أوامر الصلاحيات

### تعيين الصلاحيات الكاملة
```bash
sudo chown -R www-data:www-data /var/www/bus-booking-system
sudo find /var/www/bus-booking-system -type d -exec chmod 755 {} \;
sudo find /var/www/bus-booking-system -type f -exec chmod 644 {} \;
sudo chmod 600 /var/www/bus-booking-system/api/config.php
```

### إنشاء مجلد logs
```bash
sudo mkdir -p /var/www/bus-booking-system/logs
sudo chmod 775 /var/www/bus-booking-system/logs
sudo chown www-data:www-data /var/www/bus-booking-system/logs
```

---

## 🌐 أوامر Apache

### إدارة Apache
```bash
# بدء
sudo systemctl start apache2

# إيقاف
sudo systemctl stop apache2

# إعادة تشغيل
sudo systemctl restart apache2

# إعادة تحميل التكوين
sudo systemctl reload apache2

# التحقق من الحالة
sudo systemctl status apache2

# تفعيل عند بدء التشغيل
sudo systemctl enable apache2
```

### إدارة المواقع
```bash
# تفعيل موقع
sudo a2ensite bus-booking.conf

# تعطيل موقع
sudo a2dissite 000-default.conf

# عرض المواقع المفعلة
sudo apache2ctl -S

# اختبار التكوين
sudo apache2ctl configtest
```

### إدارة الوحدات
```bash
# تفعيل وحدة
sudo a2enmod rewrite
sudo a2enmod headers

# تعطيل وحدة
sudo a2dismod module_name

# عرض الوحدات المفعلة
sudo apache2ctl -M
```

---

## 🐘 أوامر PHP

### إدارة PHP-FPM
```bash
# بدء
sudo systemctl start php8.1-fpm

# إيقاف
sudo systemctl stop php8.1-fpm

# إعادة تشغيل
sudo systemctl restart php8.1-fpm

# التحقق من الحالة
sudo systemctl status php8.1-fpm
```

### معلومات PHP
```bash
# نسخة PHP
php -v

# وحدات PHP المثبتة
php -m

# معلومات phpinfo
php -i

# اختبار ملف PHP
php -l /path/to/file.php
```

---

## 🔥 أوامر جدار الحماية (UFW)

### إعداد أساسي
```bash
# تفعيل UFW
sudo ufw enable

# تعطيل UFW
sudo ufw disable

# عرض الحالة
sudo ufw status

# عرض الحالة مع الأرقام
sudo ufw status numbered
```

### إضافة قواعد
```bash
# السماح بـ SSH
sudo ufw allow 22/tcp

# السماح بـ HTTP
sudo ufw allow 80/tcp

# السماح بـ HTTPS
sudo ufw allow 443/tcp

# السماح بـ port معين
sudo ufw allow 3306/tcp

# حذف قاعدة
sudo ufw delete allow 3306/tcp

# حذف بالرقم
sudo ufw delete 2
```

---

## 📊 أوامر المراقبة

### مراقبة Logs
```bash
# Apache Error Log
sudo tail -f /var/log/apache2/error.log
sudo tail -100 /var/log/apache2/bus-booking-error.log

# Apache Access Log
sudo tail -f /var/log/apache2/access.log

# PHP-FPM Log
sudo tail -f /var/log/php8.1-fpm.log

# MySQL Error Log
sudo tail -f /var/log/mysql/error.log

# System Log
sudo tail -f /var/log/syslog
```

### مراقبة الموارد
```bash
# استخدام CPU والذاكرة (تفاعلي)
htop

# معلومات الذاكرة
free -h

# مساحة القرص
df -h

# استخدام مجلد معين
du -sh /var/www/bus-booking-system

# العمليات النشطة
ps aux | grep apache2
ps aux | grep php
ps aux | grep mysql

# الاتصالات النشطة
netstat -tunlp | grep :80
netstat -tunlp | grep :443
```

---

## 🔒 أوامر SSL (Certbot)

### إصدار شهادة SSL
```bash
# تثبيت Certbot
sudo apt install certbot python3-certbot-apache -y

# الحصول على شهادة
sudo certbot --apache -d yourdomain.com -d www.yourdomain.com

# الحصول على شهادة (وضع يدوي)
sudo certbot certonly --manual -d yourdomain.com
```

### إدارة الشهادات
```bash
# عرض الشهادات
sudo certbot certificates

# تجديد الشهادات
sudo certbot renew

# اختبار التجديد
sudo certbot renew --dry-run

# حذف شهادة
sudo certbot delete --cert-name yourdomain.com
```

---

## 💾 أوامر النسخ الاحتياطي

### نسخ احتياطي يدوي
```bash
# نسخ قاعدة البيانات
mysqldump -u bus_admin -p bus_booking_system | gzip > backup_$(date +%Y%m%d).sql.gz

# نسخ الملفات
tar -czf backup_$(date +%Y%m%d).tar.gz -C /var/www bus-booking-system

# نسخ إلى خادم آخر
scp backup_*.tar.gz user@backup-server:/backups/
```

### استعادة من نسخة احتياطية
```bash
# استعادة قاعدة البيانات
gunzip < backup_20250115.sql.gz | mysql -u bus_admin -p bus_booking_system

# استعادة الملفات
tar -xzf backup_20250115.tar.gz -C /var/www/
```

---

## 🔧 أوامر الصيانة

### تنظيف النظام
```bash
# تنظيف الحزم غير المستخدمة
sudo apt autoremove -y

# تنظيف ذاكرة التخزين المؤقت
sudo apt autoclean

# تنظيف logs القديمة
sudo find /var/log -name "*.log" -mtime +30 -delete

# تنظيف tmp
sudo rm -rf /tmp/*
```

### تحسين MySQL
```bash
# تحسين الجداول
mysql -u bus_admin -p -e "OPTIMIZE TABLE bus_booking_system.trips, bus_booking_system.bookings;"

# تحليل الجداول
mysql -u bus_admin -p -e "ANALYZE TABLE bus_booking_system.trips;"

# إصلاح الجداول
mysql -u bus_admin -p -e "REPAIR TABLE bus_booking_system.trips;"
```

---

## 🧪 أوامر الاختبار

### اختبار API
```bash
# اختبار المحطات
curl http://localhost/api/api.php?endpoint=stations

# اختبار التسجيل
curl -X POST http://localhost/api/auth.php?action=register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"123456","full_name":"Test"}'

# اختبار تسجيل الدخول
curl -X POST http://localhost/api/auth.php?action=login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"123456"}'

# اختبار البحث عن رحلات
curl "http://localhost/api/api.php?endpoint=trips&from=1&to=2&date=2025-01-20"
```

### اختبار الاتصال
```bash
# اختبار HTTP
curl -I http://localhost

# اختبار HTTPS
curl -I https://yourdomain.com

# اختبار DNS
nslookup yourdomain.com

# اختبار ping
ping -c 4 yourdomain.com
```

---

## 📝 أوامر التحرير

### محررات النصوص
```bash
# nano (سهل)
sudo nano /path/to/file

# vim (متقدم)
sudo vim /path/to/file

# عرض ملف
cat /path/to/file

# عرض مع أرقام السطور
cat -n /path/to/file

# عرض بداية ملف
head -20 /path/to/file

# عرض نهاية ملف
tail -20 /path/to/file
```

---

## 🔍 أوامر البحث

### البحث في الملفات
```bash
# البحث عن نص في ملفات
grep -r "search_text" /var/www/bus-booking-system/

# البحث عن ملفات
find /var/www -name "*.php"

# البحث عن ملفات معدّلة مؤخراً
find /var/www -mtime -7

# البحث عن ملفات كبيرة
find /var/www -size +10M
```

---

## 🔄 أوامر Cron

### إدارة Cron Jobs
```bash
# فتح crontab
crontab -e

# عرض cron jobs
crontab -l

# حذف جميع cron jobs
crontab -r

# cron jobs للمستخدم الجذر
sudo crontab -e
sudo crontab -l
```

### أمثلة Cron
```bash
# كل دقيقة
* * * * * command

# كل 5 دقائق
*/5 * * * * command

# كل ساعة
0 * * * * command

# كل يوم الساعة 2 صباحاً
0 2 * * * command

# كل أحد الساعة 3 صباحاً
0 3 * * 0 command
```

---

## 🆘 أوامر الطوارئ

### إعادة تشغيل الخدمات
```bash
# إعادة تشغيل كل شيء
sudo systemctl restart apache2 php8.1-fpm mysql

# قتل عملية معلقة
sudo killall apache2
sudo killall php-fpm

# إعادة تشغيل الخادم
sudo reboot
```

### استكشاف الأخطاء
```bash
# آخر 100 سطر من error log
sudo tail -100 /var/log/apache2/error.log

# البحث عن أخطاء PHP
sudo grep "PHP" /var/log/apache2/error.log

# التحقق من المنافذ المستخدمة
sudo netstat -tunlp

# التحقق من العمليات
ps aux | grep apache2
```

---

## 📋 أوامر معلومات النظام

```bash
# نسخة Ubuntu
lsb_release -a

# معلومات CPU
lscpu

# معلومات الذاكرة
free -h

# معلومات القرص
df -h

# مدة تشغيل النظام
uptime

# المستخدمين المتصلين
who

# تاريخ ووقت النظام
date
```

---

## 🎯 أوامر مجمّعة مفيدة

### فحص شامل للنظام
```bash
echo "=== Apache ===" && sudo systemctl status apache2 | head -5 && \
echo "=== PHP ===" && php -v | head -1 && \
echo "=== MySQL ===" && sudo systemctl status mysql | head -5 && \
echo "=== Disk ===" && df -h | grep -v tmpfs && \
echo "=== Memory ===" && free -h
```

### تنظيف شامل
```bash
sudo apt autoremove -y && \
sudo apt autoclean && \
sudo find /var/log -name "*.log" -mtime +30 -delete && \
echo "✓ تم التنظيف"
```

### نسخ احتياطي سريع
```bash
DATE=$(date +%Y%m%d_%H%M%S) && \
mysqldump -u bus_admin -p bus_booking_system | gzip > /tmp/db_$DATE.sql.gz && \
tar -czf /tmp/files_$DATE.tar.gz -C /var/www bus-booking-system && \
echo "✓ نسخ احتياطي في /tmp/"
```

---

## 💡 نصائح سريعة

### اختصارات مفيدة
```bash
# السطر السابق
!!

# آخر وسيط من السطر السابق
!$

# مسح الشاشة
clear  # أو Ctrl+L

# إيقاف عملية
Ctrl+C

# الخروج من terminal
exit  # أو Ctrl+D
```

### التنقل
```bash
# الذهاب للمنزل
cd ~

# الرجوع للمجلد السابق
cd -

# عرض المسار الحالي
pwd

# عرض محتويات المجلد
ls -la
```

---

**💾 احفظ هذا الملف كمرجع سريع!**
