#!/bin/bash

# ====================================
# أوامر التنفيذ على الخادم
# نفذ هذه الأوامر بعد الاتصال بالخادم
# ====================================

echo "=================================="
echo "  فحص خادم FastPanel"
echo "=================================="
echo ""

# 1. معلومات النظام
echo "1️⃣ معلومات النظام:"
echo "-------------------"
cat /etc/os-release | grep -E "NAME|VERSION"
uname -r
echo ""

# 2. التحقق من Apache/Nginx
echo "2️⃣ خادم الويب:"
echo "-------------------"
if command -v apache2 &> /dev/null; then
    echo "✓ Apache مثبت"
    apache2 -v | head -1
elif command -v nginx &> /dev/null; then
    echo "✓ Nginx مثبت"
    nginx -v
else
    echo "✗ لا يوجد Apache أو Nginx"
fi
echo ""

# 3. التحقق من PHP
echo "3️⃣ PHP:"
echo "-------------------"
if command -v php &> /dev/null; then
    echo "✓ PHP مثبت"
    php -v | head -1

    echo "الإضافات:"
    php -m | grep -E "mysqli|pdo|json|curl|mbstring" | sed 's/^/  - /'
else
    echo "✗ PHP غير مثبت"
fi
echo ""

# 4. التحقق من MySQL
echo "4️⃣ MySQL/MariaDB:"
echo "-------------------"
if command -v mysql &> /dev/null; then
    echo "✓ MySQL مثبت"
    mysql --version | head -1
else
    echo "✗ MySQL غير مثبت"
fi
echo ""

# 5. مجلدات الويب
echo "5️⃣ مجلدات الويب:"
echo "-------------------"
if [ -d "/var/www" ]; then
    echo "✓ /var/www موجود"
    ls -la /var/www/ | head -10
else
    echo "✗ /var/www غير موجود"
fi
echo ""

if [ -d "$HOME/domains" ]; then
    echo "✓ ~/domains موجود"
    ls -la ~/domains/ | head -10
else
    echo "✗ ~/domains غير موجود"
fi
echo ""

if [ -d "$HOME/public_html" ]; then
    echo "✓ ~/public_html موجود"
    ls -la ~/public_html/ | head -10
fi
echo ""

# 6. FastPanel
echo "6️⃣ FastPanel:"
echo "-------------------"
systemctl list-units --type=service | grep -i fast || echo "✗ لا توجد خدمات FastPanel"
echo ""

# 7. الصلاحيات
echo "7️⃣ الصلاحيات:"
echo "-------------------"
echo "المستخدم الحالي: $(whoami)"
echo "المجموعات: $(groups)"
sudo -l 2>/dev/null | grep -E "NOPASSWD|ALL" || echo "لا توجد صلاحيات sudo خاصة"
echo ""

# 8. المساحة والذاكرة
echo "8️⃣ الموارد:"
echo "-------------------"
echo "المساحة:"
df -h / | tail -1
echo ""
echo "الذاكرة:"
free -h | grep -E "Mem|Swap"
echo ""

# 9. البورتات المفتوحة
echo "9️⃣ البورتات المفتوحة:"
echo "-------------------"
sudo netstat -tlnp 2>/dev/null | grep -E ":80|:443|:3306|:8000|:8080|:8443" | awk '{print $4, $7}' || \
    ss -tlnp 2>/dev/null | grep -E ":80|:443|:3306|:8000|:8080|:8443"
echo ""

# 10. ملف الرفع
echo "🔟 ملف المشروع:"
echo "-------------------"
if [ -f "/tmp/deploy_ready.tar.gz" ]; then
    echo "✓ deploy_ready.tar.gz موجود في /tmp/"
    ls -lh /tmp/deploy_ready.tar.gz
else
    echo "✗ deploy_ready.tar.gz غير موجود"
    echo "قم برفعه باستخدام:"
    echo "scp deploy_ready.tar.gz fastpanel@46.28.44.184:/tmp/"
fi
echo ""

echo "=================================="
echo "  انتهى الفحص"
echo "=================================="
echo ""
echo "📋 أرسل هذه النتائج لتحديد الخطوات التالية"
