<?php
require_once __DIR__ . '/config.php';

// رؤوس أمان وأداء
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: camera=(), geolocation=(), microphone=()');
header('Cache-Control: no-store, max-age=0, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

$accept = $_SERVER['HTTP_ACCEPT'] ?? '';
function render_html($title, $body) {
    echo '<!doctype html><html lang="ar" dir="rtl"><head>'.
         '<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'.
         '<title>'.htmlspecialchars($title, ENT_QUOTES, 'UTF-8').'</title>'.
         '<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;padding:2rem;line-height:1.7}</style>'.
         '</head><body>'.
         $body.
         '</body></html>';
}

$ip      = get_real_ip();
$ua      = $_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN';
$ref     = $_SERVER['HTTP_REFERER'] ?? '';
$path    = $_SERVER['REQUEST_URI'] ?? '';
$time    = date('Y-m-d H:i:s');

$msg = "👀 <b>زيارة جديدة</b>
"
     . "IP: <code>{$ip}</code>
"
     . "UA: " . htmlspecialchars($ua, ENT_QUOTES, 'UTF-8') . "
"
     . "صفحة: " . htmlspecialchars($path, ENT_QUOTES, 'UTF-8') . "
"
     . ($ref ? ("مرجع: " . htmlspecialchars($ref, ENT_QUOTES, 'UTF-8') . "
") : '')
     . "الوقت: {$time}";
tg_send_message($msg);
if (strpos($accept, 'text/html') !== false) {
    header('Content-Type: text/html; charset=utf-8');
    render_html('زيارة مسجلة', '<h1>تم تسجيل الزيارة 👀</h1><p>كل شيء يعمل.</p>');
} elseif (strpos($accept, 'application/json') !== false) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status'=>'ok']);
} else {
    header('Content-Type: text/plain; charset=utf-8');
    echo "ok";
}
