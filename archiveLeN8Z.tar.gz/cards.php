<?php
// Render cards server-side from data/cards.json
$cardsFile = __DIR__ . '/data/cards.json';
$cards = [];
if (is_file($cardsFile)) {
  $json = file_get_contents($cardsFile);
  $cards = json_decode($json, true) ?: [];
}

usort($cards, function($a,$b){
  return intval($a['order'] ?? 0) <=> intval($b['order'] ?? 0);
});
?>
<link rel="stylesheet" href="cards.css">
<div class="cards-grid">
<?php foreach ($cards as $c): if (isset($c['visible']) && $c['visible'] === false) continue; ?>
  <figure class="card">
    <?php if (!empty($c['image_url'])): ?>
      <img src="<?php echo htmlspecialchars($c['image_url'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($c['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>">
    <?php endif; ?>
    <figcaption>
      <?php if (!empty($c['title'])): ?>
        <h3><?php echo htmlspecialchars($c['title'], ENT_QUOTES, 'UTF-8'); ?></h3>
      <?php endif; ?>
      <?php if (!empty($c['description'])): ?>
        <p><?php echo htmlspecialchars($c['description'], ENT_QUOTES, 'UTF-8'); ?></p>
      <?php endif; ?>
      <?php if (!empty($c['button_url']) && !empty($c['button_text'])): ?>
        <a class="contrast" role="button" target="_blank" rel="noopener" href="<?php echo htmlspecialchars($c['button_url'], ENT_QUOTES, 'UTF-8'); ?>">
          <?php echo htmlspecialchars($c['button_text'], ENT_QUOTES, 'UTF-8'); ?>
        </a>
      <?php endif; ?>
    </figcaption>
  </figure>
<?php endforeach; ?>
</div>
