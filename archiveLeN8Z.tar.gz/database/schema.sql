-- =====================================================
-- نظام حجز الباصات - قاعدة بيانات MySQL
-- =====================================================

CREATE DATABASE IF NOT EXISTS bus_booking_system
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE bus_booking_system;

-- =====================================================
-- 1. جدول المستخدمين
-- =====================================================
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(255),
  phone VARCHAR(20),
  national_id VARCHAR(20),
  role ENUM('user', 'admin') DEFAULT 'user',
  email_verified BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  last_login TIMESTAMP NULL,
  INDEX idx_email (email),
  INDEX idx_role (role),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 2. جدول جلسات المستخدمين
-- =====================================================
CREATE TABLE IF NOT EXISTS user_sessions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  token VARCHAR(255) NOT NULL UNIQUE,
  expires_at TIMESTAMP NOT NULL,
  ip_address VARCHAR(45),
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_token (token),
  INDEX idx_user_id (user_id),
  INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 3. جدول الملفات الشخصية
-- =====================================================
CREATE TABLE IF NOT EXISTS user_profiles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL UNIQUE,
  date_of_birth DATE,
  gender ENUM('male', 'female', 'other'),
  address TEXT,
  city VARCHAR(100),
  country VARCHAR(100) DEFAULT 'Saudi Arabia',
  preferences JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 4. جدول المحطات
-- =====================================================
CREATE TABLE IF NOT EXISTS stations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name_ar VARCHAR(255) NOT NULL,
  name_en VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  address TEXT,
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  phone VARCHAR(20),
  facilities JSON,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_city (city),
  INDEX idx_is_active (is_active),
  FULLTEXT idx_search (name_ar, name_en, city)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 5. جدول الباصات
-- =====================================================
CREATE TABLE IF NOT EXISTS buses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bus_number VARCHAR(50) NOT NULL UNIQUE,
  bus_type ENUM('standard', 'vip', 'luxury') DEFAULT 'standard',
  capacity INT NOT NULL,
  plate_number VARCHAR(20),
  manufacturer VARCHAR(100),
  model VARCHAR(100),
  year INT,
  features JSON,
  is_active BOOLEAN DEFAULT TRUE,
  last_maintenance DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_bus_number (bus_number),
  INDEX idx_bus_type (bus_type),
  INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 6. جدول الرحلات
-- =====================================================
CREATE TABLE IF NOT EXISTS trips (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  trip_number VARCHAR(50) NOT NULL UNIQUE,
  from_station_id INT UNSIGNED NOT NULL,
  to_station_id INT UNSIGNED NOT NULL,
  bus_id INT UNSIGNED NOT NULL,
  departure_time DATETIME NOT NULL,
  arrival_time DATETIME NOT NULL,
  base_price DECIMAL(10, 2) NOT NULL,
  available_seats INT NOT NULL,
  trip_status ENUM('scheduled', 'boarding', 'in_transit', 'completed', 'cancelled') DEFAULT 'scheduled',
  is_direct BOOLEAN DEFAULT TRUE,
  amenities JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (from_station_id) REFERENCES stations(id),
  FOREIGN KEY (to_station_id) REFERENCES stations(id),
  FOREIGN KEY (bus_id) REFERENCES buses(id),
  INDEX idx_trip_number (trip_number),
  INDEX idx_from_station (from_station_id),
  INDEX idx_to_station (to_station_id),
  INDEX idx_bus_id (bus_id),
  INDEX idx_departure_time (departure_time),
  INDEX idx_trip_status (trip_status),
  INDEX idx_route (from_station_id, to_station_id, departure_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 7. جدول الحجوزات
-- =====================================================
CREATE TABLE IF NOT EXISTS bookings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_reference VARCHAR(50) NOT NULL UNIQUE,
  user_id INT UNSIGNED,
  trip_id INT UNSIGNED NOT NULL,
  manager_name VARCHAR(255) NOT NULL,
  manager_email VARCHAR(255) NOT NULL,
  manager_phone VARCHAR(20) NOT NULL,
  manager_national_id VARCHAR(20) NOT NULL,
  total_passengers INT NOT NULL,
  total_price DECIMAL(10, 2) NOT NULL,
  booking_status ENUM('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
  payment_status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
  payment_method VARCHAR(50),
  payment_reference VARCHAR(100),
  payment_date TIMESTAMP NULL,
  seats JSON,
  special_requests TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (trip_id) REFERENCES trips(id),
  INDEX idx_booking_reference (booking_reference),
  INDEX idx_user_id (user_id),
  INDEX idx_trip_id (trip_id),
  INDEX idx_booking_status (booking_status),
  INDEX idx_payment_status (payment_status),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 8. جدول تفاصيل الركاب
-- =====================================================
CREATE TABLE IF NOT EXISTS passenger_details (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  booking_id INT UNSIGNED NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  national_id VARCHAR(20) NOT NULL,
  date_of_birth DATE,
  gender ENUM('male', 'female', 'other'),
  phone VARCHAR(20),
  seat_number VARCHAR(10),
  passenger_type ENUM('adult', 'child', 'infant') DEFAULT 'adult',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  INDEX idx_booking_id (booking_id),
  INDEX idx_national_id (national_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 9. جدول المراجعات
-- =====================================================
CREATE TABLE IF NOT EXISTS trip_reviews (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  trip_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  is_approved BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_trip_id (trip_id),
  INDEX idx_user_id (user_id),
  INDEX idx_rating (rating),
  INDEX idx_is_approved (is_approved)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 10. جدول التعليقات
-- =====================================================
CREATE TABLE IF NOT EXISTS comments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  review_id INT UNSIGNED,
  parent_id INT UNSIGNED,
  user_id INT UNSIGNED NOT NULL,
  content TEXT NOT NULL,
  is_approved BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (review_id) REFERENCES trip_reviews(id) ON DELETE CASCADE,
  FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_review_id (review_id),
  INDEX idx_parent_id (parent_id),
  INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 11. جدول الرحلات المفضلة
-- =====================================================
CREATE TABLE IF NOT EXISTS favorite_routes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  from_station_id INT UNSIGNED NOT NULL,
  to_station_id INT UNSIGNED NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (from_station_id) REFERENCES stations(id),
  FOREIGN KEY (to_station_id) REFERENCES stations(id),
  UNIQUE KEY unique_favorite (user_id, from_station_id, to_station_id),
  INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 12. جدول سجل التدقيق
-- =====================================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED,
  action VARCHAR(100) NOT NULL,
  table_name VARCHAR(100) NOT NULL,
  record_id INT UNSIGNED,
  old_values JSON,
  new_values JSON,
  ip_address VARCHAR(45),
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_user_id (user_id),
  INDEX idx_table_name (table_name),
  INDEX idx_action (action),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 13. جدول إعدادات تيليجرام
-- =====================================================
CREATE TABLE IF NOT EXISTS telegram_settings (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  bot_token VARCHAR(255) NOT NULL,
  chat_id VARCHAR(100) NOT NULL,
  notifications_enabled BOOLEAN DEFAULT TRUE,
  notify_new_booking BOOLEAN DEFAULT TRUE,
  notify_cancellation BOOLEAN DEFAULT TRUE,
  notify_payment BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by INT UNSIGNED,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 14. جدول رموز OTP
-- =====================================================
CREATE TABLE IF NOT EXISTS otp_codes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED,
  phone VARCHAR(20) NOT NULL,
  code VARCHAR(10) NOT NULL,
  purpose ENUM('verification', 'payment', 'password_reset') DEFAULT 'verification',
  expires_at TIMESTAMP NOT NULL,
  is_used BOOLEAN DEFAULT FALSE,
  attempts INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_phone (phone),
  INDEX idx_code (code),
  INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- بيانات أولية - المحطات الرئيسية
-- =====================================================
INSERT INTO stations (name_ar, name_en, city, address, latitude, longitude) VALUES
('محطة الرياض المركزية', 'Riyadh Central Station', 'الرياض', 'حي العليا، الرياض', 24.7136, 46.6753),
('محطة جدة', 'Jeddah Station', 'جدة', 'حي الروضة، جدة', 21.5433, 39.1728),
('محطة مكة المكرمة', 'Makkah Station', 'مكة', 'العزيزية، مكة المكرمة', 21.4225, 39.8262),
('محطة المدينة المنورة', 'Madinah Station', 'المدينة المنورة', 'حي العزيزية، المدينة المنورة', 24.4672, 39.6111),
('محطة الدمام', 'Dammam Station', 'الدمام', 'حي الفيصلية، الدمام', 26.4207, 50.0888),
('محطة الخبر', 'Khobar Station', 'الخبر', 'حي الثقبة، الخبر', 26.2172, 50.1971),
('محطة أبها', 'Abha Station', 'أبها', 'حي المنهل، أبها', 18.2164, 42.5053),
('محطة الطائف', 'Taif Station', 'الطائف', 'حي الفيصلية، الطائف', 21.2703, 40.4153);

-- =====================================================
-- بيانات أولية - الباصات
-- =====================================================
INSERT INTO buses (bus_number, bus_type, capacity, plate_number, manufacturer, model, year, features) VALUES
('BUS-001', 'luxury', 45, 'ABC-1234', 'Mercedes', 'Travego', 2023, '{"wifi": true, "charging": true, "entertainment": true, "meal": true}'),
('BUS-002', 'vip', 40, 'ABC-1235', 'Volvo', '9700', 2023, '{"wifi": true, "charging": true, "entertainment": true}'),
('BUS-003', 'standard', 50, 'ABC-1236', 'Scania', 'Touring', 2022, '{"wifi": true, "charging": false}'),
('BUS-004', 'vip', 40, 'ABC-1237', 'Mercedes', 'Tourismo', 2023, '{"wifi": true, "charging": true, "entertainment": true}'),
('BUS-005', 'standard', 50, 'ABC-1238', 'MAN', 'Lion Coach', 2022, '{"wifi": true}');

-- =====================================================
-- بيانات أولية - رحلات تجريبية
-- =====================================================
INSERT INTO trips (trip_number, from_station_id, to_station_id, bus_id, departure_time, arrival_time, base_price, available_seats, is_direct) VALUES
('TRIP-001', 1, 2, 1, DATE_ADD(NOW(), INTERVAL 1 DAY), DATE_ADD(NOW(), INTERVAL 1 DAY) + INTERVAL 10 HOUR, 250.00, 45, TRUE),
('TRIP-002', 2, 1, 2, DATE_ADD(NOW(), INTERVAL 1 DAY) + INTERVAL 2 HOUR, DATE_ADD(NOW(), INTERVAL 1 DAY) + INTERVAL 12 HOUR, 250.00, 40, TRUE),
('TRIP-003', 1, 3, 3, DATE_ADD(NOW(), INTERVAL 2 DAY), DATE_ADD(NOW(), INTERVAL 2 DAY) + INTERVAL 12 HOUR, 300.00, 50, TRUE),
('TRIP-004', 1, 5, 4, DATE_ADD(NOW(), INTERVAL 1 DAY) + INTERVAL 6 HOUR, DATE_ADD(NOW(), INTERVAL 1 DAY) + INTERVAL 10 HOUR, 180.00, 40, TRUE);

-- =====================================================
-- انتهى
-- =====================================================
