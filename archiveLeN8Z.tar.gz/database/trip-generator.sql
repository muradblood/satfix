-- =====================================================
-- نظام توليد الرحلات التلقائي
-- =====================================================

USE bus_booking_system;

DELIMITER $$

-- =====================================================
-- دالة توليد رحلات تلقائية
-- =====================================================
DROP PROCEDURE IF EXISTS generate_trips$$

CREATE PROCEDURE generate_trips(
    IN start_date DATE,
    IN end_date DATE,
    IN trips_per_route INT
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_from_station INT;
    DECLARE v_to_station INT;
    DECLARE v_station_from_name VARCHAR(255);
    DECLARE v_station_to_name VARCHAR(255);
    DECLARE v_bus_id INT;
    DECLARE v_bus_type VARCHAR(20);
    DECLARE v_capacity INT;
    DECLARE v_current_date DATE;
    DECLARE v_trip_count INT;
    DECLARE v_hour INT;
    DECLARE v_departure_time DATETIME;
    DECLARE v_arrival_time DATETIME;
    DECLARE v_duration INT;
    DECLARE v_base_price DECIMAL(10,2);
    DECLARE v_trip_number VARCHAR(50);

    -- Cursor لجميع المسارات الممكنة
    DECLARE route_cursor CURSOR FOR
        SELECT s1.id, s2.id, s1.name_ar, s2.name_ar
        FROM stations s1
        CROSS JOIN stations s2
        WHERE s1.id < s2.id
        AND s1.is_active = TRUE
        AND s2.is_active = TRUE;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- حذف الرحلات القديمة المجدولة فقط
    DELETE FROM trips
    WHERE trip_status = 'scheduled'
    AND departure_time < NOW();

    OPEN route_cursor;

    route_loop: LOOP
        FETCH route_cursor INTO v_from_station, v_to_station, v_station_from_name, v_station_to_name;

        IF done THEN
            LEAVE route_loop;
        END IF;

        -- حساب المدة والسعر بناءً على المسافة
        SET v_duration = 4 + FLOOR(RAND() * 8); -- من 4 إلى 12 ساعة
        SET v_base_price = 100 + (v_duration * 20) + (RAND() * 100);

        -- توليد رحلات لكل تاريخ
        SET v_current_date = start_date;

        date_loop: WHILE v_current_date <= end_date DO
            -- توليد عدة رحلات في اليوم
            SET v_trip_count = 0;

            trip_loop: WHILE v_trip_count < trips_per_route DO
                -- اختيار باص عشوائي
                SELECT id, bus_type, capacity
                INTO v_bus_id, v_bus_type, v_capacity
                FROM buses
                WHERE is_active = TRUE
                ORDER BY RAND()
                LIMIT 1;

                -- تحديد وقت المغادرة (موزع على مدار اليوم)
                SET v_hour = 6 + (v_trip_count * (18 / trips_per_route));
                SET v_departure_time = CONCAT(v_current_date, ' ', LPAD(FLOOR(v_hour), 2, '0'), ':00:00');
                SET v_arrival_time = DATE_ADD(v_departure_time, INTERVAL v_duration HOUR);

                -- توليد رقم رحلة فريد
                SET v_trip_number = CONCAT(
                    'T',
                    DATE_FORMAT(v_current_date, '%Y%m%d'),
                    '-',
                    LPAD(v_from_station, 2, '0'),
                    LPAD(v_to_station, 2, '0'),
                    '-',
                    LPAD(v_trip_count + 1, 2, '0')
                );

                -- إضافة الرحلة
                INSERT INTO trips (
                    trip_number,
                    from_station_id,
                    to_station_id,
                    bus_id,
                    departure_time,
                    arrival_time,
                    base_price,
                    available_seats,
                    trip_status,
                    is_direct,
                    amenities
                ) VALUES (
                    v_trip_number,
                    v_from_station,
                    v_to_station,
                    v_bus_id,
                    v_departure_time,
                    v_arrival_time,
                    v_base_price,
                    v_capacity,
                    'scheduled',
                    TRUE,
                    JSON_OBJECT(
                        'wifi', IF(v_bus_type IN ('vip', 'luxury'), TRUE, FALSE),
                        'charging', IF(v_bus_type IN ('vip', 'luxury'), TRUE, FALSE),
                        'entertainment', IF(v_bus_type = 'luxury', TRUE, FALSE),
                        'refreshments', IF(v_bus_type = 'luxury', TRUE, FALSE)
                    )
                );

                -- رحلة العودة
                SET v_trip_number = CONCAT(
                    'T',
                    DATE_FORMAT(v_current_date, '%Y%m%d'),
                    '-',
                    LPAD(v_to_station, 2, '0'),
                    LPAD(v_from_station, 2, '0'),
                    '-',
                    LPAD(v_trip_count + 1, 2, '0')
                );

                INSERT INTO trips (
                    trip_number,
                    from_station_id,
                    to_station_id,
                    bus_id,
                    departure_time,
                    arrival_time,
                    base_price,
                    available_seats,
                    trip_status,
                    is_direct,
                    amenities
                ) VALUES (
                    v_trip_number,
                    v_to_station,
                    v_from_station,
                    v_bus_id,
                    DATE_ADD(v_departure_time, INTERVAL 2 HOUR),
                    DATE_ADD(v_arrival_time, INTERVAL 2 HOUR),
                    v_base_price,
                    v_capacity,
                    'scheduled',
                    TRUE,
                    JSON_OBJECT(
                        'wifi', IF(v_bus_type IN ('vip', 'luxury'), TRUE, FALSE),
                        'charging', IF(v_bus_type IN ('vip', 'luxury'), TRUE, FALSE),
                        'entertainment', IF(v_bus_type = 'luxury', TRUE, FALSE),
                        'refreshments', IF(v_bus_type = 'luxury', TRUE, FALSE)
                    )
                );

                SET v_trip_count = v_trip_count + 1;
            END WHILE trip_loop;

            SET v_current_date = DATE_ADD(v_current_date, INTERVAL 1 DAY);
        END WHILE date_loop;

    END LOOP route_loop;

    CLOSE route_cursor;

    -- عرض الإحصائيات
    SELECT
        COUNT(*) as total_trips,
        COUNT(DISTINCT from_station_id) as total_stations_from,
        COUNT(DISTINCT to_station_id) as total_stations_to,
        MIN(departure_time) as first_trip,
        MAX(departure_time) as last_trip,
        SUM(available_seats) as total_seats
    FROM trips
    WHERE trip_status = 'scheduled';

END$$

-- =====================================================
-- دالة توليد رحلات لشهر كامل
-- =====================================================
DROP PROCEDURE IF EXISTS generate_monthly_trips$$

CREATE PROCEDURE generate_monthly_trips(
    IN target_month INT,
    IN target_year INT,
    IN trips_per_route INT
)
BEGIN
    DECLARE v_start_date DATE;
    DECLARE v_end_date DATE;

    -- حساب أول وآخر يوم في الشهر
    SET v_start_date = DATE(CONCAT(target_year, '-', LPAD(target_month, 2, '0'), '-01'));
    SET v_end_date = LAST_DAY(v_start_date);

    CALL generate_trips(v_start_date, v_end_date, trips_per_route);
END$$

-- =====================================================
-- دالة توليد رحلات للأسبوع القادم
-- =====================================================
DROP PROCEDURE IF EXISTS generate_weekly_trips$$

CREATE PROCEDURE generate_weekly_trips(
    IN trips_per_route INT
)
BEGIN
    DECLARE v_start_date DATE;
    DECLARE v_end_date DATE;

    SET v_start_date = CURDATE();
    SET v_end_date = DATE_ADD(CURDATE(), INTERVAL 7 DAY);

    CALL generate_trips(v_start_date, v_end_date, trips_per_route);
END$$

-- =====================================================
-- دالة توليد رحلات ليوم محدد
-- =====================================================
DROP PROCEDURE IF EXISTS generate_daily_trips$$

CREATE PROCEDURE generate_daily_trips(
    IN target_date DATE,
    IN trips_per_route INT
)
BEGIN
    CALL generate_trips(target_date, target_date, trips_per_route);
END$$

-- =====================================================
-- دالة تنظيف الرحلات القديمة
-- =====================================================
DROP PROCEDURE IF EXISTS cleanup_old_trips$$

CREATE PROCEDURE cleanup_old_trips(
    IN days_old INT
)
BEGIN
    DECLARE v_deleted_count INT;

    -- حذف الرحلات القديمة التي لم يتم حجزها
    DELETE FROM trips
    WHERE trip_status = 'scheduled'
    AND departure_time < DATE_SUB(NOW(), INTERVAL days_old DAY)
    AND available_seats = (SELECT capacity FROM buses WHERE id = bus_id);

    SET v_deleted_count = ROW_COUNT();

    SELECT v_deleted_count as deleted_trips;
END$$

DELIMITER ;

-- =====================================================
-- أمثلة على الاستخدام
-- =====================================================

-- توليد رحلات للأسبوع القادم (3 رحلات لكل مسار يومياً)
-- CALL generate_weekly_trips(3);

-- توليد رحلات لشهر محدد
-- CALL generate_monthly_trips(1, 2025, 3);

-- توليد رحلات ليوم محدد
-- CALL generate_daily_trips('2025-01-15', 3);

-- تنظيف الرحلات القديمة (أقدم من 7 أيام)
-- CALL cleanup_old_trips(7);

-- =====================================================
-- إنشاء event تلقائي لتوليد رحلات يومياً
-- =====================================================

-- تمكين جدولة الأحداث
SET GLOBAL event_scheduler = ON;

-- حذف الحدث إن وجد
DROP EVENT IF EXISTS daily_trip_generation;

-- إنشاء حدث يومي لتوليد رحلات الأسبوع القادم
CREATE EVENT daily_trip_generation
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    -- توليد رحلات للأسبوع القادم
    CALL generate_weekly_trips(3);

    -- تنظيف الرحلات القديمة
    CALL cleanup_old_trips(7);
END;

-- عرض الأحداث المجدولة
-- SHOW EVENTS;

-- =====================================================
-- إحصائيات الرحلات
-- =====================================================

DROP PROCEDURE IF EXISTS get_trip_statistics$$

DELIMITER $$

CREATE PROCEDURE get_trip_statistics()
BEGIN
    SELECT
        DATE(departure_time) as trip_date,
        COUNT(*) as total_trips,
        SUM(available_seats) as total_available_seats,
        SUM(capacity - available_seats) as total_booked_seats,
        ROUND(AVG(base_price), 2) as avg_price,
        COUNT(DISTINCT from_station_id) as stations_covered
    FROM trips t
    JOIN buses b ON t.bus_id = b.id
    WHERE trip_status = 'scheduled'
    AND departure_time >= CURDATE()
    GROUP BY DATE(departure_time)
    ORDER BY trip_date;
END$$

DELIMITER ;

-- =====================================================
-- تهيئة أولية: توليد رحلات للشهر الحالي
-- =====================================================

CALL generate_monthly_trips(MONTH(CURDATE()), YEAR(CURDATE()), 3);
