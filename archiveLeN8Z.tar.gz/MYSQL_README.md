# 🚌 نظام حجز الباصات - MySQL + PHP API

نظام متكامل لحجز تذاكر الباصات مع قاعدة بيانات MySQL وواجهة برمجية PHP.

---

## ✨ المميزات

### 🎯 الوظائف الأساسية
- ✅ تسجيل المستخدمين وتسجيل الدخول
- ✅ البحث عن الرحلات المتاحة
- ✅ حجز التذاكر واختيار المقاعد
- ✅ إدارة معلومات الركاب
- ✅ التحقق من OTP
- ✅ معالجة الدفع
- ✅ تتبع الحجوزات
- ✅ إشعارات تيليجرام

### 🎨 واجهة المستخدم
- 📱 تصميم متجاوب بالكامل (Mobile-First)
- 🌙 دعم الوضع الليلي/النهاري
- 🌍 دعم اللغتين العربية والإنجليزية
- ♿ متوافق مع معايير إمكانية الوصول (WCAG 2.1)
- 🎭 تأثيرات حركية سلسة

### 🔒 الأمان
- 🔐 تشفير كلمات المرور (bcrypt)
- 🎫 نظام JWT للمصادقة
- 🛡️ حماية من SQL Injection
- 🚫 تحقق من المدخلات وتنظيفها
- 📝 سجل تدقيق شامل

---

## 📁 هيكل المشروع

```
project/
├── api/                    # واجهة برمجة التطبيق
│   ├── config.php          # إعدادات الاتصال والأمان
│   ├── auth.php            # نظام المصادقة
│   └── api.php             # نقاط النهاية الرئيسية
│
├── database/               # قاعدة البيانات
│   └── schema.sql          # هيكل قاعدة البيانات
│
├── src/                    # الشفرة المصدرية
│   ├── lib/
│   │   └── api-client.js   # عميل API
│   ├── modules/            # وحدات JavaScript
│   ├── components/         # المكونات
│   └── styles/             # ملفات CSS
│
├── public/                 # الملفات العامة
│   └── assets/             # الصور والأيقونات
│
├── docs/                   # التوثيق
│   └── mysql/              # أدلة MySQL
│       ├── MYSQL_SETUP_GUIDE.md
│       └── MIGRATION_GUIDE.md
│
└── dist/                   # الملفات المبنية
```

---

## 🚀 البدء السريع

### المتطلبات الأساسية

- PHP 7.4 أو أحدث
- MySQL 8.0 أو أحدث
- خادم ويب (Apache/Nginx)
- Node.js (للتطوير)

### التثبيت

#### 1. استنساخ المشروع

```bash
git clone https://github.com/yourusername/bus-booking-system.git
cd bus-booking-system
```

#### 2. إعداد قاعدة البيانات

```bash
# تسجيل الدخول لـ MySQL
mysql -u root -p

# استيراد الهيكل
mysql -u root -p < database/schema.sql
```

#### 3. إعداد الإعدادات

نسخ وتعديل `api/config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'bus_booking_system');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('JWT_SECRET', 'your-secret-key-here');
```

#### 4. تثبيت التبعيات (للتطوير)

```bash
npm install
```

#### 5. بناء المشروع

```bash
npm run build
```

#### 6. تشغيل الخادم

```bash
# Apache
sudo systemctl start apache2

# أو Nginx
sudo systemctl start nginx

# أو خادم PHP المدمج (للتطوير فقط)
php -S localhost:8000 -t .
```

---

## 📡 نقاط النهاية (API Endpoints)

### المصادقة

```bash
# تسجيل مستخدم جديد
POST /api/auth.php?action=register
Content-Type: application/json
{
  "email": "user@example.com",
  "password": "password123",
  "full_name": "أحمد محمد",
  "phone": "0501234567"
}

# تسجيل الدخول
POST /api/auth.php?action=login
Content-Type: application/json
{
  "email": "user@example.com",
  "password": "password123"
}

# التحقق من الجلسة
GET /api/auth.php?action=verify
Authorization: Bearer {token}

# تسجيل الخروج
POST /api/auth.php?action=logout
Authorization: Bearer {token}
```

### المحطات والرحلات

```bash
# الحصول على جميع المحطات
GET /api/api.php?endpoint=stations

# البحث عن رحلات
GET /api/api.php?endpoint=trips&from=1&to=2&date=2025-01-15&passengers=2

# الحصول على رحلة محددة
GET /api/api.php?endpoint=trip&id=1
```

### الحجوزات

```bash
# إنشاء حجز جديد
POST /api/api.php?endpoint=booking
Content-Type: application/json
Authorization: Bearer {token}
{
  "trip_id": 1,
  "manager_name": "أحمد محمد",
  "manager_email": "ahmad@example.com",
  "manager_phone": "0501234567",
  "manager_national_id": "1234567890",
  "total_passengers": 2,
  "seats": ["A1", "A2"],
  "passengers": [...]
}

# الحصول على حجز
GET /api/api.php?endpoint=booking&ref=BK-12345678
```

### OTP

```bash
# إنشاء رمز OTP
POST /api/api.php?endpoint=otp
Content-Type: application/json
{
  "phone": "0501234567",
  "purpose": "verification"
}

# التحقق من OTP
POST /api/api.php?endpoint=verify-otp
Content-Type: application/json
{
  "phone": "0501234567",
  "code": "123456"
}
```

### تيليجرام

```bash
# إرسال إشعار
POST /api/api.php?endpoint=telegram
Content-Type: application/json
Authorization: Bearer {token}
{
  "message": "تم إنشاء حجز جديد #BK-12345678"
}
```

---

## 🔧 الإعدادات

### config.php

```php
// قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'bus_booking_system');
define('DB_USER', 'root');
define('DB_PASS', '');

// الأمان
define('JWT_SECRET', 'your-secret-key');
define('JWT_EXPIRY', 86400);  // 24 ساعة

// OTP
define('OTP_LENGTH', 6);
define('OTP_EXPIRY', 300);     // 5 دقائق
define('OTP_MAX_ATTEMPTS', 3);

// CORS
define('ALLOWED_ORIGINS', [
    'http://localhost:5173',
    'https://yourdomain.com'
]);

// Debug (false في الإنتاج)
define('DEBUG_MODE', true);
```

---

## 🗄️ قاعدة البيانات

### الجداول الرئيسية

- **users** - المستخدمين
- **user_sessions** - الجلسات
- **user_profiles** - الملفات الشخصية
- **stations** - محطات الباصات
- **buses** - الباصات
- **trips** - الرحلات
- **bookings** - الحجوزات
- **passenger_details** - تفاصيل الركاب
- **trip_reviews** - المراجعات
- **comments** - التعليقات
- **favorite_routes** - المسارات المفضلة
- **audit_logs** - سجل التدقيق
- **telegram_settings** - إعدادات تيليجرام
- **otp_codes** - رموز OTP

### الفهارس

جميع المفاتيح الأجنبية والحقول المستخدمة في البحث مفهرسة لتحسين الأداء.

---

## 🧪 الاختبار

### اختبار API

```bash
# استخدم curl
./tests/api-test.sh

# أو Postman
# استورد collection من docs/postman-collection.json
```

### اختبار قاعدة البيانات

```bash
php tests/test-db.php
```

---

## 📚 التوثيق

- [دليل تثبيت MySQL](docs/mysql/MYSQL_SETUP_GUIDE.md)
- [دليل الترحيل من Supabase](docs/mysql/MIGRATION_GUIDE.md)
- [دليل البدء السريع](QUICK_START.md)
- [دليل التصميم المتجاوب](RESPONSIVE_DESIGN.md)

---

## 🔒 الأمان

### أفضل الممارسات المطبقة

1. ✅ تشفير كلمات المرور باستخدام bcrypt
2. ✅ استخدام Prepared Statements لمنع SQL Injection
3. ✅ تنظيف والتحقق من جميع المدخلات
4. ✅ نظام JWT آمن للمصادقة
5. ✅ حماية CORS
6. ✅ معالجة آمنة للأخطاء
7. ✅ سجل تدقيق شامل
8. ✅ حماية الملفات الحساسة

### نصائح إضافية

- استخدم HTTPS في الإنتاج
- غيّر JWT_SECRET إلى قيمة عشوائية قوية
- فعّل جدار الحماية
- راجع السجلات بانتظام
- احتفظ بنسخ احتياطية منتظمة

---

## 🚀 النشر

### على خادم مشترك (Shared Hosting)

1. ارفع الملفات عبر FTP
2. استورد قاعدة البيانات من phpMyAdmin
3. عدّل config.php
4. تأكد من الصلاحيات

### على VPS

```bash
# نسخ الملفات
rsync -avz ./ user@server:/var/www/bus-booking/

# على الخادم
cd /var/www/bus-booking
sudo chown -R www-data:www-data .
sudo systemctl restart apache2
```

---

## 🛠️ الصيانة

### النسخ الاحتياطي

```bash
# نسخة يدوية
mysqldump -u root -p bus_booking_system > backup.sql

# نسخة تلقائية (cron)
0 2 * * * mysqldump -u root -pPASSWORD bus_booking_system | gzip > /backups/db_$(date +\%Y\%m\%d).sql.gz
```

### تحسين الأداء

```sql
-- تحليل الجداول
ANALYZE TABLE trips, bookings, users;

-- تحسين الجداول
OPTIMIZE TABLE trips, bookings, users;
```

### مراقبة السجلات

```bash
# سجل Apache
tail -f /var/log/apache2/error.log

# سجل PHP
tail -f /var/log/php/error.log

# سجل التطبيق
tail -f logs/api.log
```

---

## 🤝 المساهمة

نرحب بالمساهمات! يرجى:

1. Fork المشروع
2. إنشاء فرع للميزة (`git checkout -b feature/AmazingFeature`)
3. Commit التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. Push للفرع (`git push origin feature/AmazingFeature`)
5. فتح Pull Request

---

## 📝 الترخيص

هذا المشروع مرخص تحت MIT License.

---

## 💬 الدعم

للأسئلة والدعم:

- 📧 البريد الإلكتروني: support@example.com
- 💬 تيليجرام: @bus_booking_support
- 📚 الوثائق: [docs/](docs/)

---

## 🙏 شكر وتقدير

- فريق تطوير النظام
- المساهمون في المشروع
- المجتمع المفتوح المصدر

---

**صُنع بـ ❤️ في السعودية**
