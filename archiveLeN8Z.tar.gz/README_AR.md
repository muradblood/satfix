# 🚌 نظام حجز باصات سابتكو

## ⚡ البدء السريع

### 1️⃣ تفعيل التسجيل
```
Supabase Dashboard → Authentication → Settings
✓ Enable Email Signup
Save
```

### 2️⃣ إنشاء حساب مسؤول
```
افتح: /admin/setup.html
أدخل البريد والكلمة
اضغط "إنشاء الحساب"
```

### 3️⃣ تسجيل الدخول
```
افتح: /admin/login.html
أدخل البيانات
```

### 4️⃣ إعداد تيليجرام
```
لوحة التحكم → إعدادات تيليجرام
أدخل Bot Token & Chat ID
فعّل الإشعارات
احفظ
```

## 📁 الصفحات الرئيسية

### المستخدمين
- `/` - الرئيسية
- `/trip-results.html` - نتائج البحث
- `/seat-selection.html` - اختيار المقاعد
- `/payment.html` - الدفع
- `/profile.html` - الملف الشخصي

### المسؤولين
- `/admin/setup.html` ⭐ - إنشاء حساب
- `/admin/login.html` ⭐ - تسجيل دخول
- `/admin/index.html` - لوحة التحكم
- `/admin/telegram-settings.html` ⭐ - إعدادات تيليجرام

## 🔔 الإشعارات

يرسل النظام إشعارات تيليجرام عند:
- ✅ حجز جديد
- ❌ إلغاء حجز
- 💰 دفع مكتمل

## 📚 الملفات المهمة

- `SETUP_INSTRUCTIONS.md` - تعليمات الإعداد الكاملة
- `ADMIN_LOGIN_GUIDE.md` - دليل نظام تسجيل الدخول
- `QUICK_START.md` - دليل البدء السريع
- `README_AR.md` - هذا الملف (ملخص سريع)

## ⚠️ مهم!

**يجب تفعيل "Enable Email Signup" في Supabase قبل إنشاء الحسابات!**

## 🆘 مشاكل شائعة

| المشكلة | الحل |
|---------|------|
| Email signups disabled | فعّل Email Signup في Dashboard |
| Unauthorized | سجل دخول من /admin/login.html |
| Telegram failed | تحقق من Token & Chat ID |

## ✅ جاهز!

بعد الإعداد:
1. جرّب حجز تجريبي
2. تحقق من إشعار تيليجرام
3. استكشف لوحة التحكم

🚀 **استمتع!**
