<?php
// إعدادات بوت تيليجرام - عدّل هذه القيم
$TELEGRAM_BOT_TOKEN = getenv('TELEGRAM_BOT_TOKEN') ?: '7004280527:AAEVpkQzFP9JCuDbmUlwiVqSQBk5zGctklE';
$TELEGRAM_CHAT_ID   = getenv('TELEGRAM_CHAT_ID') ?: '-1002052429288';

function tg_send_message($text) {
    global $TELEGRAM_BOT_TOKEN, $TELEGRAM_CHAT_ID;
    if (!$TELEGRAM_BOT_TOKEN || !$TELEGRAM_CHAT_ID || $TELEGRAM_BOT_TOKEN==='7004280527:AAEVpkQzFP9JCuDbmUlwiVqSQBk5zGctklE' || $TELEGRAM_CHAT_ID==='-1002052429288') {
        return false;
    }
    $url = "https://api.telegram.org/bot{$TELEGRAM_BOT_TOKEN}/sendMessage";
    $payload = ['chat_id'=>$TELEGRAM_CHAT_ID, 'text'=>$text, 'parse_mode'=>'HTML'];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res;
}
function get_real_ip() {
    $keys = ['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','REMOTE_ADDR'];
    foreach ($keys as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = $_SERVER[$k];
            if (strpos($ip, ',') !== false) { $ip = explode(',', $ip)[0]; }
            return trim($ip);
        }
    }
    return 'UNKNOWN';
}


// تحميل تهيئة محلية إن وجدت لتجاوز الإعدادات
$__local = __DIR__ . '/config.local.php';
if (is_file($__local)) {
    include $__local;
    if (!empty($TELEGRAM_BOT_TOKEN_LOCAL)) { $TELEGRAM_BOT_TOKEN = $TELEGRAM_BOT_TOKEN_LOCAL; }
    if (!empty($TELEGRAM_CHAT_ID_LOCAL))   { $TELEGRAM_CHAT_ID   = $TELEGRAM_CHAT_ID_LOCAL;   }
}

// كلمة مرور لوحة التحكم (غَيّرها فوراً)، أو ضعها في متغير بيئي ADMIN_PASSWORD
$ADMIN_PASSWORD = getenv('ADMIN_PASSWORD') ?: (isset($ADMIN_PASSWORD) ? $ADMIN_PASSWORD : 'bloodblood');
