#!/bin/bash

# ====================================
# سكربت رفع المشروع لخادم FastPanel
# الخادم: 46.28.44.184
# المستخدم: fastpanel
# ====================================

set -e

# الألوان
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo ""
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo ""
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# معلومات الخادم
SERVER_IP="46.28.44.184"
SERVER_USER="fastpanel"

print_header "رفع نظام حجز الباصات"

echo -e "${GREEN}معلومات الخادم:${NC}"
echo "  الخادم: $SERVER_IP"
echo "  المستخدم: $SERVER_USER"
echo ""

# التحقق من وجود الملف المضغوط
if [ ! -f "deploy_ready.tar.gz" ]; then
    print_error "الملف deploy_ready.tar.gz غير موجود"
    print_info "قم بتشغيل: npm run build أولاً"
    exit 1
fi

print_success "الملف المضغوط جاهز ($(du -h deploy_ready.tar.gz | cut -f1))"

# رفع الملف
print_header "جاري رفع الملفات..."

print_info "سيُطلب منك إدخال كلمة المرور..."

scp deploy_ready.tar.gz $SERVER_USER@$SERVER_IP:/tmp/

if [ $? -eq 0 ]; then
    print_success "تم رفع الملفات بنجاح!"
else
    print_error "فشل رفع الملفات"
    exit 1
fi

# عرض التعليمات التالية
print_header "الخطوات التالية"

echo "الآن اتصل بالخادم ونفذ الأوامر التالية:"
echo ""
echo -e "${YELLOW}ssh $SERVER_USER@$SERVER_IP${NC}"
echo ""
echo "ثم نفذ:"
echo ""
cat << 'EOF'
# فك الضغط
cd /tmp
tar -xzf deploy_ready.tar.gz

# معلومات النظام
echo "=== معلومات النظام ==="
cat /etc/os-release | grep -E "NAME|VERSION"

# التحقق من البرامج
echo -e "\n=== البرامج المثبتة ==="
which apache2 nginx 2>/dev/null || echo "لا يوجد Apache/Nginx"
php -v 2>/dev/null | head -1 || echo "لا يوجد PHP"
mysql --version 2>/dev/null | head -1 || echo "لا يوجد MySQL"

# التحقق من مجلدات الويب
echo -e "\n=== مجلدات الويب ==="
ls -la /var/www/ 2>/dev/null || echo "/var/www غير موجود"
ls -la ~/domains/ 2>/dev/null || echo "~/domains غير موجود"
ls -la ~ | grep -E "www|public_html|htdocs"

# التحقق من FastPanel
echo -e "\n=== FastPanel ==="
systemctl list-units | grep -i fast || echo "لا توجد خدمات FastPanel"

echo -e "\n✓ انتهى الفحص"
echo "أرسل النتائج لنقرر الخطوات التالية"
EOF

echo ""
print_success "✨ تم الرفع بنجاح!"
echo ""
