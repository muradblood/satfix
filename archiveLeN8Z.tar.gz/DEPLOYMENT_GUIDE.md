# دليل نشر النظام على Ubuntu 24.04

دليل شامل لنشر نظام حجز الباصات على خادم Ubuntu 24.04 مع PHP 7.4+ و MySQL.

---

## 📋 المتطلبات

### نظام التشغيل
- Ubuntu 24.04 LTS (أو أحدث)
- صلاحيات root أو sudo

### البرامج المطلوبة
- Apache 2.4+ أو Nginx
- PHP 7.4 أو أحدث (يُفضل PHP 8.0+)
- MySQL 8.0+
- Git (اختياري)

### إضافات PHP المطلوبة
```bash
php-fpm
php-mysqli
php-pdo
php-pdo-mysql
php-json
php-mbstring
php-curl
php-xml
```

---

## 🚀 خطوات التثبيت

### الخطوة 1: تحديث النظام

```bash
sudo apt update
sudo apt upgrade -y
```

### الخطوة 2: تثبيت Apache و PHP

```bash
# تثبيت Apache
sudo apt install apache2 -y

# تثبيت PHP والإضافات المطلوبة
sudo apt install php8.1 php8.1-fpm php8.1-mysql php8.1-mbstring php8.1-curl php8.1-xml php8.1-json -y

# تفعيل mod_rewrite و PHP-FPM
sudo a2enmod rewrite
sudo a2enmod proxy_fcgi setenvif
sudo a2enconf php8.1-fpm

# إعادة تشغيل Apache
sudo systemctl restart apache2
```

### الخطوة 3: تثبيت MySQL

```bash
# تثبيت MySQL
sudo apt install mysql-server -y

# تأمين MySQL
sudo mysql_secure_installation

# تسجيل الدخول لـ MySQL
sudo mysql

# إنشاء قاعدة البيانات
CREATE DATABASE bus_booking_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

# إنشاء مستخدم
CREATE USER 'bus_admin'@'localhost' IDENTIFIED BY 'كلمة_مرور_قوية_هنا';

# منح الصلاحيات
GRANT ALL PRIVILEGES ON bus_booking_system.* TO 'bus_admin'@'localhost';
FLUSH PRIVILEGES;

EXIT;
```

### الخطوة 4: رفع ملفات المشروع

#### الطريقة 1: باستخدام Git (موصى بها)

```bash
# الانتقال لمجلد الويب
cd /var/www

# استنساخ المشروع
sudo git clone https://github.com/yourusername/bus-booking-system.git

# أو رفع الملفات يدوياً
sudo mkdir -p /var/www/bus-booking-system
```

#### الطريقة 2: رفع يدوي

```bash
# على جهازك المحلي
scp -r project/* user@your-server:/tmp/

# على الخادم
sudo mv /tmp/* /var/www/bus-booking-system/
```

### الخطوة 5: إعداد الصلاحيات

```bash
# تعيين المالك
sudo chown -R www-data:www-data /var/www/bus-booking-system

# تعيين الصلاحيات
sudo chmod -R 755 /var/www/bus-booking-system

# صلاحيات خاصة لمجلد logs
sudo mkdir -p /var/www/bus-booking-system/logs
sudo chmod -R 775 /var/www/bus-booking-system/logs
```

### الخطوة 6: إعداد Apache Virtual Host

```bash
# إنشاء ملف التكوين
sudo nano /etc/apache2/sites-available/bus-booking.conf
```

أضف المحتوى التالي:

```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com
    DocumentRoot /var/www/bus-booking-system

    <Directory /var/www/bus-booking-system>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted

        # PHP-FPM Configuration
        <FilesMatch \.php$>
            SetHandler "proxy:unix:/run/php/php8.1-fpm.sock|fcgi://localhost"
        </FilesMatch>
    </Directory>

    # API Directory
    <Directory /var/www/bus-booking-system/api>
        Options -Indexes
        AllowOverride All
        Require all granted
    </Directory>

    # Logging
    ErrorLog ${APACHE_LOG_DIR}/bus-booking-error.log
    CustomLog ${APACHE_LOG_DIR}/bus-booking-access.log combined

    # Security Headers
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set X-XSS-Protection "1; mode=block"
    Header always set X-Content-Type-Options "nosniff"
</VirtualHost>
```

حفظ والخروج (Ctrl+O ثم Ctrl+X)

```bash
# تفعيل الموقع
sudo a2ensite bus-booking.conf

# تعطيل الموقع الافتراضي (اختياري)
sudo a2dissite 000-default.conf

# اختبار التكوين
sudo apache2ctl configtest

# إعادة تشغيل Apache
sudo systemctl restart apache2
```

### الخطوة 7: إعداد قاعدة البيانات

```bash
# تحديث ملف config.php
sudo nano /var/www/bus-booking-system/api/config.php
```

عدّل الإعدادات:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'bus_booking_system');
define('DB_USER', 'bus_admin');
define('DB_PASS', 'كلمة_المرور_التي_أنشأتها');

// غيّر المفتاح السري
define('JWT_SECRET', 'مفتاح_عشوائي_قوي_جداً_هنا');

// عطّل وضع التطوير
define('DEBUG_MODE', false);
```

```bash
# استيراد هيكل قاعدة البيانات
mysql -u bus_admin -p bus_booking_system < /var/www/bus-booking-system/database/schema.sql

# استيراد سكربت توليد الرحلات
mysql -u bus_admin -p bus_booking_system < /var/www/bus-booking-system/database/generate_trips.sql
```

### الخطوة 8: إعداد SSL (HTTPS)

```bash
# تثبيت Certbot
sudo apt install certbot python3-certbot-apache -y

# الحصول على شهادة SSL
sudo certbot --apache -d yourdomain.com -d www.yourdomain.com

# تجديد تلقائي
sudo certbot renew --dry-run
```

سيتم إنشاء ملف تكوين جديد تلقائياً في:
`/etc/apache2/sites-available/bus-booking-le-ssl.conf`

### الخطوة 9: إعداد جدار الحماية

```bash
# تفعيل UFW
sudo ufw enable

# السماح بـ SSH
sudo ufw allow 22/tcp

# السماح بـ HTTP و HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# عرض الحالة
sudo ufw status
```

### الخطوة 10: إعداد النسخ الاحتياطي التلقائي

```bash
# إنشاء سكربت النسخ الاحتياطي
sudo nano /usr/local/bin/backup-bus-booking.sh
```

أضف المحتوى:

```bash
#!/bin/bash

# إعدادات
BACKUP_DIR="/var/backups/bus-booking"
DB_NAME="bus_booking_system"
DB_USER="bus_admin"
DB_PASS="كلمة_المرور"
DATE=$(date +%Y%m%d_%H%M%S)

# إنشاء مجلد النسخ الاحتياطي
mkdir -p $BACKUP_DIR

# نسخ احتياطي لقاعدة البيانات
mysqldump -u $DB_USER -p$DB_PASS $DB_NAME | gzip > $BACKUP_DIR/db_$DATE.sql.gz

# نسخ احتياطي للملفات
tar -czf $BACKUP_DIR/files_$DATE.tar.gz -C /var/www bus-booking-system

# حذف النسخ القديمة (أقدم من 30 يوم)
find $BACKUP_DIR -type f -mtime +30 -delete

echo "✓ تم إنشاء نسخة احتياطية: $DATE"
```

```bash
# جعل السكربت قابل للتنفيذ
sudo chmod +x /usr/local/bin/backup-bus-booking.sh

# إضافة مهمة cron يومية
sudo crontab -e

# أضف هذا السطر (كل يوم الساعة 2 صباحاً)
0 2 * * * /usr/local/bin/backup-bus-booking.sh >> /var/log/bus-booking-backup.log 2>&1
```

---

## ✅ اختبار التثبيت

### 1. اختبار Apache و PHP

```bash
# اختبار Apache
sudo systemctl status apache2

# إنشاء ملف اختبار PHP
echo "<?php phpinfo(); ?>" | sudo tee /var/www/bus-booking-system/info.php

# افتح في المتصفح
http://yourdomain.com/info.php

# احذف الملف بعد الاختبار
sudo rm /var/www/bus-booking-system/info.php
```

### 2. اختبار MySQL

```bash
mysql -u bus_admin -p bus_booking_system -e "SELECT COUNT(*) FROM stations;"
```

### 3. اختبار API

```bash
# اختبار المحطات
curl http://yourdomain.com/api/api.php?endpoint=stations

# اختبار التسجيل
curl -X POST http://yourdomain.com/api/auth.php?action=register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"123456","full_name":"Test User"}'
```

### 4. اختبار الموقع

افتح في المتصفح:
- الصفحة الرئيسية: `http://yourdomain.com`
- لوحة التحكم: `http://yourdomain.com/admin/login.html`

---

## 🔧 الإعدادات الإضافية

### تحسين أداء PHP

```bash
sudo nano /etc/php/8.1/fpm/php.ini
```

عدّل القيم:

```ini
memory_limit = 256M
upload_max_filesize = 10M
post_max_size = 10M
max_execution_time = 300
max_input_time = 300
display_errors = Off
log_errors = On
error_log = /var/log/php/error.log
```

```bash
# إنشاء مجلد logs
sudo mkdir -p /var/log/php
sudo chown www-data:www-data /var/log/php

# إعادة تشغيل PHP-FPM
sudo systemctl restart php8.1-fpm
```

### تحسين أداء MySQL

```bash
sudo nano /etc/mysql/mysql.conf.d/mysqld.cnf
```

أضف:

```ini
[mysqld]
max_connections = 200
innodb_buffer_pool_size = 512M
innodb_log_file_size = 128M
query_cache_size = 32M
query_cache_type = 1
```

```bash
sudo systemctl restart mysql
```

### مراقبة الأداء

```bash
# تثبيت htop
sudo apt install htop -y

# مراقبة الموارد
htop

# مراقبة Apache
sudo tail -f /var/log/apache2/bus-booking-access.log

# مراقبة PHP errors
sudo tail -f /var/log/php/error.log

# مراقبة MySQL
sudo tail -f /var/log/mysql/error.log
```

---

## 🔒 تعزيز الأمان

### 1. تعطيل الوظائف الخطرة في PHP

```bash
sudo nano /etc/php/8.1/fpm/php.ini
```

```ini
disable_functions = exec,passthru,shell_exec,system,proc_open,popen,curl_exec,curl_multi_exec,parse_ini_file,show_source
```

### 2. إخفاء نسخة PHP

```ini
expose_php = Off
```

### 3. تعطيل تصفح المجلدات

```apache
# في .htaccess (موجود بالفعل)
Options -Indexes
```

### 4. حماية ملفات الإعدادات

```bash
sudo chmod 600 /var/www/bus-booking-system/api/config.php
sudo chown www-data:www-data /var/www/bus-booking-system/api/config.php
```

### 5. تثبيت Fail2Ban

```bash
# تثبيت
sudo apt install fail2ban -y

# إنشاء تكوين Apache
sudo nano /etc/fail2ban/jail.local
```

```ini
[apache-auth]
enabled = true
port = http,https
logpath = /var/log/apache2/*error.log
maxretry = 3
bantime = 3600

[apache-badbots]
enabled = true
port = http,https
logpath = /var/log/apache2/*access.log
maxretry = 2
bantime = 86400
```

```bash
sudo systemctl restart fail2ban
```

---

## 📊 المراقبة والصيانة

### مهام يومية

```bash
# مراجعة logs
sudo tail -100 /var/log/apache2/bus-booking-error.log
sudo tail -100 /var/log/php/error.log
sudo tail -100 /var/log/mysql/error.log

# مراجعة استخدام القرص
df -h

# مراجعة الذاكرة
free -h
```

### مهام أسبوعية

```bash
# تحديث النظام
sudo apt update && sudo apt upgrade -y

# تنظيف logs القديمة
sudo find /var/log -name "*.log" -mtime +30 -delete

# تحسين MySQL
mysql -u root -p -e "OPTIMIZE TABLE bus_booking_system.trips, bus_booking_system.bookings;"
```

### مهام شهرية

```bash
# مراجعة النسخ الاحتياطية
ls -lh /var/backups/bus-booking/

# اختبار استعادة النسخة الاحتياطية
# (على خادم تجريبي)
```

---

## 🐛 استكشاف الأخطاء

### المشكلة: "500 Internal Server Error"

```bash
# تحقق من logs
sudo tail -50 /var/log/apache2/bus-booking-error.log

# تحقق من صلاحيات الملفات
ls -la /var/www/bus-booking-system/

# تحقق من تكوين Apache
sudo apache2ctl configtest
```

### المشكلة: "Access denied for user"

```bash
# تحقق من إعدادات قاعدة البيانات
sudo nano /var/www/bus-booking-system/api/config.php

# اختبر الاتصال
mysql -u bus_admin -p bus_booking_system -e "SELECT 1;"
```

### المشكلة: "PHP file not found"

```bash
# تحقق من تفعيل PHP-FPM
sudo systemctl status php8.1-fpm

# إعادة تشغيل
sudo systemctl restart php8.1-fpm apache2
```

### المشكلة: ".htaccess not working"

```bash
# تحقق من تفعيل mod_rewrite
sudo a2enmod rewrite

# تحقق من AllowOverride
grep -r "AllowOverride" /etc/apache2/sites-available/

# يجب أن يكون: AllowOverride All
```

---

## 📞 الدعم والموارد

- [دليل تثبيت MySQL](docs/mysql/MYSQL_SETUP_GUIDE.md)
- [دليل الترحيل](docs/mysql/MIGRATION_GUIDE.md)
- [دليل توليد الرحلات](docs/AUTO_TRIP_GENERATION.md)
- [README الرئيسي](MYSQL_README.md)

---

## 🎉 تهانينا!

نظامك الآن جاهز للعمل على Ubuntu 24.04! 🚀

### الخطوات التالية:
1. ✅ أنشئ مستخدم مسؤول
2. ✅ ولّد رحلات تجريبية
3. ✅ اختبر الحجز
4. ✅ راقب الأداء
5. ✅ شارك مع المستخدمين

---

**💡 نصيحة أخيرة**: احفظ نسخة احتياطية قبل أي تعديل كبير!
