```php
<?php
// ...existing code...
?>
<!doctype html>
<html lang="ar">
<head>
    <!-- ...existing head... -->
</head>
<body>
    <div class="container">
        <!-- ...existing markup including search_from, search_to, btnSearch, searchMsg ... -->
        ...existing code...
    </div>

    <!-- استدعاء ملف جافاسكربت البحث المنفصل -->
    <script src="js/search.js"></script>
    <!-- السكربت العام الموجود مسبقاً -->
    <script src="script.js"></script>
</body>
</html>
```